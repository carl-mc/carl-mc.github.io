#######################################
# REPLICATION FILE 
#
# --- Robustness: Randomization Inference ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

###############################
# RANDOMIZATION INFERENCE
###############################


## Stub
stub <- "figure_A1"

## Main function
randinf_coefs <- function(df){
  ## Prep specification
  these.treat <- list(c("tek.status"),
                      c("log(1+prec.homerule.yrsavg)"),
                      c("tek.status", "log(1+prec.homerule.yrsavg)"),
                      c( "log(1+prec.homerule.yrsavg)*tek.status"))
  
  # these.treat <- c(these.treat, 
  #                  list(unlist(these.treat)))
  form.ls <- unlist(lapply(these.treat, function(t){
    lapply(list(contr.vars), function(c){
      make_form(dv = dep.var, 
                expl = c(t, c), 
                fe = fe.vars, 
                iv = "0", se = clust.vars )
    })
  }))
  
  ## Estimate
  model.ls <- lapply(form.ls, function(f){
    felm(f, data = df)
  })
  
  ## Coefficients
  coef.df1 <- getCoefDF(model.ls) %>%
    filter(grepl("TEK|homerule", term)) %>%
    mutate(model = factor(model, labels = c("TEK", "PHR", "TEK + PHR", "Interaction"))) %>%
    mutate(term = factor(term, levels = c("tek.statusTEK", 
                                          "tek.statusTEKCAP", 
                                          "log(1 + prec.homerule.yrsavg)", 
                                          "log(1 + prec.homerule.yrsavg):tek.statusTEK",
                                          "log(1 + prec.homerule.yrsavg):tek.statusTEKCAP"
    ), 
    labels = c("Non-dominant TEK",
               "Dominant TEK", 
               "PHR years, log", 
               "Non-dom. TEK*PHR",
               "Dom. TEK*PHR"), ordered = T)) %>%
    mutate(term = fct_rev(term))
  
  coef.df1$conf.low90 <- coef.df1$estimate - coef.df1$std.error * qnorm(0.95)
  coef.df1$conf.high90 <- coef.df1$estimate + coef.df1$std.error * qnorm(0.95)
  # coef.df1 <- coef.df1 %>% filter(model %in% c("TEK + PHR", "Interaction"))
  
  ## Return
  return(coef.df1)
}

## Main Coefficients
main.df <- cgy.df[cgy.df$is.capitalrulegrp == 0,]
main.coef <- randinf_coefs(main.df)

## Randomization
set.seed(0)
rand.coef <- do.call(rbind, lapply(1:1000, function(i){
  set.seed(i)
  # print(i)
  # Randomize treatment
  treat.vars <- c("prec.homerule.yrsavg", "tek.status")
  rand.df <- main.df
  rand.df[, treat.vars] <- rand.df[sample(seq_len(nrow(main.df)),
                                          nrow(main.df), replace = FALSE), 
                                   treat.vars]
  
  # Estimate coefs
  cbind(randinf_coefs(rand.df), randomization = i)
}))


## Plots
main.coef$term <- factor(main.coef$term, levels = unique(main.coef$term),
                         ordered = T)
rand.coef$term <- factor(rand.coef$term, levels = unique(rand.coef$term),
                         ordered = T)
coef.plot.randinf <- ggplot(data = main.coef, aes(x = estimate,
                                             xmin = conf.low, xmax = conf.high)) +
  geom_line(data = rand.coef, aes(x = estimate), stat = "density", col = "black") +
  geom_vline(xintercept = 0, lty = 2, col = "grey") +
  geom_hline(yintercept = 0, lty = 1, col = "lightgrey", lwd = .6) +
  geom_pointrange(size = 0.5, aes(y = 0), col = "black") +
  geom_linerange(data = main.coef, aes(xmin = conf.low90, xmax = conf.high90, y  = 0), 
                 size = 1, col = "black") +
  scale_x_continuous(name = "Ethnic cleansing risk (ppt. increase)") +
  facet_grid(term ~ model, scales = "free") +
  theme_minimal() +
  theme(legend.position = "none", 
        axis.title.y = element_blank(),
        strip.text = element_text(face = "bold", size = 7)) +
  guides(color = "none") +
  ylab("") +
  theme(panel.spacing = unit(1, "lines"))

png("results/figures/figure_A1.png", width = 6, height = 6, res = 275, units = "in")
print(coef.plot.randinf)
dev.off()

