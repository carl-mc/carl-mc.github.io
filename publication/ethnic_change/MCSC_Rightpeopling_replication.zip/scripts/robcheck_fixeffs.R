#######################################
# REPLICATION FILE 
#
# --- Robustness: Fixed effects ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################


# NO FIXED EFFECTS ##################


## Stub
stub <- "table_A4"

## Prep specification
these.treat <- list(c("tek.status"),
                    c("log(1+prec.homerule.yrsavg)"),
                    c("tek.status", "log(1+prec.homerule.yrsavg)"),
                    c( "log(1+prec.homerule.yrsavg)*tek.status"))

form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(c(contr.vars)), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = "0", 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0,])
})

# Prepare Table
add.lines <- list(latex.addline("Country FE:", rep("no", length(model.ls))),
                  latex.addline("Year FE:", rep("no", length(model.ls))),
                  latex.addline("Controls:", rep(c("yes"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic Cleansing 1886--2020: No Fixed Effects",
                     keep = c("Constant","tek.status", "homerule"),
                     order = c(1,2,5,3,4),
                     # type = "text",
                     multicolumn = F,
                     column.labels = "Ethnic Cleansing (0/100)",
                     column.separate = length(model.ls), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Intercept", "Non-dominant TEK", 
                                          "Dominant TEK",
                                          "Past home rule (yrs, log)", "Non-titular TEK x past home rule",
                                          "Titular TEK x past home rule"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     notes = latex.notes(.85),
                     notes.label = "", notes.append = F
), 
fileConn)
close(fileConn)



# STATE-YEAR FIXED EFFECTS ##################

## Stub
stub <- "table_A6"

## Prep specification
these.treat <- list(c("tek.status"),
                    c("log(1+prec.homerule.yrsavg)"),
                    c("tek.status", "log(1+prec.homerule.yrsavg)"),
                    c( "log(1+prec.homerule.yrsavg)*tek.status"))

form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(c(contr.vars)), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = "factor(gwcode):factor(year)", 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0,])
})

# Prepare Table
add.lines <- list(latex.addline("Country-year FE:", rep("yes", length(model.ls))),
                  latex.addline("Country FE:", rep("--", length(model.ls))),
                  latex.addline("Year FE:", rep("--", length(model.ls))),
                  latex.addline("Controls:", rep(c("yes"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic Cleansing 1886--2020: Country-year Fixed Effects",
                     keep = c("tek.status", "homerule"),
                     order = c(1,2,5,3,4),
                     # type = "text",
                     multicolumn = F,
                     column.labels = "Ethnic Cleansing (0/100)",
                     column.separate = length(model.ls), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Non-dominant TEK", 
                                          "Dominant TEK",
                                          "Past home rule (yrs, log)", "Non-titular TEK x past home rule",
                                          "Titular TEK x past home rule"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     notes = latex.notes(.85),
                     notes.label = "", notes.append = F
), 
fileConn)
close(fileConn)
