#######################################
# REPLICATION FILE 
#
# --- Robustness: Control variables ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

# NO CONTROLS ##################


## Stub
stub <- "table_A3"

## Prep specification
these.treat <- list(c("tek.status"),
                    c("log(1+prec.homerule.yrsavg)"),
                    c("tek.status", "log(1+prec.homerule.yrsavg)"),
                    c( "log(1+prec.homerule.yrsavg)*tek.status"))

form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(c()), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = fe.vars, 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0,])
})

# Prepare Table
add.lines <- list(latex.addline("Country FE:", rep("yes", length(model.ls))),
                  latex.addline("Year FE:", rep("yes", length(model.ls))),
                  latex.addline("Controls:", rep(c("no"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic Cleansing 1886--2020: Without Control Variables",
                     keep = c("tek.status", "homerule"),
                     order = c(1,2,5,3,4),
                     # type = "text",
                     multicolumn = F,
                     column.labels = "Ethnic Cleansing (0/100)",
                     column.separate = length(model.ls), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Non-dominant TEK", 
                                          "Dominant TEK",
                                          "Past home rule (yrs, log)", "Non-titular TEK x past home rule",
                                          "Titular TEK x past home rule"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     notes = latex.notes(.85),
                     notes.label = "", notes.append = F
), 
fileConn)
close(fileConn)



# ADD CONTROLS ##################


## Stub
stub <- "table_A5"



## Prep specification
add.contr <- c("dispersion", "grpshare", "log(borderdistance)",
               "state.frac","tek.frac",
               "loc.rulegrpavg", "loc.rulegrpexp")

these.treat <- list(c("tek.status"),
                    c("log(1+prec.homerule.yrsavg)"),
                    c("tek.status", "log(1+prec.homerule.yrsavg)"),
                    c( "log(1+prec.homerule.yrsavg)*tek.status"))

form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(c(contr.vars, add.contr)), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = fe.vars, 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0,])
})

# Prepare Table
add.lines <- list(latex.addline("Country FE:", rep("yes", length(model.ls))),
                  latex.addline("Year FE:", rep("yes", length(model.ls))),
                  latex.addline("Controls:", rep(c("yes"), length(model.ls))),
                  latex.addline("Additional Controls:", rep(c("yes"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic Cleansing 1886--2020: Additional Controls",
                     keep = c("tek.status", "homerule"),
                     multicolumn = F,
                     column.labels = "Ethnic Cleansing (0/100)",
                     column.separate = length(model.ls), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Non-dominant TEK", 
                                          "Dominant TEK",
                                          "Past home rule (yrs, log)", "Non-titular TEK x past home rule",
                                          "Titular TEK x past home rule"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     notes = latex.notes(.85),
                     notes.label = "", notes.append = F
), 
fileConn)
close(fileConn)
