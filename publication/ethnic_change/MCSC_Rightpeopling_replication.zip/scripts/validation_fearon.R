#######################################
# REPLICATION FILE 
#
# --- HEG Validation: Fearon's List ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

# Load Fearon

## Raw data 
fearon.df <- read.dta13("data/Fearon_List.dta")

## Match
f.match.df <- read.csv("data/fearonlist.csv",
                       stringsAsFactors = F)
fearon.df <- plyr::join(fearon.df, f.match.df,
                        by = c("ccode", "group"),
                        type = "left")
fearon.df$match <- tolower(fearon.df$match)
  
fearon.df <- aggregate.data.frame(fearon.df[, "gpro", drop = F],
                                  fearon.df[, c("ccode", "match")],
                                  FUN = sum, na.rm = T)
  
# Load HEG country-segments
cgy.df$ccode <- cgy.df$gwcode
cgy.df$match <- cgy.df$group
cgy.df$heg.share <- cgy.df$grpshare


# Join
eval.df <- plyr::join(fearon.df, 
                      cgy.df[cgy.df$year == 1990,
                             c("ccode", "match", "heg.share")],
                      by = c("ccode", "match"), type = "inner")

# R2 Variation explained
r.df <- na.omit(eval.df)
r2 <- 1 - sum((r.df$gpro - r.df$heg.share)^2) / sum((r.df$gpro - mean(r.df$gpro))^2)

writeLines(as.character(100 * signif(r2, 2)), 
           file.path(num.path, "heg_fearon_r2.tex"))
