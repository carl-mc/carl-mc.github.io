#######################################
# REPLICATION FILE 
#
# --- Bootstrapped SEs ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

# Predicted probabilities, Model 4 ###

## Model (with fixest)
model <- feols(as.formula(paste(dep.var, "~",
                                paste(c("log(1+prec.homerule.yrsavg)*tek.status", 
                                        contr.vars), 
                                      collapse = " + ") ,
                                "|", paste(fe.vars, collapse = " + ")
)),
cluster = clust.vars,
data = cgy.df[cgy.df$is.capitalrulegrp == 0,])
summary(model)

## Median variable values
med.val <- lapply(all.vars(form.ls[[4]])[-1], function(v){
  median(cgy.df[cgy.df$is.capitalrulegrp == 0,v],
         na.rm = T)
})
med.val <- data.frame(med.val)
colnames(med.val) <- all.vars(form.ls[[4]])[-1]

## Fake data
fake.df <- raw.df <- unique(cgy.df[cgy.df$is.capitalrulegrp == 0, 
                                   c("prec.homerule.yrsavg", "tek.status")])
fake.df$tek.statusTEK <- ifelse(fake.df$tek.status == "TEK", 1, 0)
fake.df$tek.statusTEKCAP <- ifelse(fake.df$tek.status == "TEKCAP", 1, 0)
fake.df$`log(1 + prec.homerule.yrsavg)` <- log(1 + fake.df$prec.homerule.yrsavg)
fake.df$`log(1 + prec.homerule.yrsavg):tek.statusTEK` <- fake.df$`log(1 + prec.homerule.yrsavg)`  * fake.df$tek.statusTEK
fake.df$`log(1 + prec.homerule.yrsavg):tek.statusTEKCAP` <- fake.df$`log(1 + prec.homerule.yrsavg)`  * fake.df$tek.statusTEKCAP
fake.df <- fake.df[, -c(1,2)]


## Predict (relative to 0,0)
pred <- rowSums(t(t(as.matrix(fake.df)) * as.vector(model$coefficients[colnames(fake.df)])))
se <- rowSums(do.call(cbind, unlist(lapply(colnames(fake.df), function(i){
  lapply(colnames(fake.df), function(j){
    fake.df[,i] * fake.df[,j] * vcov(model)[i,j]
  })
}), recursive = F)))^.5

## Plot
plot.df <- cbind(raw.df, fake.df)
plot.df$pred <- pred
plot.df$se <- se

## Adjust labels
plot.df$labels <- ifelse(plot.df$tek.status == "TEK",
                         "Non-dominant TEK", 
                         ifelse(plot.df$tek.status == "TEKCAP",
                                "Dominant TEK",
                                "No TEK"))
main.plot.df <- plot.df


# GROUP-LEVEL BOOTSTRAP ############

## All groups
all.grps <- unique(cgy.df[cgy.df$is.capitalrulegrp == 0,clust.vars])

## Cluster
cl <- makeCluster(getOption("cl.cores", ncore))
registerDoParallel(cl)
clusterExport_fast(cl, c("cgy.df", "all.grps", "dep.var",
                               "contr.vars", "fe.vars", "clust.vars"))

## Model (with fixest)
bs.df <- foreach(b = 1:1000,
                 .packages = c("fixest", "plyr"),
                 .combine = rbind,
                 .noexport = c("cgy.df", "all.grps", "model", "these.grps", "this.df")) %dopar% {
                   ## Sample groups
                   set.seed(b)
                   these.grps <- sample(all.grps, size = length(all.grps), replace = T)
                   this.df <- data.frame(group = these.grps)
                   colnames(this.df) <- clust.vars
                   this.df <- plyr::join(this.df,
                                         cgy.df[cgy.df$is.capitalrulegrp == 0,], 
                                         type = "left", match = "all", by = clust.vars)
                   
                   ## Model (with fixest)
                   model <- fixest::feols(as.formula(paste(dep.var, "~",
                                                           paste(c("log(1+prec.homerule.yrsavg)*tek.status", 
                                                                   contr.vars), 
                                                                 collapse = " + ") ,
                                                           "|", paste(fe.vars, collapse = " + ")
                   )),  data = this.df)
                   
                   ## Fake data
                   fake.df <- raw.df <- unique(cgy.df[cgy.df$is.capitalrulegrp == 0, 
                                                      c("prec.homerule.yrsavg", "tek.status")])
                   fake.df$tek.statusTEK <- ifelse(fake.df$tek.status == "TEK", 1, 0)
                   fake.df$tek.statusTEKCAP <- ifelse(fake.df$tek.status == "TEKCAP", 1, 0)
                   fake.df$`log(1 + prec.homerule.yrsavg)` <- log(1 + fake.df$prec.homerule.yrsavg)
                   fake.df$`log(1 + prec.homerule.yrsavg):tek.statusTEK` <- fake.df$`log(1 + prec.homerule.yrsavg)`  * fake.df$tek.statusTEK
                   fake.df$`log(1 + prec.homerule.yrsavg):tek.statusTEKCAP` <- fake.df$`log(1 + prec.homerule.yrsavg)`  * fake.df$tek.statusTEKCAP
                   fake.df <- fake.df[, -c(1,2)]
                   
                   
                   ## Predict (relative to 0,0)
                   pred <- rowSums(t(t(as.matrix(fake.df)) * as.vector(model$coefficients[colnames(fake.df)])))
                   
                   ## Plot
                   iter.df <- cbind(raw.df, fake.df)
                   iter.df$obs <- 1:nrow(iter.df)
                   iter.df$pred <- pred
                   iter.df$iter <- b
                   
                   ## Return
                   return(iter.df)
                 }

## Collapse
sum.bs.df <- bs.df %>% 
  group_by(obs) %>%
  summarise(ub = quantile(pred, .975, na.rm = T),
            ub10 = quantile(pred, .95, na.rm = T),
            lb = quantile(pred, .025, na.rm = T),
            lb10 = quantile(pred, .05, na.rm = T))
sum.bs.df <- sum.bs.df[order(sum.bs.df$obs),]

## Plot
plot.df <- cbind(raw.df, fake.df, sum.bs.df)
plot.df$pred <- pred
plot.df$se <- se

## Adjust labels
plot.df$labels <- ifelse(plot.df$tek.status == "TEK",
                         "Non-dominant TEK", 
                         ifelse(plot.df$tek.status == "TEKCAP",
                                "Dominant TEK",
                                "No TEK"))

bs.plot.df <- plot.df

## Combined Plot
set.seed(1)
g <- ggplot(main.plot.df, aes(x = log(1+prec.homerule.yrsavg), y = pred)) + 
  geom_hline(aes(yintercept = 0), col = "grey", lty = 2) +
  geom_text(data = cgy.df[cgy.df$is.capitalrulegrp == 0,],
            aes(y = -.25), label = "|", alpha = .05,position=position_jitter(width=.05,height=0)) +
  geom_line() +
  geom_ribbon(aes(ymin=pred + 1.96*se,
                  ymax=pred - 1.96*se),alpha=0.15) +
  geom_line(data = main.plot.df, 
            aes(y = pred + 1.96*se, lty = "95% CI from clustered SEs"), col = "black") +
  geom_line(data = main.plot.df, 
            aes(y = pred - 1.96*se, lty = "95% CI from clustered SEs"), col = "black") +
  geom_ribbon(data = bs.plot.df,
              aes(ymin=lb,
                  ymax=ub),alpha=0.15) +
  geom_line(data = bs.plot.df, 
            aes(y = lb, lty = "95% CI from bootstrap"), col = "black") +
  geom_line(data = bs.plot.df, 
            aes(y = ub, lty = "95% CI from bootstrap"), col = "black") +
  scale_linetype_manual(values = c(2,3),
                        # labels = c("clustered SEs", "bootstrap"),
                        name = "") +
  facet_wrap(~tek.status, nrow = 1, labeller = function(x){
    lapply(x, function(i){
      c(INSULAR = "No TEK", TEK = "Non-dominant TEK", TEKCAP = "Dominant TEK")[i]
    })
  }) + 
  scale_x_continuous(breaks = log(1+c(0,2,5,10,25,50,100)),
                     labels = c(0,2,5,10,25,50,100)) +
  labs(y = "Change in P(ethnic cleansing)",
       x = "Years of Past Home Rule") +
  theme_minimal()+
  theme(panel.spacing = unit(1.5, "lines"),
        legend.position = "bottom", legend.justification = 1)


png("results/figures/figure_7.png", 
    width = 6, height = 3, res = 600, units = "in")
print(g)
dev.off()

# Stop Cluster
stopCluster(cl)
