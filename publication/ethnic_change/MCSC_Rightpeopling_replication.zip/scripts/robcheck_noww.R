#######################################
# REPLICATION FILE 
#
# --- Robustness: No world wars ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

#############################
# ROBCHECKS: NO WORLD WARS
#############################

## Stub
stub <- "table_A7"


## Prep specification
these.treat <- list(c("tek.status"),
                    c("log(1+prec.homerule.yrsavg)"),
                    c("tek.status", "log(1+prec.homerule.yrsavg)"),
                    c( "log(1+prec.homerule.yrsavg)*tek.status"))

# these.treat <- c(these.treat, 
#                  list(unlist(these.treat)))
form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(contr.vars), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = fe.vars, 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0 &
                          !cgy.df$year %in% c(1939:1945, 1914:1918),])
})

# Prepare Table
add.lines <- list(latex.addline("Country FE:", rep("yes", length(model.ls))),
                  latex.addline("Year FE:", rep("yes", length(model.ls))),
                  latex.addline("Controls:", rep(c("yes"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic cleansing 1886--2020, w/out World Wars",
                     keep = c("tek.status", "homerule"),
                     # type = "text",
                     multicolumn = F,
                     column.labels = "Ethnic cleansing (0/100)",
                     column.separate = length(model.ls), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Non-dominant TEK", 
                                          "Dominant TEK",
                                          "Past home rule (yrs, log)", 
                                          "Non-dominant TEK x past home rule",
                                          "Dominant TEK x past home rule"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser") ,
                     notes = latex.notes(.85),
                     notes.label = "", notes.append = F
), 
fileConn)
close(fileConn)
