#######################################
# REPLICATION FILE 
#
# --- Main analysis ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################


# SUMMARY STATS ##################

stub <- "table_A1"

vars <- c(dep.var, 
          "Dominant TEK" = "tek.titular", 
          "Non-dominant TEK" = "tek.nontitular", 
          "Past home rule" = "prec.homerule.yrsavg",
          contr.vars)
vars <- sapply(vars, function(v){
  all.vars(as.formula(paste("~", v)))
})

fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(cgy.df[cgy.df$is.capitalrulegrp == 0,
                            vars],
                     title="Summary Statistics",
                     keep = vars,
                     digits = 1,
                     covariate.labels = names(vars),
                     column.sep.width = "-12pt",
                     font.size = "scriptsize",
                     omit.summary.stat = c("p25", "p75", "median"),
                     align =T,
                     label=stub
), 
fileConn)
close(fileConn)


# MAIN TABLE #####################

## Stub
stub <- "table_1"

## Prep specification
these.treat <- list(c("tek.status"),
                    c("log(1+prec.homerule.yrsavg)"),
                    c("tek.status", "log(1+prec.homerule.yrsavg)"),
                    c( "log(1+prec.homerule.yrsavg)*tek.status"))
form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(contr.vars), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = fe.vars, 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0,], keepX = T)
})

# Wald Test difference
test1 <- linearHypothesis(model.ls[[1]], c("tek.statusTEK = tek.statusTEKCAP"))
print(test1)

test3 <- linearHypothesis(model.ls[[3]], c("tek.statusTEK = tek.statusTEKCAP"))
print(test3)

test4 <- linearHypothesis(model.ls[[4]], c("tek.statusTEK = tek.statusTEKCAP"))
print(test4)

# Wald Test sum
test1 <- linearHypothesis(model.ls[[1]], c("tek.statusTEK + tek.statusTEKCAP = 0"))
print(test1)

test3 <- linearHypothesis(model.ls[[3]], c("tek.statusTEK + tek.statusTEKCAP = 0"))
print(test3)

test4 <- linearHypothesis(model.ls[[4]], c("tek.statusTEK + tek.statusTEKCAP = 0"))
print(test4)

# Prepare Table
add.lines <- list(latex.addline("Country FE:", rep("yes", length(model.ls))),
                  latex.addline("Year FE:", rep("yes", length(model.ls))),
                  latex.addline("Controls:", rep(c("yes"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic cleansing 1886--2020 (OLS): TEK Links and Past Home Rule",
                     keep = c("tek.status", "homerule"),
                     # type = "text",
                     multicolumn = F,
                     column.labels = "Ethnic cleansing (0/100)",
                     column.separate = length(model.ls), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Non-dominant TEK", 
                                          "Dominant TEK",
                                          "Past home rule (yrs, log)", 
                                          "Non-dominant TEK x past home rule",
                                          "Dominant TEK x past home rule"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser") ,
                     notes = latex.notes(.8),
                     notes.label = "", notes.append = F
                     ), 
           fileConn)
close(fileConn)



# TEK Link to enemy with claim / at war

## Stub
stub <- "table_2"

## Prep specification
these.treat <- list(c("I(terrclaim>0)"),
                    c("has.tek", "I(terrclaim>0)", "tek.5col.claim"),
                    c("I(WarNum>0)"),
                    c("has.tek", "I(WarNum>0)", "tek.5col"))
these.treat <- c(these.treat, 
                 list(unlist(these.treat)))

form.ls <- unlist(lapply(these.treat, function(t){
  lapply(list(contr.vars), function(c){
    make_form(dv = dep.var, 
              expl = c(t, c), 
              fe = fe.vars, 
              iv = "0", se = clust.vars )
  })
}))

## Estimate
model.ls <- lapply(form.ls, function(f){
  felm(f, data = cgy.df[cgy.df$is.capitalrulegrp == 0,])
})

# Prepare Table
add.lines <- list(latex.addline("Country FE:", rep("yes", length(model.ls))),
                  latex.addline("Year FE:", rep("yes", length(model.ls))),
                  latex.addline("Controls:", rep(c("yes"), length(model.ls))),
                  latex.mean.dv(model.ls))

# Save Table
fileConn <- file(file.path(tab.path, paste0(stub,".tex")))
writeLines(stargazer(model.ls,
                     title="Ethnic cleansing 1886--2020 (OLS): TEK, Territorial Claims, and Interstate Wars",
                     keep = c(unique(unlist(these.treat)), "WarNum", "terrclaim"),
                     multicolumn = F,# se = se,
                     column.labels = "Ethnic cleansing (0/100)",
                     column.separate = c(5), column.sep.width ="-10pt",
                     dep.var.caption = "",dep.var.labels = rep("", length(model.ls)),
                     covariate.labels = c("Has TEK",
                                          "Terr. claims$_{t-1}$", "Claims from state w/ TEK",
                                          "Interstate war$_{t-1}$", "War with state w/ TEK"),
                     font.size = "scriptsize",
                     star.char = star.char,
                     notes.align = "c", label=stub, align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     notes = latex.notes(.8), 
                     notes.label = "", notes.append = F), 
           fileConn)
close(fileConn)

