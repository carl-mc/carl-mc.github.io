#######################################
# REPLICATION FILE 
#
# --- Full HEG Map ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################


# Data load ####################

## Main dataset extent
ext.poly <- st_read(file.path("data/heg_extent_main.geojson"))

## HEG colored points
plot.pts <- readRDS("data/heg_map_points.rds")


# PLOT ########

# Years
plot.yrs <- c(1890, 2020)

# Make one plot per year
for(y in plot.yrs){
  print(y)
  plot.df <- plot.pts[plot.pts$year == y,]
  
  png(file.path(fig.path, paste0("figure_5_", y, ".png")), 
      width = 7, height = 5, res = 400, units = "in")
  par(mar = c(0,0,1,0))
  plot(as_Spatial(ext.poly), border = "grey",
       main = paste0(y))
  points(plot.df$x, plot.df$y, 
         col = plot.df$color,
         pch = ".", cex = 1
  )
  dev.off()
}

