#######################################
# REPLICATION FILE 
#
# --- Libraries ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################



# All libraries needed
libraries <- c(
  "lfe", "stargazer","ggplot2","plyr","dplyr","car", "tidyverse",
  "MASS", "broom", "fixest", "countrycode", "rasterVis", "raster",
  "rgeos", "rgdal", "viridis", "viridisLite", "devtools", "sf", "foreach","doParallel",
  "wesanderson", "Rcpp","ggrepel", "scales", "readstata13", "cshapes"
)

# Missing libraries
lib.miss <- libraries[!libraries %in% installed.packages()[,"Package"]]

# Print
if(length(lib.miss) > 0){
  print(paste("Installing the following", length(lib.miss), "packages:", 
              paste(lib.miss, collapse = "; ")))
}

if(length(lib.miss) > 0){
  # Install
  install.packages(lib)
  
  # Message
  fails <- libraries[!libraries %in% installed.packages()[,"Package"]]
  message(paste("Successfully installed", length(lib.miss) - length(fails), "packages."))
  if(length(fails) > 0){
    warning(paste("Failed to install the following", length(fails), "packages:", 
                  paste(fails, collapse = "; ")))
  }
} else {
  message(paste("All packages installed. "))
}

