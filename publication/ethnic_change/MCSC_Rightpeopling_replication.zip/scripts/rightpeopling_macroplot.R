#######################################
# REPLICATION FILE 
#
# --- State to nation alignment ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################


# PREPARE DATA ################
for(TV in c("", "_tv")){
  # Load data
  all.homog.df <- readRDS(paste0("data/sys_homogeneity", TV, ".rds"))
  
  # Summary
  all.homog.df <- aggregate.data.frame(list(value = all.homog.df$value * all.homog.df$weight),
                                       by = all.homog.df[, c("type", "cs.year", "heg.year")],
                                       FUN = sum)
  
  # Change to homogeneity
  all.homog.df[all.homog.df$type %in% c("Ethnic fractionalization"   ,
                                        "Territorial fractionalization"), "value"] <- 
    1 - all.homog.df[all.homog.df$type %in% c("Ethnic fractionalization",
                                              "Territorial fractionalization"), "value"]
  all.homog.df$type[all.homog.df$type == "Ethnic fractionalization" ] <-  "Ethnic homogeneity"
  all.homog.df$type[all.homog.df$type == "Territorial fractionalization" ] <-  "Territorial unity"

  # Types
  types <- c(ethfrac = "Ethnic homogeneity"   ,   
             minorm =  "Normalized Mutual Information" , 
             terrfrac = "Territorial unity")
  
  ## Plot DF List
  plot.df.ls <- list()
  
  for(t in types){
    # Subset data
    homog.df <- all.homog.df[all.homog.df$type == t,]
    
    # Years
    years <- unique(homog.df$heg.year)
    
    #' Total change
    #' D cs_t  - cs_t-1, heg_t  - heg_t+1
    total.diff <- unlist(sapply(years, function(y){
      homog.df$value[homog.df$heg.year == y &
                       homog.df$cs.year == y] - 
        homog.df$value[homog.df$heg.year == y - 1 &
                         homog.df$cs.year == y - 1]
      
    }))
    
    #' Border change:
    #' D cs_t  - cs_t-1, heg_t-1
    border.diff <- unlist(sapply(years, function(y){
      homog.df$value[homog.df$heg.year == y - 1 &
                       homog.df$cs.year == y] - 
        homog.df$value[homog.df$heg.year == y - 1 &
                         homog.df$cs.year == y - 1]
      
    }))
    
    #' Ethnic change:
    #' D heg_t  - heg_t-1, cs_t-1
    ethnic.diff <- unlist(sapply(years, function(y){
      homog.df$value[homog.df$heg.year == y &
                       homog.df$cs.year == y - 1] - 
        homog.df$value[homog.df$heg.year == y - 1 &
                         homog.df$cs.year == y - 1]
      
    }))
    
    
    # Combine
    diff.df <- data.frame(year = years[-1], 
                          total = homog.df$value[homog.df$heg.year == homog.df$cs.year][-1],
                          xtotal = total.diff,
                          xborder = border.diff,
                          xethnic = ethnic.diff)

   
    ## Save plot dta
    plot.df.ls[[t]] <- cbind(diff.df, 
                             type = rep(t, nrow(diff.df)))
  }
  
  ## Combined
  
  ### Combine data
  plot.df <- do.call(rbind, plot.df.ls)
  
  ### Types
  plot.df$typef <- factor(plot.df$type, levels = c("Normalized Mutual Information",
                                                   "Ethnic homogeneity",
                                                   "Territorial unity"), 
                          labels = c(
                            "Mutual Information",
                            "Ethnic homogeneity",
                                     "Territorial unity"), 
                          ordered = T)
  
  ### Absolute levels
  p <- ggplot(plot.df, aes(x = year, y = total, group = typef)) +
    geom_line(aes(lty = typef)) +
    theme_minimal() +
    theme(legend.position = "top") +
    scale_color_discrete() +
    # geom_hline(yintercept = 0, lty = 2, col = "grey") +
    xlab("Year") + labs(color = "") +
    ylab("State to Nation Alignment") +
    scale_x_continuous(breaks = seq(1880, 2020, by = 20)) +
    guides(lty=guide_legend(nrow=2, title = NULL)) +
    NULL
  
  ### save
  ggsave(file.path(fig.path, paste0("figure_", ifelse(TV == "", "A2", "8a"), ".png")), p,
         device = "png", width = 4, height = 3.5, 
         bg = "white",
         units = "in", dpi = 400)
  
  
  ## Changes
  ch.df <- do.call(rbind, lapply(plot.df.ls, function(p){
    p %>%
      arrange(year) %>%
      mutate(type = NULL,
             xtotal = cumsum(xtotal),
             xborder = cumsum(xborder),
             xethnic = cumsum(xethnic)) %>%
      mutate(xrest = xtotal - (xethnic + xborder)) %>%
      pivot_longer(cols = c(-year, -total, -xtotal)) %>%
      mutate(type = unique(p$type))
  }))
  
  ### Types
  ch.df <- ch.df %>% 
    filter(type %in% c("Normalized Mutual Information"))

  ### Print stat
  print(ch.df[ch.df$year == 2020,])
  
  ### Make plot
  p <- ggplot(ch.df, aes(x = year, y = value)) +
    geom_bar(stat = "identity", aes(fill = name)) +
    theme_minimal() +
    scale_fill_manual(name = "", 
                        labels = c( "... through border change", 
                                    "... through ethnic change  ", 
                                    ""),
                        values = c(grey(c(.75, .25)), "white")) +
    
    theme(legend.position = "top") +
    geom_hline(yintercept = 0, lty = 2, col = "grey") +
    xlab("Year") + ylab("Cumulative Change in \n Mutual Information") +
    scale_x_continuous(breaks = seq(1880, 2020, by = 20)) +
    NULL
  
  ## Save
  ggsave(file.path(fig.path, paste0("figure_", ifelse(TV == "", "A3", "8b"), ".png")), p,
         device = "png", width = 5, height = 2.7, 
         bg = "white",
         units = "in", dpi = 400)
  
  
}
