#######################################
# REPLICATION FILE 
#
# --- Descriptive Maps and Plots ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

######################################
# DESCRIPTIVE PLOTS 
######################################

# CLEANSING: VICTIMS & AFFECTED ######

## Load list of ethnic cleansing events
eth.cleans.df <- read.csv("data/ethnic_cleansing_list.csv")

## Set lower bound for missing casualty estimate
eth.cleans.df$pop_est[eth.cleans.df$pop_est == -88] <- 1000

## Save estimated affected population
writeLines(as.character(round(sum(as.numeric(eth.cleans.df$pop_est)) / 1e6)),
           con = file.path(num.path, "num_ethcleanvictims.tex"))

writeLines(as.character(round(sum(cgy.df$grpsize[cgy.df$ethcl_onset == 1 & !is.na(cgy.df$ethcl_onset)]) / 1e6)),
           con = file.path(num.path, "num_ethcleanaffected.tex"))


# DESCRIPTIVE NUMBERS ################

# Observations & country-years
writeLines(as.character(nrow(cgy.df)),
           con = file.path(num.path, "num_segmentyrs.tex"))
writeLines(as.character(length(unique(cgy.df$group))),
           con = file.path(num.path, "num_groups.tex"))
writeLines(as.character(nrow(unique(cgy.df[, c("gwcode", "year")]))),
           con = file.path(num.path, "num_countryyrs.tex"))



# OUTCOME DATA OVER TIME #############


# Data
onset.df <- cgy.df[cgy.df$ethcl_onset == 1 & !is.na(cgy.df$ethcl_onset),]

# Plot 
g <- ggplot(onset.df, aes(x = floor(year/5)*5+2.5)) +
  geom_bar() + 
  scale_y_continuous(name = "Onsets of ethnic cleansing") +
  scale_x_continuous(name = "Year (5-year periods)", 
                     breaks = seq(1880, 2020, by = 20),
                     limits = c(1880, 2025),
                     NULL
                     ) +
  theme_minimal() 
png(file.path(fig.path, "figure_8.png"), width = 7, height = 2.5, res = 400, units = "in")
print(g)
dev.off()

# Numbers
writeLines(as.character(nrow(onset.df)),
           con = file.path(num.path, "num_genocint.tex"))
writeLines(as.character(round(sum(onset.df$grpsize)/1e6)),
           con = file.path(num.path, "pop_genocint.tex"))
writeLines(as.character(round(sum(onset.df$grpsize[!duplicated(onset.df[, c("group", "gwcode")])])/1e6)),
           con = file.path(num.path, "pop_genocint_nodupl.tex"))



# TIMELINE OF MAPS ###################


# Load Metadata
eth.meta.df <- read.csv("data/heg_meta.csv")

# Plot
g <- ggplot(eth.meta.df, aes(x = floor(year_data_end/5)*5+2.5)) +
  geom_bar() + 
  scale_y_continuous(breaks = seq(0,10, by = 2),
                     name = "Number of maps") +
  scale_x_continuous(name = "Year (5-year periods)", breaks = seq(1840, 2020, by = 20)) +
  theme_minimal() 

# Save
png(file.path(fig.path, "figure_3.png"), width = 7, height = 2.5, res = 400, units = "in")
print(g)
dev.off()


# TIMELINE POLES ##################

# Data
pol.df <- cgy.df[grep("polish", cgy.df$group),]
countries.df <- cgy.df[cgy.df$gwcode %in% pol.df$gwcode,]

# Plot 
g <- ggplot(pol.df, aes(x = year, y = country)) +
  geom_point(data = countries.df, col = "lightgrey", pch = 15) + 
  geom_point(pch = 15) + 
  geom_point(data = pol.df[pol.df$ethcl_onset == 1 | is.na(pol.df$ethcl_onset), ], 
             col = "red", pch = 15) + 
  geom_text_repel(data = pol.df[pol.df$ethcl_onset == 1, ][1,],
            label = "Genocide / Forced displacement", vjust = 0, hjust = 0,
            point.padding = 0.2,
            col = "red", pch = 15, size = 3, direction = "both",
            box.padding = 0.4, min.segment.length = 0.4) +
  scale_x_continuous(name = "Year", breaks = seq(1880, 2020, by = 20)) +
  scale_y_discrete(limits=rev, name = NULL) +
  theme_minimal() 

png(file.path(fig.path, "figure_4b.png"), width = 7, height = 3, res = 300, units = "in")
print(g)
dev.off()


# MAPS POLES ######################

# CShapes
cs <- cshp() %>% sf::as_Spatial()

# Delete small holes
pol.poly.spdf <- readRDS("data/poles_shapes.rds")

# Color
col <- viridis::inferno(2020-1850)


# Plot
png(file.path(fig.path, "figure_4a.png"), width = 10, height = 5, res = 400, units = "in")
par(mar = c(0,0,0,0))
ext = c(14.5, 33, 47.5, 55.5)
plot(as(extent(ext),"SpatialPolygons"), border = "white")
plot(cs[substr(cs$end, 1,4) == 2019, ], add = T, 
     border = "grey", lwd = 2)
plot(pol.poly.spdf, 
     border = alpha(col[2020 - pol.poly.spdf$year_data_start], 0.5), add= T, alpha = 0.6)
dev.off()

# RASTER POLISH ###################

# Load

## Poles, 1918
pol.r1 <- raster("data/poles_1918.tif")

## Poles, 1951
pol.r2 <- raster("data/poles_1951.tif")


# Plot
png(file.path(fig.path, "figure_4c.png"), width = 16, height = 6, res = 400, units = "in")
par(mar = rep(2, 4), mfrow = c(1,2))
ext = c(14.5, 33, 47.5, 55.5)
plot(as(extent(ext),"SpatialPolygons"), border = "white", main = 1918)
plot(pol.r1, add = T, legend = F)
plot(cs[substr(cs$start, 1,4) <= 1918 & substr(cs$end, 1,4) >= 1918, ], add = T, 
     border = "grey", lwd = 2)
plot(raster::crop(pol.r1, extent(ext)), add = T, legend.only = T, horizontal = T)

plot(as(extent(ext),"SpatialPolygons"), border = "white", main = 1951)
plot(pol.r2, add = T, legend = F)
plot(cs[substr(cs$start, 1,4) <= 1951 & substr(cs$end, 1,4) >= 1951, ], add = T, 
     border = "grey", lwd = 2)
plot(raster::crop(pol.r2, extent(ext)), add = T, legend.only = T, horizontal = T)
dev.off()





