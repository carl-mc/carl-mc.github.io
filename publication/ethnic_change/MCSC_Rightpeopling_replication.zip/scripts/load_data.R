#######################################
# REPLICATION FILE 
#
# --- Load main anlysis data ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################

# Country-group year dataset
cgy.df <- readRDS(file.path(data.path, "country_grp_year_analysis.rds"))


## IDs
cgy.df$seg.id <- as.numeric(as.factor(paste0(cgy.df$gwcode, ".", cgy.df$group)))
cgy.df$state.group <- as.numeric(as.factor(paste0(cgy.df$group, ".", cgy.df$gwcode)))
cgy.df$group.yr <- as.numeric(as.factor(paste0(cgy.df$group, ".", cgy.df$year)))
cgy.df$state.yr <- as.numeric(as.factor(paste0(cgy.df$gwcode, ".", cgy.df$year)))

