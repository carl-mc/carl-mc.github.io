#######################################
# REPLICATION FILE
#
# --- Globals ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################



# GLOBALS ############################

## Ncore
ncore <- 10

## Paths
data.path <- "data/"
tab.path <- "results/tables/"
fig.path <- "results/figures/"
num.path <- "results/numbers/"
heg.data.dir <- "data/heg"

## Make directories
dir.create(tab.path, recursive = T)
dir.create(fig.path)
dir.create(num.path)

## Packages
library(lfe)
library(ggplot2)
library(stargazer)
library(plyr)
library(tidyverse)
library(countrycode)
library(fixest)
library(broom)
library(MASS)
library(car)
library(rasterVis)
library(raster)
library(rgeos)
library(rgdal)
library(viridisLite)
library(viridis)
library(sf)
library(wesanderson)
library(foreach)
library(doParallel)
library(ggrepel)
library(scales)
library(readstata13)
library(cshapes)

# FUNCTIONS ##########################
source("scripts/analysis_functions.R")

# MAIN EMPIRICAL SETUP ###############

# Main outcome
dep.var <- c("Ethnic Cleansing Onset" = "I(100*(ethcl_onset_do))")


# Controls
contr.vars <- c("Capital distance" = "log(capitaldistance)",
                "Segment pop." = "log(1 + grpsize)",
                "TEK pop." = "log(1+tek.pop)",
                "Country pop." = "log(1+countrysize)",
                "Altitude" = "altitude",
                "Slope" = "slope",
                "Evapotranspiration" = "evapotransp",
                "Precipitation" = "precipitation",
                "Evap/precip" = "ppetratio",
                "Temperature" = "temperature")


# Error clustering
clust.vars <- "group"

# Main Fixed effects on Country
fe.vars <- c("factor(gwcode)","factor(year)")


# Notes
latex.notes <- function(width = .85, model = "OLS linear models."){
  paste0("\\parbox[t]{",width,"\\textwidth}{\\textit{Notes:} ", model,
         " Sample excludes dominant groups.
         Control variables described in main text.
         Standard errors clustered on the ethnic group level.
         Significance codes: $^{\\dagger}$p$<$0.1; $^{*}$p$<$0.05; $^{**}$p$<$0.01}")}
star.char <- c("\\dagger", "*", "**")

