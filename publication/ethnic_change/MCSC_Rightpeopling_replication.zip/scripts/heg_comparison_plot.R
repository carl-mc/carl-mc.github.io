#######################################
# REPLICATION FILE 
#
# --- HEG Validation: Comparisons among HEG Maps ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################


# Data
data <- readRDS(file.path("data", "compare_heg_df.rds"))

# Drop comparisons to self
data <- data[data$x != data$y,]
data <- data[data$x.terr.tot > 0 & data$y.terr.tot > 0, ]

# Time difference
data$time.diff <- abs(as.numeric(data$x.year) - 
                           as.numeric(data$y.year))
data$time.diff.dec <- round(data$time.diff/10)

# Weights
data <- data %>% 
  group_by(time.diff.dec) %>% 
  mutate(pop.weight.dec = x.pop.tot/sum(x.pop.tot),
         terr.weight.dec = x.terr.tot/sum(x.terr.tot)) %>% 
  ungroup()

# Combined Plot
plot.df <- rbind(cbind(data[!is.na(data$x.in.y.pop),],
                       value = data$x.in.y.pop[!is.na(data$x.in.y.pop)] *100,
                       type = "Population weights",
                       data = "All data"),
                 cbind(data[!is.na(data$x.in.y.terr),],
                       value = data$x.in.y.terr[!is.na(data$x.in.y.terr)] *100,
                       type = "Area weights",
                       data = "All data"))
plot.df <- plot.df[order(plot.df$time.diff.dec, decreasing = T),]
plot.df$grps <- factor(plot.df$time.diff.dec, levels = rev(sort(unique(plot.df$time.diff.dec))),
                       ordered = T)
plot.df$value.w <- ifelse(plot.df$type == "Area weights",
                          plot.df$value * plot.df$terr.weight.dec,
                          plot.df$value * plot.df$pop.weight.dec)


# Plot
g <- ggplot(plot.df, aes(x = value, 
                         col = time.diff.dec,
                         group = grps)) + 
  scale_color_viridis() +
  geom_density(data = plot.df[plot.df$type == "Population weights",], 
               aes(weight=pop.weight.dec)) +
  geom_density(data = plot.df[plot.df$type == "Area weights",], 
               aes(weight=terr.weight.dec)) +
  theme_minimal() +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 2)) +
  facet_grid(data ~ type) +
  labs(col = "Time\ndifference\n(decades)",
       x = "% of group in map X in group in map Y",
       y = "Weighted density") +
  theme(panel.spacing = unit(1, "lines")) +
  NULL
  
# Save
png(file.path(fig.path, "figure_A4.png"), width = 7, height = 3.5, res = 300,
    units = "in")
print(g)
dev.off()

## Means 
weight.df <- plot.df %>% 
  group_by(time.diff.dec, data) %>% 
  summarise(pop.mean = stats::weighted.mean(x.in.y.pop, pop.weight.dec),
            terr.mean = stats::weighted.mean(x.in.y.terr, terr.weight.dec)) 
print(weight.df, n = 1000)


