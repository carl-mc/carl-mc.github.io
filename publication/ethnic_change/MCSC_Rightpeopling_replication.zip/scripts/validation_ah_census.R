#######################################
# REPLICATION FILE 
#
# --- HEG Validation: Austria-Hungary, Census data ---
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################


# Load data
comp.df <- readRDS("data/census_AH_comparison.rds")

# 1910 Data Variation explained
r.df <- na.omit(comp.df[comp.df$Year == 1910,])
r2 <- 1 - sum((r.df$census_prop - r.df$heg_prop)^2) / sum((r.df$census_prop - mean(r.df$census_prop))^2)

writeLines(as.character(100 * signif(r2, 2)), 
           file.path(num.path, "heg_ah_census_r2.tex"))
