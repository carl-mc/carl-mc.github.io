#######################################
# REPLICATION FILE 
#
# "Right-Peopling" the State: Nationalism, Historical Legacies, and Ethnic Cleansing in Europe, 1886-2020
# Carl Müller-Crepon, Guy Schvitz, Lars-Erik Cederman
# November 2023
#
# Forthcoming, Journal of Conflict Resolution
#######################################



# Clean working environment
rm(list = ls())

# Set working directory to root of replication repository
# setwd("replication")

# Libraries
source("scripts/libraries.R")

# Globals
source("scripts/globals.R")

# Load data
source("scripts/load_data.R")

# ANALYSIS ############################

# Main analysis
source("scripts/analysis_main.R")

# Bootstrap and interaction plot
source("scripts/analysis_groupboot.R")

# Heterogeneity by democracy
source("scripts/heter_vdem.R")

# Robustness check: Controls
source("scripts/robcheck_controls.R")

# Robustness check: drop World Wars
source("scripts/robcheck_noww.R")

# Robustness check: Fixed effects
source("scripts/robcheck_fixeffs.R")

# Robustness check: Logit estimation
source("scripts/robcheck_logit.R")

# Randomization inference
source("scripts/robcheck_randinf.R")


# DATA DESCRIPTION / VALIDATION ####

# Plot: HEG Map
source("scripts/map_heg_all.R")

# Plot: single maps and timeline
source("scripts/maps_descr.R")

# Validation: AH census data
source("scripts/validation_ah_census.R")

# Validation: Fearon's list
source("scripts/validation_fearon.R")

# Validation: among HEG maps
source("scripts/heg_comparison_plot.R")

# MAKING OF NATION-STATES #########
source("scripts/rightpeopling_macroplot.R")

# Clean working environment
rm(list = ls())
