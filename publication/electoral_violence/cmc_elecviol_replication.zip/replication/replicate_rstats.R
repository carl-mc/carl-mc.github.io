###########################################
# Local Ethno-Political Polarization and Election Violence in 
#         Majoritarian vs. Proportional Systems
#
# Replication
#
# Carl Müller-Crepon, JPR, 2020
#
# Email: carl.muller-crepon@politics.ox.ac.uk
#
###########################################
rm(list = ls())


# Setup ############

# Working Directory
setwd("stuff/electoral_violence/replication")

# Make empty tables / figure directories
#  (for full check, delete these before running replication)
dir.create(file.path("results", "figures"),
           recursive = T, showWarnings = F)
dir.create(file.path("results","tables"),
           recursive = T, showWarnings = F)

# Install missing packages
source("scripts/install_pkgs.R")


# Replicate all ###

# Riot analysis
rm(list = ls())

## Number of CPUs on your machine
ncore <- 40

## Run
source("scripts/analysis_riots.R")

# Afrobarometer analysis
rm(list = ls())
source("scripts/analysis_ab.R")
