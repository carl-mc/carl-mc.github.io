#####################################
# PRE-ELECTION RIOTS AND ETHNO-POLITICAL POLARIZATION: PLOTS

# Carl Müller-Crepon,
# 24.4.2018
#####################################


# Kenya map with EPR polarization #####
#   Produces Figure 1

# Admin units

# ... color palette
colpal <- colorRampPalette(c("white","orange","red3"),space = "Lab")(256)

# ... data: Lakes
lakes.ken <- readOGR(file.path("data", "shapefiles"),
                 "kenya_lakes")

# ... data: Kenya Boundaries
kenya.shp <- readOGR(file.path("data", "shapefiles"),
                     "kenya_adm0")

# ... data: Admin units
adm2.spdf <- readOGR(file.path("data", "shapefiles"),
                     "kenya_adm2")
adm2.spdf$id.new <- adm2.spdf$id_new
colnames(adm2.spdf@data) <- tolower(colnames(adm2.spdf@data))
adm2.spdf@data <- join(adm2.spdf@data, ts[ts$year==2007 & ts$month==1 & ts$cowcode==501, 
                                          c("id.new","cowcode","adm1_code",
                                            "adm2_code", "epr.polar")],
                       by = c("id.new","cowcode","adm1_code", 
                              "adm2_code"), match = "first")


# ... plot admin units
png(paste0(fig.path,"figure1b.png"), width = 4, height=4, units = "in", res = 300)
print(spplot(adm2.spdf , "epr.polar", xlim = c(33,42), ylim=c(-4.8,5),
       sp.layout = list(list("sp.polygons",lakes.ken, col =c("white"), fill= "white",cex=3, first=FALSE)),
       par.settings =
         list(axis.line = list(col =  'transparent'),fontsize=list(text=20)),
       col.regions = colpal, at = seq(0,1.01,length=256),colorkey = list(space = 'right'), col="white") )
dev.off()

# Constituencies

# ... load data
kenya.const.spdf <- readOGR(file.path("data", "shapefiles"),
                            "kenya_const")
kenya.const.spdf$id.new <- kenya.const.spdf$id_new

# ... add polarization
kenya.const.spdf@data <- join(kenya.const.spdf@data, 
                              ts.kenya[ts.kenya$year==2007 & ts.kenya$month==1, 
                                       c("id.new","cowcode","adm1_code",
                                         "adm2_code", "epr.polar")],
                              by = c("id.new"), type = "left", match = "first")

# ... plot constituencies
png(paste0(fig.path,"figure1a.png"), width = 4, height=4, units = "in", res = 300)
print(spplot(kenya.const.spdf , "epr.polar", xlim = c(33,42), ylim=c(-4.8,5),
             sp.layout = list(list("sp.polygons",lakes.ken, col =c("white"), fill= "white",cex=3, first=FALSE)),
             par.settings =
               list(axis.line = list(col =  'transparent'),fontsize=list(text=20)),
             col.regions = colpal, at = seq(0,1.01,length=256),colorkey = list(space = "left"), col="white") )
dev.off()

# Comparison scatter plot

# ... spatial merge of data
comp <- gIntersection(adm2.spdf,kenya.const.spdf,byid=TRUE)
comp.data <- data.frame(id = getSpPPolygonsIDSlots(comp), stringsAsFactors = FALSE)
id.split <- cSplit(comp.data, "id", " ")
comp.data$id.adm <- id.split$id_1
adm2.spdf@data$id.adm <- getSpPPolygonsIDSlots(adm2.spdf)
comp.data <- join(comp.data, adm2.spdf@data[, c("id.adm","epr.polar")], 
                  by = "id.adm", type = "left")
colnames(comp.data)[colnames(comp.data)=="epr.polar"] <- "adm.epr.polar"
comp.data$id.const <- id.split$id_2
kenya.const.spdf$id.const <- getSpPPolygonsIDSlots(kenya.const.spdf)
comp.data <- join(comp.data, 
                  kenya.const.spdf@data[, c("id.const","epr.polar")], 
                  by = "id.const", type = "left")
colnames(comp.data)[colnames(comp.data)=="epr.polar"] <- "const.epr.polar"

comp.data$area.km2 <- areaPolygon(comp,byid=TRUE) / 10^6           

# ... keep only biggest intersecting part
comp.data$id.new <- id.split$id_2
agg.comp <- aggregate.data.frame(comp.data$area, list(comp.data$id.new), max)
colnames(agg.comp) <- c("id.new","area.km2")
agg.comp$biggest <- 1
comp.data <- join(comp.data,agg.comp, type="left",
                  by = c("id.new", "area.km2"))
plot.data <- comp.data[!is.na(comp.data$biggest),]

# ... regression line preparation
reg <- lm(adm.epr.polar ~ 0 + const.epr.polar, data=plot.data)
r2 <- paste0("italic(R) ^ 2 ==",round_any(summary(reg)$r.squared,0.01))


# ... plot
png(paste0(fig.path,"figure1c.png"), width = 2.5, height=2.5, units = "in", res = 300)
print(ggplot(plot.data, aes(x = adm.epr.polar, y = const.epr.polar)) + 
  geom_point(alpha = .3) + geom_abline(slope = reg$coefficients) + theme_minimal() +
  xlab("District-level ethno-political\npolarization") + 
  ylab("Constituency-level\nethno-political polarization") +
  xlim(0,1) + ylim(0,1) + 
  annotate("text", x = .02, y = .95, label = paste0("Coef = ",round_any(reg$coefficients,0.001)), hjust = 0) +
  annotate("text", x = .02, y = .8, label = r2, parse = TRUE, hjust = 0) )
dev.off()


# Simple discriptive plot ###########
#   Produces Figure 3

# ... prepare data

# ... ---- Average polarization
mean.pol <- mean(ts$epr.polar[ts$majoritarian==1], na.rm =T)

# ... ---- Monthly riots above avg
m.riots.p <- aggregate.data.frame(ts$scad.riot.count[ts$majoritarian==1 & ts$epr.polar>=mean.pol], 
                                  list(ts$time.to.leg.elec[ts$majoritarian==1 & ts$epr.polar>=mean.pol]), 
                                  mean)
colnames(m.riots.p) <- c("time.to.leg.elec", "scad.riot.count")
m.riots.p$time.to.leg.elec <- 1/m.riots.p$time.to.leg.elec - 1
m.riots.p <- m.riots.p[m.riots.p$time.to.leg.elec <=24,]

# ... ---- Monthly riots below avg
m.riots.np <- aggregate.data.frame(ts$scad.riot.count[ts$majoritarian==1 & ts$epr.polar<mean.pol], 
                                   list(ts$time.to.leg.elec[ts$majoritarian==1 & ts$epr.polar<mean.pol]),
                                   mean)
colnames(m.riots.np) <- c("time.to.leg.elec", "scad.riot.count")
m.riots.np$time.to.leg.elec <- 1/m.riots.np$time.to.leg.elec - 1
m.riots.np <- m.riots.np[m.riots.np$time.to.leg.elec <=24,]

# ... plot
png(file=paste0(fig.path,"figure3.png"), width = 6, height=3, units = "in", res = 300)
print(ggplot(m.riots.p, aes(x = time.to.leg.elec, y = scad.riot.count,
                            group = "> mean ethno-political polarization",
                            lty = "> mean ethno-political polarization")) + 
        geom_line() + theme_minimal() +
        geom_line(data = m.riots.np, aes(group = "< mean ethno-political polarization",
                                         lty = "< mean ethno-political polarization")) +
        scale_x_reverse() + scale_linetype_discrete(name = NULL) + 
        theme(legend.position="bottom",legend.direction="vertical") +
        ylab("Average number of riots") + xlab("Months to legislative election") +
        guides(lty=guide_legend(nrow=1,byrow=TRUE)))

dev.off()



# Time line by country #########
#   Produces Figure A1

# ... load afrobarometer data
ab.fin.df <- readRDS(file.path("data", "afrobarometer.rds"))

# ... prepare time line
ts.sub <- ts[!is.na(ts$epr.polar) & !is.na(ts$time.to.leg.elec) & !is.na(ts$majoritarian),
             c("country","cowcode","year","map.from",
               "time.to.leg.elec", "epr.polar", "scad.riot.count")]
cow.time.df <- data.frame(matrix(0,nrow=length(unique(ts.sub$country))*(2013-1989), ncol=4))

colnames(cow.time.df) <- c("country","year","election","map")
cow.time.df$country <- rep(unique(ts.sub$country), each=2013-1989)
cow.time.df$cowcode <- rep(unique(ts.sub$cowcode), each=2013-1989)
cow.time.df$year <- rep(c(1990:2013), length(unique(ts.sub$country)))

# ... code variables by country
for(c in unique(ts$cowcode)){
  cow.time.df$election[cow.time.df$cowcode==c & cow.time.df$year %in% 
                         unique(ts$year[ts$cowcode==c & ts$time.to.leg.elec==1])] <-1
  cow.time.df$majelec[cow.time.df$cowcode==c & cow.time.df$year %in% 
                        unique(ts$year[ts$cowcode==c & ts$time.to.leg.elec==1 & 
                                         ts$majoritarian==1 & ts$pr.wb == 0])] <-1
  cow.time.df$mixelec[cow.time.df$cowcode==c & cow.time.df$year %in% 
                        unique(ts$year[ts$cowcode==c & ts$time.to.leg.elec==1 & 
                                         ts$majoritarian==1 & ts$pr.wb == 1])] <-1
  cow.time.df$prelec[cow.time.df$cowcode==c & cow.time.df$year %in% 
                       unique(ts$year[ts$cowcode==c & ts$time.to.leg.elec==1 & 
                                        ts$majoritarian==0 & ts$pr.wb == 1])] <-1
  cow.time.df$map[cow.time.df$cowcode==c & cow.time.df$year %in% 
                    unique(ts$year[ts$cowcode==c & ts$year >= ts$map.from])] <-1
  cow.time.df$ab[cow.time.df$cowcode==c & cow.time.df$year %in% 
                   unique(ab.fin.df$year[ab.fin.df$cowcode==c & 
                                           !is.na(ab.fin.df$epr.polar)])] <-1
}
cow.time.df <- cow.time.df[order(cow.time.df$country),]
cow.time.df$n <- rep(c(length(unique(ts.sub$country)):1), each=2013-1989)

# ... print plot
png(paste0(fig.path,"figurea1.png"), width = 7.5, height=9, units = "in", res = 300)
par(mar = c(5, 10.5, 4, 2))  

# ... --- empty plot
plot(NA, xlim=c(1989,2014),
     bty='n',yaxt="n", xaxt="n", ylab="", xlab="Year", col="black", ylim = c(0,29))

# ... --- 
for(c in unique(cow.time.df$n)){
  segments(1990, c, 2013,c,col = "gray")
  segments(min(cow.time.df$year[cow.time.df$n==c & cow.time.df$map==1]),c,2013,c, col="lightgray", lwd=8)
}

# ... --- elections
points(cow.time.df$year[cow.time.df$prelec==1 ],cow.time.df$n[ cow.time.df$prelec==1], 
       pch=3, col="black")
points(cow.time.df$year[cow.time.df$majelec==1 ],cow.time.df$n[cow.time.df$majelec==1 ], 
       col="black", pch = 4)
points(cow.time.df$year[cow.time.df$mixelec==1 ],cow.time.df$n[cow.time.df$mixelec==1], 
       col="black", pch = 8)

# ... --- surveys
points(cow.time.df$year[cow.time.df$ab==1],cow.time.df$n[cow.time.df$ab==1], 
       col="black", pch = 1, cex = 1.5)
points(cow.time.df$year[cow.time.df$cowcode %in% ab.fin.df$cowcode[ab.fin.df$round == 6] & cow.time.df$year == 2013] + 1,
       cow.time.df$n[cow.time.df$cowcode %in% ab.fin.df$cowcode[ab.fin.df$round == 6] & cow.time.df$year == 2013]+0.0, 
       col="black", pch = 16, cex = 1.5)

# ... --- Legends and axes
axis(1, at=c(seq(1990, 2010, length.out = 5),2013))
labs <- unique(cow.time.df$country)
axis(2, at=unique(cow.time.df$n), labels=labs, las=1, tick=F, lwd=0, pos=1990)
points(2013, 26.5, pch = 3, col="black")
text(2012, 26.5, labels="PR election", pos=2, cex = 0.9)
points(2013, 28.5, pch = 4, col="black")
text(2012, 28.5, labels="Majoritarian election", pos=2, cex = 0.9)
points(2013, 27.5, pch = 8, col="black")
text(2012, 27.5, labels="Mixed election", pos=2, cex = 0.9)
points(2013, 25.5, pch = 1, col="black", cex =1.5)
text(2012, 25.5, labels="Afrobarometer survey (pre-2014)", pos=2, cex = 0.9)
points(2013, 24.5, pch = 16, col="black", cex =1.5)
text(2012, 24.5, labels="Afrobarometer survey (post-2013)", pos=2, cex = 0.9)

segments(2012,23.5,2013,23.5, col="lightgrey", lwd=8)
text(2012, 23.5, labels="Years after first SIDE map", pos=2, cex = 0.9)

# ... --- finish
dev.off()



# Plot (voronoi) units (Kenya) #########
#   Produces Figure A2

## Load data
poly.ls <- list()

### Real districts
poly.ls[[1]] <- readOGR(file.path("data", "shapefiles"),
                        "uganda_adm2")

### Voronoi districts
poly.ls[[2]] <- readOGR(file.path("data", "shapefiles"),
                        "uganda_vor")

## Plot
count = 0
for(p in poly.ls){
  count = count + 1
  png(paste0(fig.path, "figurea2",c("a","b")[count],".png"), width = 3, height = 3, units = "in", res = 300)
  par(mar = c(0,0,0,0))
  plot(p)
  dev.off()
}







