###########################################
# ETHNO-POLITICAL POLARIZATION AND PRE-ELECTION VIOLENCE
#
# DISTRICT-LEVEL ANALYSIS ON RIOTS
#
# Carl Müller-Crepon, JPR, 2020
###########################################


###########################################
# GLOBALS #################################
###########################################

# Paths
tab.path <- "results/tables/"
fig.path <- "results/figures/"

# Star switch
stars.off <- F

# Libraries
library(lfe)
library(stargazer)
library(ggplot2)
library(countrycode)
library(rgeos)
library(rgdal)
library(sp)
library(spdep)
library(parallel)
library(foreach)
library(doParallel)
library(plyr)
library(splitstackshape)
library(geosphere)
library(MASS)
library(gtools)


# Functions

# ... spatial and temporal lags
get_lag_names <- function(var){
  c(paste0("log(1+",var,".spl",c(1:3),")"),paste0(var,".lag",c(1:3)))
}

# ... functions for additional table rows for LaTeX
latex.spat.lag <- function(times){c("Spatial lag$_{t-1,t-2,t-3}$:",paste0("\\multicolumn{1}{c}{",rep("yes",times),"}"))}
latex.temp.lag <- function(times){c("Polynomial DV$^{1,2,3}$:",paste0("\\multicolumn{1}{c}{",rep("yes",times),"}"))}
latex.dist.yrfe <- function(times){c("District-year FE:",paste0("\\multicolumn{1}{c}{",rep("yes",times),"}"))}
latex.cow.monthfe <- function(times){c("Country-month FE:",paste0("\\multicolumn{1}{c}{",rep("yes",times),"}"))}
latex.sample <- function(times,str){c("Sample:",paste0("\\multicolumn{1}{c}{",rep(str,times),"}"))}
latex.notes <- "Standard errors are clustered on the district-level"
latex.mean.dv <- function(model.ls){
  c("Mean DV:",paste0("\\multicolumn{1}{c}{",round_any(unlist(lapply(model.ls, function(m){mean(m$response)})), 0.0001),"}"))
}

# ... get coefficients out of felm object for plotting
get_coef <- function(m, coef.ids, label = "", class = "",
                     sample = c("Majoritarian", "Difference", "Proportional")){
  data.frame(label = label,
             class = class,
             coef = c(m$coefficients[coef.ids, 1],
                      m$coefficients[coef.ids[1], 1] + m$coefficients[coef.ids[2], 1]),
             se = c(diag(m$clustervcv[coef.ids, coef.ids])^.5,
                    (m$clustervcv[coef.ids[1], coef.ids[1]] + m$clustervcv[coef.ids[2], coef.ids[2]] + 2*m$clustervcv[coef.ids[1], coef.ids[2]])^.5
             ),
             sample = sample, 
             stringsAsFactors = F)
}

# ... Make stargazer columnlabels with one extra layer and rulers
collab_w_ruler <- function(column.labels, column.separate, trim = 10, add.below = NULL){
  cmidrule <- paste(paste0("\\cmidrule(lr{",trim,"pt}){", c(2, 2 + cumsum(column.separate[-length(column.separate)])), "-",
                           c(1+ cumsum(column.separate)), "}"), collapse = " ")
  if(is.null(add.below)){
    result <-  c(column.labels[-length(column.labels)], 
                 paste0(column.labels[length(column.labels)], "} \\\\ ", cmidrule, " \\\\[-6ex] {"))
  } else {
    add.b <- paste(paste0(" & \\multicolumn{1}{c}{", add.below, "}"), collapse = "")
    result <-  c(column.labels[-length(column.labels)], 
                 paste0(column.labels[length(column.labels)], "} \\\\ ", cmidrule, add.b, " {"))
  }
  
  return(result)
}

###########################################
# DATA LOAD ###############################
###########################################

# Time series
ts <- readRDS(file.path("data", "elec_viol_ts_main.rds"))

# Time series - stable 1990
ts.1990 <- readRDS(file.path("data", "elec_viol_ts_stab.rds"))

# Voronoi time series
ts.vor <- readRDS(file.path("data", "elec_viol_ts_vortv.rds"))

# Voronoi time series - stable 1990
ts.vor.1990 <- readRDS(file.path("data", "elec_viol_ts_vor1990.rds"))

# Kenya time series electoral districts
ts.kenya <- readRDS(file.path("data", "elec_viol_ts_kenya.rds"))

# Neighborhood matrix
ngb.df <- readRDS(file.path("data", "districts_ngb_df.rds"))




###########################################
# ANALYSIS SETUP ##########################
###########################################

# Specification

# ... covariates
main.cov <- c("time.to.leg.elec", "epr.polar", "epr.pol.time", "log.pop", "lnpop.time")
main.cov.lab <- c("Time to election", "Ethno-pol. polarization", "Time to elec. $\\times$ Ethno-pol. polar.",
                  "Population (log)", "Time to elec. $\\times$ Population")

# ... covariates that *do not* drop with district-year and country-month FEs
does.not.drop <- c(F,F,T,F,T)

# ... fixed effects (main)
fe.main <- "factor(cow.month) + factor(id.all.year) "

# ... SE clustering (main)
se.cluster <- "id.all"

# Helper function to combine
make_form <- function(dv, expl, fe, iv = "0", se = "0" ){
  as.formula(paste(dv, "~", paste(expl, collapse = "+"), "|",
                   fe, "|", iv, "|", se))
}

# Notes, significance, etc
if(stars.off){
  latex.notes <- "\\parbox[t]{.95\\textwidth}{\\textit{Notes:} OLS linear models. 
  Standard errors clustered on the district-level in parentheses.}"
  star.cutoffs <- c(.1,.05,.01)
  star.char <- c("","","")
} else {
  latex.notes <- "\\parbox[t]{.95\\textwidth}{\\textit{Notes:} OLS linear models. 
    Standard errors clustered on the district-level in parentheses.
    Significance codes: $^{*}$p$<$0.1; $^{**}$p$<$0.05; $^{***}$p$<$0.01}"
  star.cutoffs <- c(.1,.05,.01)
  star.char <- c("*","**","***")
}


# Empty dataframe for results plot
all.res.plot.df <- NULL


###########################################
# DESCRIPTIVES ############################
###########################################

# Plots ##################
#   Prodces Figures 1, 3, A1, and A2
source("scripts/plots_riots.R")


# Summary Statistics #####
#  Produces Table A1

# ... select variables
sum.vars <- c("time.to.leg.elec", "epr.polar", "log.pop", "polar", "urb.pop.ln", "nightlights.pp", 
              "scad.riot.ln", "acled.riot.ln", "acled.fat.ln", "ecav.viol.ln", "ecav.fat.ln", "majoritarian", "pr")

# ... labels
sum.labs <- c("Time to election", "Ethno-pol. polarization",
              "Population (log)", "Ethnic polarization","Urban population (log)",
              "Nightlights per capita", "Riots (SCAD; log)", "Riots (ACLED; log)", "Fatalities (ACLED; log)",
              "Viol. events (ECAV; log)", "Fatalities (ECAV; log)",
              "Majoritarian \\& mixed", "PR (pure)")

# ... save table
fileConn<-file(paste0(tab.path,"tablea1.tex"))
writeLines(stargazer(ts[!is.na(ts$epr.polar) & !is.na(ts$time.to.leg.elec) & !is.na(ts$majoritarian),sum.vars],
                     title = "Summary statistics: Districts 1990--2013",
                     omit.stat = c("adj.rsq","ser"),
                     covariate.labels = sum.labs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)



# Morans I #################
#  Produces numbers mentioned in text in section "Empirical strategy", last paragraph


# Prepare specifcations (to test Moran's I of residuals)
form <- make_form(dv = paste0("log(1+scad.riot.count)"), 
                  expl = c(main.cov[does.not.drop], get_lag_names("scad.riot.count")), fe = fe.main, se = se.cluster)
form.nolag <- make_form(dv = paste0("log(1+scad.riot.count)"), 
                        expl = c(main.cov[does.not.drop], get_lag_names("scad.riot.count")[!grepl("spl", get_lag_names("scad.riot.count"), fixed = T)]), 
                        fe = fe.main, se = se.cluster)

# Select majoritarian subset only  - drop all without neighbours
data <- na.omit(ts[ts$majoritarian==1, c(all.vars(form), "adm2_code", "cowcode","year", "month")])
data <- join(data,  ngb.df[, c("adm2_code", "cowcode", "year", "ngb_code")], 
             by = c("adm2_code", "cowcode", "year"),
             type = "left", match = "first")
data <- data[!is.na(data$ngb_code),]
data$id <- 1:nrow(data)

# Make neighbour list

## Prepare
this.ngb.df <- join(data[, c("adm2_code", "cowcode", "year", "month", "id")], 
                    ngb.df, 
                    type = "left", match = "all",
                    by = c("adm2_code", "cowcode", "year"))
this.ngb.df <- join(this.ngb.df,
                    cbind(data[, c("cowcode", "year", "month")], 
                          ngb_code = data$adm2_code, ngb_id = data$id), 
                    type = "left", match = "first",
                    by = c("ngb_code", "cowcode", "year", "month"))
this.ngb.df$patch.id <- ceiling(ncore*this.ngb.df$id / max(this.ngb.df$id))

## Cluster with 10 CPUs
cl <- makeCluster(getOption("cl.cores",  ncore))
registerDoParallel(cl)
clusterExport(cl, list("this.ngb.df"))

## Make this list on cluster
max.id <- nrow(data)
this.ngb.ls <- foreach(p = 1:ncore,
                       .noexport = c("this.ngb.df")) %dopar% {
                         these.id <- which(ceiling(ncore*c(1:max.id) / max(this.ngb.df$id)) == p)
                         lapply(these.id, function(i){
                           this.ngb.df$ngb_id[this.ngb.df$id == i]
                         })
                       }
this.ngb.ls <- unlist(this.ngb.ls, recursive = F)

## Stop Cluster
stopCluster(cl)

## Finalize neighbor list in spdep format
class(this.ngb.ls) <- "nb"
listw <-  nb2listw( this.ngb.ls)


# Estimate models
model <- felm(form, data = data, keepCX = T)
model.nolag <- felm( make_form(dv = paste0("log(1+scad.riot.count)"), 
                               expl = c(main.cov[does.not.drop]), fe = "0", se = se.cluster), data = data, keepCX = T)

# Compute Moran's Is

## Moran's I of outcome
test1 <- moran.test(log(1 + data$scad.riot.count), listw, randomisation=T, zero.policy=NULL,
                    alternative="greater", rank = FALSE, na.action=na.fail, spChk=NULL, adjust.n=T)
print(test1)


## Moran's I of residuals
test2 <- moran.test(model$residuals, listw, randomisation=T, zero.policy=NULL,
                    alternative="greater", rank = FALSE, na.action=na.fail, spChk=NULL, adjust.n=T)
print(test2)


## Moran's I of residuals (w/out spatial lags and FE)
test3 <- moran.test(model.nolag$residuals, listw, randomisation=T, zero.policy=NULL,
                    alternative="greater", rank = FALSE, na.action=na.fail, spChk=NULL, adjust.n=T)
print(test3)



###########################################
# MAIN ANALYSIS ###########################
###########################################


# Main Majoritarian ########
#  Produces Table 1

# ... set dependent variable
dep.var <- "scad.riot.count"

# ... varying fixed effects specifications
fe.list <- list("0",
                "factor(cowcode)",
                "factor(id.all)", 
                fe.main)

# ... estimate
model.ls <- lapply(fe.list, function(f){
  if(f == fe.main){
    felm(make_form(dv = paste0("log(1+",dep.var,")"), expl = c(main.cov[does.not.drop], get_lag_names(dep.var)), fe = f, se = se.cluster),
         data = ts[ts$majoritarian==1 ,], keepX = T)
  } else {
    felm(make_form(dv = paste0("log(1+",dep.var,")"), expl = c(main.cov, get_lag_names(dep.var)), fe = f, se = se.cluster),
         data = ts[ts$majoritarian==1 ,], keepX = T)
  }
})
res.fe.maj <- model.ls

# ... prepare table
add.lines <- list(latex.sample(4,"Maj. \\& Mix."),
                  c("Fixed effects:",paste0("\\multicolumn{1}{c}{",c(" -- ", "country","district","district-year \\&"),"}")),
                  c("",paste0("\\multicolumn{1}{c}{",c("","","","country-month"),"}")),
                  latex.spat.lag(4),latex.temp.lag(4),latex.mean.dv(model.ls)
)

# ... save table
fileConn<-file(paste0(tab.path,"table1.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& pre-election violence in majoritarian and mixed systems",
                     dep.var.labels=rep("\\sc{Riots \\lb (SCAD)}",4),multicolumn=F,# se = se,
                     covariate.labels = c("Constant",main.cov.lab),
                     omit = c("scad.riot.count.spl1","scad.riot.count.spl2","scad.riot.count.spl3",
                              "scad.riot.count.lag1","scad.riot.count.lag2","scad.riot.count.lag3"),
                     notes.align = "l",label="tab_main",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F, notes.label = "", star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)


# Nigeria Prediction
#  Cited in section "Results", paragraph 2

# ... reestimate Model 1, Table 1
m <- lm(paste(paste0("log(1+","scad.riot.count",")"), "~", 
              paste(expl = c(main.cov, get_lag_names("scad.riot.count")), collapse = " + ")),
        data = ts[ts$majoritarian==1 ,])
summary(m)

# ... data
nig.df <- ts[ts$cowcode == 475 & 
               ts$year %in% c(2007) &
               ts$time.to.leg.elec >= 1,]



# ... all riots at actual polarization level
mean(nig.df$epr.polar)
sum(nig.df$scad.riot.count)
sum(exp(predict(m, nig.df)) - 1)


nig.df$epr.polar <- 0
nig.df$epr.pol.time <- 0
sum(exp(predict(m, nig.df)) - 1)


# Plot: Substantive effects ###
#  Produces Figure 4

# ... get model
m <- res.fe.maj[[1]]

# ... get data underlying the model
sub.data <- as.data.frame(m$X)

# ... mean values
mean.values <- data.frame(matrix(apply(sub.data, 2, mean), nrow = 1))[rep(1, 50),]
colnames(mean.values) <- colnames(sub.data)
mean.values$epr.polar <- seq(0,1,length.out = 50)

# ... simulate months to 0, 3, 6, 12 election
set.seed(250589)
sim <- mvrnorm(n=100000,mu=m$beta,Sigma=m$clustervcv)
res <- list()

for(i in c(0,3,6,12)){
  
  # ... update election related values
  m.to.elec <- 1/(i+1)
  these.values <- mean.values #[,2:12]
  these.values$time.to.leg.elec <- m.to.elec
  these.values$epr.pol.time <- these.values$epr.polar * m.to.elec
  these.values$lnpop.time <- these.values$log.pop * m.to.elec
  
  # ... predict
  these.pred <- apply(these.values, 1, function(x){rowSums(t(t(sim) * x))})
  these.pred <- apply(these.pred, 2, function(x){ c(mean(x),quantile(x,c(0.975,0.025)))})
  these.pred <- t(these.pred)
  these.pred <- exp(these.pred) - 1
  res <- c(res,list(these.pred))
}

# ... Save figure
png(file=paste0(fig.path,"figure4.png"), width = 12, height=5, units = "in", res = 300)
par(mar = c(5, 5, 5, 0.5))  
titles <- c("election month","3 months to election","6 months to election","12 months to election")
layout(matrix(c(1,2,3,4), nrow=1, byrow = TRUE), widths = c(1.3,1,1,1))
tick <- seq(0,0.015, length.out = 4)
dens <- density(ts$epr.polar[ts$majoritarian==1], na.rm=T)
for(i in c(4:1)){
  if(i==4){ 
    ylab = "Predicted number of riots (SCAD)" 
    par(mar = c(5, 5, 5, 0))
  } else { 
    ylab = "" 
    par(mar = c(5, 1, 5, 0))
  }
  
  plot(mean.values$epr.polar,res[[i]][,1],  type="l", xlim = c(0,1), ylim = c(0, 0.0125),
       bty='n',yaxt="n", xaxt="n", ylab=ylab,xlab = "", main=titles[i], cex.lab = 1.5)
  segments(rep(0,length(tick)),tick, rep(1,length(tick)), tick, lty=2, col="grey", lwd=2)
  polygon(c(rev(mean.values$epr.polar), mean.values$epr.polar), c(rev(res[[i]][,3]), res[[i]][,2]), col = 'grey80', border = NA)
  lines(mean.values$epr.polar,res[[i]][,1])
  axis(1, at=seq(0,1,0.25), labels=c("0",".25",".5",".75","1"),cex.axis = 1.5 )
  if(i==4){
    axis(2, at=tick, cex.axis = 1.5)
  } 
  
  #Density
  par(new=TRUE)
  plot(dens$x, dens$y, type = "l", ylim = c(0,20),xlim=c(0,1),lty=3,bty='n',yaxt="n", xaxt="n", ylab="",xlab = "")
}
mtext("Local ethno-political polarization", side=1, outer=T, line=-2) #, adj=.9, padj=0)
dev.off()

# Escalation measures 
#   Mentioned in section "results", paragraph 2

res[[1]][50,1]/res[[4]][50,1] ## Escalation within district
res[[1]][1,1]/res[[4]][1,1]

res[[1]][50,1]/res[[1]][1,1] ## Change of pol / non-pol ratio
res[[4]][50,1]/res[[4]][1,1]



# Main comparison #########
#  Produces Table 2 and rows 1-3 in Figure 5

# ... estimate models
dep.vars <- c("scad.riot.count","acled.riot.count","acled.riot.fatal")
model.ls <- unlist(lapply(dep.vars, function(dv){
  list(felm(make_form(dv = paste0("log(1+",dv,")"), expl = c(main.cov[does.not.drop], get_lag_names(dv),
                                                             "epr.pol.time:pr","lnpop.time:pr"), 
                      fe = fe.main, se = se.cluster),
            data = ts[,]))
}), recursive = F)


# ... prepare table
dv.lab <- c("\\sc{Riots \\lb (SCAD)}","\\sc{Riots \\lb (ACLED)}","\\sc{Fatalities \\lb (ACLED)}")
add.lines <- list(c("Sample:",paste0("\\multicolumn{1}{c}{",rep(c("all"),3),"}")),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.mean.dv(model.ls))

# ... save table
fileConn <- file(paste0(tab.path,"table2.tex"))
writeLines(stargazer(model.ls,
                     title="Local ethnic polarization \\& pre-election violence: Majoriarian vs. PR elections",
                     dep.var.labels=rep(dv.lab, each = 1),
                     multicolumn=F,# se = se,
                     covariate.labels = c(main.cov.lab[does.not.drop],
                                          paste("\\sc{", main.cov.lab[does.not.drop],
                                                " $\\times$ PR}")),
                     omit = c("scad", "acled"),
                     notes.align = "l",label="tab_comp",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F, notes.label = "", star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="10pt"), 
           fileConn)
close(fileConn)


# ... save results for plot
all.res.plot.df <- rbind(all.res.plot.df,
                         get_coef(m  = model.ls[[1]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Baseline", class = "Baseline"),
                         get_coef(m  = model.ls[[2]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Event count", class = "ACLED riot data:"),
                         get_coef(m  = model.ls[[3]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Fatalities", class = "ACLED riot data:"))


###########################################
# ROBUSTNESS CHECKS #######################
###########################################


# ECAV EVENT COUNTS ############
#  Produces Table A2 and rows 4-5 in Figure 5

# ... estimate models
dep.vars <- c("ecav.viol.count","ecav.all.fatal")
add.controls <-  c("log.pop")
model.ls <- unlist(lapply(dep.vars, function(dv){
  list(felm(make_form(dv = paste0("log(1+",dv,")"), expl = c("epr.polar", add.controls, get_lag_names(dv)), 
                      fe = "factor(cow.month)  ", se = se.cluster),
            data = ts[ts$majoritarian == 1 & ts$month.to.leg.elec > 1/7,]),
       felm(make_form(dv = paste0("log(1+",dv,")"), expl = c("epr.polar", add.controls , get_lag_names(dv),
                                                             paste0(c("epr.polar",add.controls), ":pr")), 
                      fe = "factor(cow.month) ", se = se.cluster),
            data = ts[ts$month.to.leg.elec > 1/7,]))
}), recursive = F)

# ... prepare table
dv.lab <- c("\\sc{Violent Events \\lb (ECAV)}","\\sc{Fatalities \\lb (ECAV)}")
add.lines <- list(c("Sample:",paste0("\\multicolumn{1}{c}{",rep(c("Maj. \\& Mix.","all"),length(model.ls)/2),"}")),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),
                  c("District-year FE:",paste0("\\multicolumn{1}{c}{",rep("no",length(model.ls)),"}")),
                  latex.cow.monthfe(length(model.ls)),
                  latex.mean.dv(model.ls))
ecav.labs <- c( "Ethno-pol. polarization" , "Population (log)")

# ... save table
fileConn<-file(paste0(tab.path,"tablea2.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& pre-election violence from ECAV",
                     dep.var.labels = rep(dv.lab, each = 2),
                     multicolumn=F,# se = se,
                     covariate.labels = c(ecav.labs,
                                          paste0(ecav.labs," $\\times$ PR")),
                     keep = c("epr.polar", "log.pop"),
                     notes.align = "l",label="tab_ecav",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F, notes.label = "", star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="-5pt"), 
           fileConn)
close(fileConn)

# ... save results for plot
all.res.plot.df <- rbind(all.res.plot.df,
                         get_coef(m  = model.ls[[2]], coef.ids = c("epr.polar","epr.polar:pr"), 
                                  label = "Violent event count", class = "ECAV data:"),
                         get_coef(m  = model.ls[[4]], coef.ids = c("epr.polar","epr.polar:pr"), 
                                  label = "Fatalities", class = "ECAV data:"))


# DISAGGREGATION: Various forms of riots #####
#  Produces Table A3 and rows 6-10 in Figure 5


# ... estimate
dep.var.ls <- c("scad.riot.spont.count","scad.riot.org.count",
                "scad.riotelec.count","scad.riotethn.count","scad.riotother.count" )

model.ls <- lapply(dep.var.ls, function(dv){
  felm(make_form(dv = paste0("log(1+",dv,")"), 
                 expl = c(main.cov[does.not.drop], paste0("pr:", main.cov[does.not.drop]), get_lag_names(dv)), 
                 fe = fe.main, se = se.cluster),
       data = ts[,])
})

# ... prepare table
add.lines <- list(latex.sample(length(model.ls),"all"),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),latex.mean.dv(model.ls))

# ... save table
fileConn<-file(paste0(tab.path,"tablea3.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& various types of pre-election riots",
                     column.labels = collab_w_ruler(column.labels = c("Riot organization", "Riot issue"), 
                                                    column.separate = c(2,3), trim = 10, 
                                                    add.below = c("Not identified", "Identified", 
                                                                  "Elections", "Ethnic", "All others")),
                     dep.var.labels= rep("", length(model.ls)),
                     column.separate = c(2,3),
                     multicolumn=F,# se = se,
                     covariate.labels = c(main.cov.lab[does.not.drop],
                                          paste("\\sc{", main.cov.lab[does.not.drop],
                                                " $\\times$ PR}")),
                     omit = c("scad"),
                     notes.align = "l",label="tab_riotdisagg",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="-12pt"), 
           fileConn)
close(fileConn)


# ... save results for plot
all.res.plot.df <- rbind(all.res.plot.df,
                         get_coef(m  = model.ls[[1]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "No identified riot organization", class = "Disaggregating riots:"),
                         get_coef(m  = model.ls[[2]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Identified riot organization", class = "Disaggregating riots:"),
                         get_coef(m  = model.ls[[3]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Issue: Election", class = "Disaggregating riots:"),
                         get_coef(m  = model.ls[[4]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Issue: Ethnic", class = "Disaggregating riots:"),
                         get_coef(m  = model.ls[[5]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Issue: Others", class = "Disaggregating riots:"))



# PLACEBO CHECK: other forms of events (demonstrations, mitlitia violence, strikes) #####
#  Produces Table A4 

# ... estimate
dep.var.ls <- c("scad.riot.count","scad.demo.count",
                "scad.strike.lim.count","scad.militia.count" )

model.ls <- lapply(dep.var.ls, function(dv){
  felm(make_form(dv = paste0("log(1+",dv,")"), expl = c(main.cov[does.not.drop], paste0("pr:", main.cov[does.not.drop]), get_lag_names(dv)), 
                 fe = fe.main, se = se.cluster),
       data = ts)
})

# ... prepare table
add.lines <- list(latex.sample(length(model.ls),"all"),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),latex.mean.dv(model.ls))

# ... save table
fileConn<-file(paste0(tab.path,"tablea4.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& various forms of pre-election violence",
                     dep.var.labels=c("\\sc{Riots \\lb (SCAD)}","\\sc{Demonstrations \\lb (SCAD)}",
                                      "\\sc{Strikes \\lb (SCAD)}","\\sc{Militia \\lb (SCAD)}"),
                     multicolumn=F,# se = se,
                     covariate.labels = c(main.cov.lab[does.not.drop],
                                          paste("\\sc{", main.cov.lab[does.not.drop],
                                                " $\\times$ PR}")),
                     omit = c("scad"),
                     notes.align = "l",label="tab_placebo",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="-5pt"), 
           fileConn)
close(fileConn)




# REVERSE CAUSALITY ############
#  Produces Table A5 and rows 11-12 in Figure 5

# ... set dependent variable
dep.var <- c("scad.riot.count") 


# ... variables
these.cov <- c("month.to.reg.elec", "epr.polar" ,"I(epr.polar * month.to.reg.elec)" , "log.pop" , "I(log.pop * month.to.reg.elec)")

# ... estimate
model.ls <- list(
  ## Regular elections
  felm(make_form(dv = paste0("log(1+",dep.var,")"), 
                 expl = c(these.cov[does.not.drop], get_lag_names(dep.var)), fe = fe.main, se = se.cluster),
       data = ts[ts$majoritarian==1 ,], keepX = T),
  felm(make_form(dv = paste0("log(1+",dep.var,")"), 
                 expl = c(these.cov[does.not.drop], 
                          paste0("I(pr*", these.cov[does.not.drop], ")"), get_lag_names(dep.var)), fe = fe.main, se = se.cluster),
       data = ts[,], keepX = T),
  
  ## Pre-period SIDE data
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"), 
                 expl = c(main.cov[does.not.drop], get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = se.cluster),
       data = ts[ts$majoritarian==1 & ts$year>=ts$map.from ,]),
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"), 
                 expl = c(main.cov[does.not.drop],
                          "I(epr.pol.time*pr)","I(lnpop.time*pr)", get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = se.cluster),
       data = ts[ts$year>=ts$map.from ,])
  
)


# ... prepare table
add.lines <- list(latex.sample(length(model.ls),"all"),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),latex.mean.dv(model.ls)
)
these.cov.labs <- c(main.cov.lab[does.not.drop],
                    paste("\\sc{", main.cov.lab[does.not.drop],
                          " $\\times$ PR}"))
# ... save table
fileConn<-file(paste0(tab.path,"tablea5.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization and riots (SCAD): Addressing reverse causality",
                     column.labels = collab_w_ruler(column.labels = c("Regular elections", "Pre-period SIDE data"), 
                                                    column.separate = c(2,2), trim = 10, 
                                                    add.below = c(rep("\\sc{Riots \\lb (SCAD)}",length(model.ls)))),
                     dep.var.labels= rep("", length(model.ls)),
                     column.separate = c(2,2),
                     multicolumn=F,# se = se,
                     dep.var.caption = "",
                     covariate.labels = c(gsub("Time to elec", "Time to reg. elec", these.cov.labs),
                                          these.cov.labs),
                     omit = c("scad"),
                     notes.align = "l",label="tab_revcause",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F, notes.label = "", star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="-12pt"), 
           fileConn)
close(fileConn)



# ... save results for plot
all.res.plot.df <- rbind(all.res.plot.df,
                         get_coef(m  = model.ls[[2]], coef.ids = c(1,3), 
                                  label = "Regular elections only", class = "Reverse causality?"),
                         get_coef(m  = model.ls[[4]], coef.ids = c(1,3), 
                                  label = "Pre-period SIDE data", class = "Reverse causality?"))




# COMPARISON: UNITS ####################
#  Produces Table A6 and rows 13-15 in Figure 5

# ... estimate models
model.ls <- lapply(list(ts, ts.1990, ts.vor, ts.vor.1990), function(data){
  felm(make_form(dv =  paste0("log(1+","scad.riot.count",")"),
                 expl = c(main.cov[does.not.drop],
                          "epr.pol.time:pr","lnpop.time:pr",
                          get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = se.cluster),
       data = data[,])
})

# ... prepare table
dv.lab <- c("\\sc{Riots \\lb (SCAD)}")
add.lines <- list(c("Units:",paste0("\\multicolumn{1}{c}{",c("District","District","Voronoi","Voronoi"),"}")),
                  c("",paste0("\\multicolumn{1}{c}{",rep(c("time-variant", "1990"),2),"}")),
                  c("Sample:",paste0("\\multicolumn{1}{c}{",rep(c("all"),4),"}")),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.mean.dv(model.ls))

# ... save table
fileConn<-file(paste0(tab.path,"tablea6.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& pre-election violence: Varying units of analysis",
                     dep.var.labels=rep(dv.lab, each = 4),
                     multicolumn=F,# se = se,
                     covariate.labels = c(main.cov.lab[does.not.drop],
                                          paste("\\sc{", main.cov.lab[does.not.drop],
                                                " $\\times$ PR}")),
                     omit = c("scad", "acled"),
                     notes.align = "l",label="tab_comp_units",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F, notes.label = "", star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="-7pt"), 
           fileConn)
close(fileConn)



# ... save results for plot
all.res.plot.df <- rbind(all.res.plot.df,
                         get_coef(m  = model.ls[[2]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Districts, 1990", class = "Endogenous districts?"),
                         get_coef(m  = model.ls[[3]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Voronoi, time-varying", class = "Endogenous districts?"),
                         get_coef(m  = model.ls[[4]], coef.ids = c("epr.pol.time","epr.pol.time:pr"), 
                                  label = "Voronoi, 1990", class = "Endogenous districts?"))






# Additional Tests: Covariates ####################
#  Produces Table A7 and rows 16-19 in Figure 5

# ... add aligned (general) election dummy
ts$aligned <- ifelse(ts$month.to.leg.elec == ts$month.to.exec.elec, 1, 0)


# ... estimate
model.ls <- list(
  # No controls
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"), 
                 expl = c("epr.pol.time", "I(epr.pol.time*pr)",  get_lag_names("scad.riot.count") ), 
                 fe = fe.main, se = se.cluster),
       data = ts),
  
  # Control for pure polarization, nightlights, and urban population              
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"), 
                 expl = c(main.cov[does.not.drop], "I(epr.pol.time*pr)","I(lnpop.time*pr)",
                          paste0("I(", c("polar","nightlights.pp", "urb.pop.ln", "epr.excl", "epr.irr"), "*time.to.leg.elec)"),
                          paste0("I(", c("polar","nightlights.pp", "urb.pop.ln", "epr.excl", "epr.irr"), "*time.to.leg.elec*pr)"),
                          get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = se.cluster),
       data = ts),
  
  # Control for election months
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"), 
                 expl = c(main.cov[does.not.drop], "I(epr.pol.time*pr)","I(lnpop.time*pr)",
                          "I(leg.elec*epr.polar)", "I(leg.elec*epr.polar*pr)", get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = se.cluster),
       data = ts),
  
  # Aligned elections
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"),
                 expl = c(c(main.cov[does.not.drop],  "I(epr.pol.time*pr)","I(lnpop.time*pr)"),
                          paste0("I(aligned*",c("epr.pol.time",  "epr.pol.time*pr"), ")"),
                          get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = se.cluster),
       data = ts)
)


# ... prepare table
add.lines <- list(
  latex.sample(4,"all"),
  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),
  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
  latex.mean.dv(model.ls))
these.cov.labels <- c(main.cov.lab[does.not.drop],
                      paste0("\\sc{", main.cov.lab[does.not.drop],
                             " $\\times$ PR}"),
                      paste(rep(c("Time to elec. $\\times$ Ethnic polar.", "Time to elec. $\\times$ Light p.c.", "Time to elec. $\\times$ Urban pop.", 
                                  "Time to elec. $\\times$ Ethn. excluded", "Time to elec. $\\times$ Ethn. irrelevant"), 2), 
                            rep(c("", " $\\times$ PR"), each = 5)),
                      paste0(rep(c("Election month $\\times$ "), each = 1),
                             rep(c("EPP", "EPP $\\times$ PR"), 1)),
                      paste0(rep(c("Time to elec. $\\times$ EPP", "Time to elec. $\\times$ EPP  $\\times$ PR"), 1),
                             rep(c(" $\\times$ Gen. elec."), each = 1)))
# ... Notes
if(stars.off){
  these.notes <- "\\parbox[t]{\\textwidth}{\\textit{Notes:} OLS linear models. 
  Model 1 includes interactions of urban population, nightlights per capital, 
  pure ethnic polarization, and ethno-political inclusion and irrelevance with the time to the next election, seperate for PR and majoritarian/mixed systems. 
  Model 3 includes a three way interaction of a dummy for an election month $\\times$ ethno-political polarization $\\times$ 
  a dummy for pure PR systems. 
  Standard errors clustered on the district-level in parentheses.}"
} else {
  these.notes <- "\\parbox[t]{.95\\textwidth}{\\textit{Notes:} OLS linear models. EPP stands for ethno-political polarization. 
    Standard errors clustered on the district-level in parentheses.
    Significance codes: $^{*}$p$<$0.1; $^{**}$p$<$0.05; $^{***}$p$<$0.01}"
}

fileConn<-file(paste0(tab.path,"tablea7.tex"))
writeLines(gsub("& & & & \\\\", "\\\\[-1.8ex] ", 
                stargazer(model.ls, type = "latex", notes.align = "l",label="tab_rob_comp",
                          align =T,title="Additional robustness Checks: Local ethnic polarization \\& pre-election riots", 
                          dep.var.labels=c(rep("\\sc{Riots \\lb (SCAD)}",length(model.ls))),
                          multicolumn=F,# se = se,
                          omit =  "scad", #c("riot", "nightlight","urb.pop.ln", "leg.elec:epr.polar"), 
                          # keep = c(1,2,4,5,6,7,8,9,10),
                          # keep = c("epr.pol.time", "lnpop.time"),
                          covariate.labels = these.cov.labels,
                          add.lines = add.lines,digits = 4,
                          omit.stat = c("adj.rsq","ser"),
                          notes = these.notes, notes.append = F, notes.label = "", star.char = star.char, star.cutoffs = star.cutoffs,
                          font.size = "scriptsize", column.sep.width ="-10pt"), fixed = T), 
           fileConn)
close(fileConn)


# ... save for plot
all.res.plot.df <- rbind(all.res.plot.df,
                         get_coef(m  = model.ls[[1]], coef.ids = c(1,2), 
                                  label = "No controls", class = "Additional tests:"),
                         get_coef(m  = model.ls[[2]], coef.ids = c(1,3), 
                                  label = "Additional controls", class = "Additional tests:"),
                         get_coef(m  = model.ls[[3]], coef.ids = c(1,3), 
                                  label = "Controlling for election months", class = "Additional tests:"),
                         get_coef(m  = model.ls[[4]], coef.ids = c(1,3), 
                                  label = "Controlling for general elections", class = "Additional tests:"))




# ROBUSTNESS CHECK PLOT #####################
#  Produces Figure 5 from results estimated above

## Prepare
plot.df <- all.res.plot.df


### Positions
plot.df$class <- factor(plot.df$class, levels = unique(plot.df$class), ordered = T)
for(c in unique(plot.df$class)[2:length(unique(plot.df$class))]){
  plot.df <- smartbind(plot.df[plot.df$class < c,, drop = F],
                       data.frame(label = rep(c, 3),
                                  class = rep(factor(c, levels = unique(plot.df$class), ordered = T), 3),
                                  sample = c("Majoritarian", "Proportional", "Difference")),
                       plot.df[plot.df$class >= c,, drop = F])
}
plot.df$sample <- factor(plot.df$sample, levels = c("Majoritarian", "Proportional", "Difference"), ordered = T)
plot.df$pos <- rep((nrow(plot.df)/3):1, each = 3)

### Label df
lab.df <- plot.df[plot.df$sample == "Majoritarian",]

### Change direction of difference
plot.df$coef[plot.df$sample == "Difference"] <- -1 * plot.df$coef[plot.df$sample == "Difference"]


## Make plot and save
g <- ggplot(plot.df, aes( x = coef, y = pos)) +
  geom_vline(xintercept = 0, lty = 2, col = "darkgrey") +
  geom_point() + theme_minimal() +
  geom_segment(aes(x = coef + se * 1.96,
                   xend = coef - se * 1.96,
                   y = pos, yend = pos)) + 
  facet_wrap( ~ sample) +
  xlab("Marginal effect of ethno-political polarization x time to election") +
  scale_y_continuous(breaks = (lab.df$pos), 
                     labels = (lab.df$label))+ 
  scale_x_continuous(breaks = scales::pretty_breaks(n = 3)) +
  theme(axis.text.y=
          element_text(face=ifelse(as.character(lab.df$label) == as.character(lab.df$class),
                                   "bold","plain")),
        axis.ticks.y = element_line(color = ifelse(as.character(lab.df$label) == as.character(lab.df$class),
                                                   "white",grey(.10))),
        panel.spacing = unit(1, "lines")) +
  ylab(NULL)

png(file=paste0(fig.path,"figure5.png"), width = 6, height=5, units = "in", res = 300)
print(g)
dev.off()


# STANDARD ERROR SPECIFICATIONS #####
#  Produces Table A8

# ... standard-error specifications
cluster.modes <- c( "id.all  ",
                    "id.all + lat + long + cow.month ", ## Lat long for conley SEs
                    "adm1_code  ",
                    "cow.year ")

# ... estimate
model.ls <- lapply(cluster.modes, function(c){
  felm(make_form(dv = paste0("log(1+","scad.riot.count",")"), 
                 expl = c(main.cov[does.not.drop], paste0("pr:", main.cov[does.not.drop]), get_lag_names("scad.riot.count")), 
                 fe = fe.main, se = c),
       data = ts[ ,], keepCX = T, keepX = T)
})
se.ls <- lapply(model.ls, function(m){diag(m$clustervcv)^.5})



# ... conley
source("scripts/functions/Conley_HAC.R")
c.se <- ConleySEs(reg = model.ls[[2]],unit = "id.all", 
                  dat = NULL,
                  time = "cow.month",
                  lat = "lat", lon = "long",
                  kernel = "bartlett", dist_fn = "Haversine", dist_cutoff = 500, 
                  lag_cutoff = 60,
                  cores = 1, 
                  verbose = TRUE)
se.ls[[2]] <- diag(c.se$Spatial_HAC)^.5


# ... prepare table
add.lines <- list(c("SE clustering:",paste0("\\multicolumn{1}{c}{",c("District", "Conley","Region",
                                                                     "Country-year"),"}")),
                  latex.sample(length(model.ls),"Maj. \\& Mix."),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),latex.mean.dv(model.ls))
# ... Notes
if(stars.off){
  these.notes <- "\\parbox[t]{\\textwidth}{\\textit{Notes:} OLS linear models. }"
} else {
  these.notes <- "\\parbox[t]{\\textwidth}{\\textit{Notes:} OLS linear models. 
  Significance codes: $^{*}$p$<$0.1; $^{**}$p$<$0.05; $^{***}$p$<$0.01}"
}

# ... save table
fileConn<-file(paste0(tab.path,"tablea8.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& pre-election violence: Standard error specifications",
                     dep.var.labels=rep("\\sc{Riots \\lb (SCAD)}",4),multicolumn=F,# se = se,
                     se = se.ls,
                     covariate.labels =c(main.cov.lab[does.not.drop],
                                         paste("\\sc{", main.cov.lab[does.not.drop],
                                               " $\\times$ PR}")),
                     omit = c("scad"),
                     notes.align = "l",label="tab_rob2",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = these.notes, notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="-5pt"), 
           fileConn)
close(fileConn)




# KENYA 2007 CONSTITUENCIES #############
#  Produces Table A9

# ... estimate
dep.var.ls <- c("scad.riot.count","acled.riot.count","acled.riot.fatal")
model.ls <- unlist(lapply(dep.var.ls, function(dv){
  list(felm(make_form(dv = paste0("log(1+",dv,")"), expl = c(main.cov[does.not.drop], get_lag_names(dv)), 
                      fe = fe.main, se = se.cluster),
            data = ts.kenya),
       felm(make_form(dv = paste0("log(1+",dv,")"), expl = c(main.cov[does.not.drop], get_lag_names(dv)), 
                      fe = fe.main, se = se.cluster),
            data = ts[ts$cowcode == 501,]))
}), recursive = F)

# ... prepare table
add.lines <- list(latex.sample(length(model.ls),"Kenya"),
                  c("",paste0("\\multicolumn{1}{c}{",
                              rep(c("constituencies","districts"),3),"}")),
                  latex.dist.yrfe(length(model.ls)),latex.cow.monthfe(length(model.ls)),
                  latex.spat.lag(length(model.ls)),latex.temp.lag(length(model.ls)),latex.mean.dv(model.ls))

# ... save table
fileConn<-file(paste0(tab.path,"tablea9.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& various forms of pre-election violence: Kenya constituencies",
                     dep.var.labels=rep(c("\\sc{Riots \\lb (SCAD)}","\\sc{Riots \\lb (ACLED)}","\\sc{Fatalities \\lb (ACLED)}"),each = 2),
                     multicolumn=F,# se = se,
                     covariate.labels = c(main.cov.lab[does.not.drop]),
                     omit = c("scad", "acled"),
                     notes.align = "l",label="tab_kenya",align =T,
                     add.lines = add.lines,digits = 4, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = latex.notes, notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)

