###########################################
# ETHNO-POLITICAL POLARIZATION AND PRE-ELECTION VIOLENCE
#
# AFROBAROMETER ANALYSIS
#
# Carl Müller-Crepon, JPR, 2020
###########################################
rm(list = ls())


###########################################
# GLOBALS #################################
###########################################

# Paths
tab.path <- "results/tables/"
fig.path <- "results/figures/"

# Switches
stars.off <- F

# Libraries
library(ggplot2)
library(lfe)
library(stargazer)

# Functions

# ... functions for additional table rows for LaTeX
latex.cow.roundfe <- function(times){c("Country-round FE:",paste0("\\multicolumn{1}{c}{",rep("yes",times),"}"))}
latex.ind.cont <- function(times){c("Controls",paste0("\\multicolumn{1}{c}{",rep("yes",times),"}"))}
latex.sample <- function(times,str){c("Sample:",paste0("\\multicolumn{1}{c}{",rep(str,times),"}"))}
latex.mean.dv <- function(model.ls){
  c("Mean DV:",paste0("\\multicolumn{1}{c}{",round_any(unlist(lapply(model.ls, function(m){mean(m$response)})), 0.0001),"}"))
}

###########################################
# DATA LOAD ###############################
###########################################

ab.fin.df <- readRDS(file.path("data", "afrobarometer.rds"))


###########################################
# ANALYSIS SETUP ##########################
###########################################


# Specification

# ... components
main.expl <- c("epr.polar")
main.expl.lab <- c("Ethno-pol. polarization")

# ... covariates
main.cov <- c("log.pop",  "urban","sex" , "age" , "age2", "educ")
main.cov.lab <- c("Population (log)", "Urban", "Female","Age","Age$^2$", "Education")

# ... fixed effects (main)
fe.main <- "factor(cowround) "

# ... SE clustering (main)
se.cluster <- "district_id"

# ... coefficient to keep in tables
keep.main <- c("epr.polar")

# ... helper function to combine
make_form <- function(dv, expl, fe, iv = "0", se = "0" ){
  as.formula(paste(dv, "~", paste(expl, collapse = "+"), "|",
                   fe, "|", iv, "|", se))
}

# Notes, stars, etc.
if(stars.off){
  latex.notes <- "\\parbox[t]{\\textwidth}{\\textit{Notes:} OLS linear models. 
Control variables include the district population (logged), and urban and female dummy, age and its square, 
  as well as the respondent's education. 
  Standard errors clustered on the district-level in parentheses.}"
  star.cutoffs <- c(.1,.05,.01)
  star.char <- c("","","")
} else {
  latex.notes <- "\\parbox[t]{\\textwidth}{\\textit{Notes:} OLS linear models. 
Control variables include the district population (logged), and urban and female dummy, age and its square, 
as well as the respondent's education. 
Standard errors clustered on the district-level in parentheses.
Significance codes: $^{*}$p$<$0.1; $^{**}$p$<$0.05; $^{***}$p$<$0.01}"
  star.cutoffs <- c(.1,.05,.01)
  star.char <- c("*","**","***")
}



###########################################
# DESCRIPTIVES ############################
###########################################

# How many countries?
#   Number cited in section "The fear of..."
country.num <- length(unique(ab.fin.df$cowcode[!is.na(ab.fin.df$fear_eviol) & !is.na(ab.fin.df$epr.polar)]))
print(country.num)

# Summary stats
#   Produces Table A10

# ... variables
sum.vars <- c("fear_eviol","epr.polar", "majoritarian", "pr", "log.pop",
              "urban","sex","age","educ","same_language" , "others_check" , 
              "others_influence" ,"others_present" )

# ... labels
sum.var.labs <- c("Fear of elec. violence", "Ethno-pol. polarization",
                  "Majoritarian \\& mixed", "PR (pure)","Population (log)", "Urban",
                  "Female","Age", "Education", "Same language as interviewer", 
                  "Others checked during interview", "Others influenced", "Others present")

# ... save
fileConn<-file(paste0(tab.path,"tablea10.tex"))
writeLines(stargazer(ab.fin.df[!is.na(ab.fin.df$epr.polar),sum.vars],
                     title = "Summary statistics: Afrobarometer, rounds 4-6",
                     omit.stat = c("adj.rsq","ser"), covariate.labels = sum.var.labs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)

# Correlates of Missing values of fear_eviol #####
#   Polarization does not correlate with missing data. 
ab.fin.df$fear.miss <- 1
ab.fin.df$fear.miss[!is.na(ab.fin.df$fear_eviol)] <- 0
summary(felm(fear.miss ~ epr.polar + log.pop  + sex +  age + educ + urban | factor(cowround) | 0 | district_id, 
             data = ab.fin.df[ab.fin.df$majoritarian==1 ,]))


###########################################
# MAIN ANALYSIS ###########################
###########################################

# Fear of Election Violence ####
#   Produces Table A12 and rows 1-3 in Figure 6

# ... estimate
res.main <- list(felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov), fe = fe.main, se = se.cluster),
                      data = ab.fin.df[ab.fin.df$majoritarian==1 ,]),
                 felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov), fe = fe.main, se = se.cluster),
                      data = ab.fin.df[ab.fin.df$majoritarian==0 ,]),
                 felm(make_form(dv = "fear_eviol", expl = c(main.expl, "epr.polar:pr", paste0(main.cov, "*pr")), 
                                fe = fe.main, se = se.cluster),
                      data = ab.fin.df))

# ... prepare print
add.lines <- list(c("Sample:",paste0("\\multicolumn{1}{c}{",c("Maj. \\& Mix.","PR","all"),"}")),
                  c("Covariates:",paste0("\\multicolumn{1}{c}{",c("yes","yes","yes"),"}")),
                  latex.cow.roundfe(3),latex.mean.dv(res.main))
these.notes <- gsub("respondent's education.",
                    "respondent's education. Model 3 also includes interactions of all covariates with the PR dummy.",
                    latex.notes)
these.notes <- gsub("\\textwidth", ".76\\textwidth",these.notes, fixed = T)

# ... save
fileConn<-file(paste0(tab.path,"tablea12.tex"))
writeLines(stargazer(res.main,title="Local ethnic polarization \\& fear of pre-election victimization",
                     dep.var.labels=rep("Fear",3),multicolumn=F,# se = se,
                     notes.align = "l",label="tab_ab_main",align =T,#keep=c(0:5),
                     add.lines = add.lines,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = these.notes,
                     keep = c("epr.polar"),
                     covariate.labels = c("Ethno-pol. polarization", "Ethno-pol. polar. $\\times$ PR"), 
                     notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="7pt"), 
           fileConn)
close(fileConn)


# Robustness checks ############
#   Produces Table A14

# ... estimate
res.rob <- list(felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov, "polar", "log(0.001 + nightlights.pp)", "urb.pop.ln"), 
                               fe = fe.main, se = se.cluster),
                     data = ab.fin.df[ab.fin.df$majoritarian==1 ,]),
                felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov), fe = fe.main, se = se.cluster),
                     data = ab.fin.df[ab.fin.df$majoritarian==1 & ab.fin.df$year >= ab.fin.df$map.from,]),
                felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov,
                                                           "same_language" , "others_check" , "others_influence" ,
                                                           "others_present" , "survey_sponsor"), 
                               fe = fe.main, se = se.cluster),
                     data = ab.fin.df[ab.fin.df$majoritarian==1 ,]))

# ... prepare table
add.lines <- list(c("Sample:",paste0("\\multicolumn{1}{c}{",rep("Maj. \\& Mix.",3),c(""," \\&",""),"}")),
                  c("",paste0("\\multicolumn{1}{c}{",c("","t $\\geq$ t$_{SIDE}$","", ""),"}")),
                  c("Covariates",paste0("\\multicolumn{1}{c}{",c("yes","yes","yes"),"}")),
                  c("Add. controls",paste0("\\multicolumn{1}{c}{",c("","","Quality items"),"}")),
                  latex.ind.cont(3),
                  latex.cow.roundfe(3),latex.mean.dv(res.rob))

# ... save
fileConn<-file(paste0(tab.path,"tablea14.tex"))
writeLines(stargazer(res.rob,title="Local ethnic polarization \\& fear of pre-election victimization",
                     dep.var.labels=rep("Fear",3),multicolumn=F,# se = se,
                     notes.align = "l",label="tab_ab_rob",align =T,
                     add.lines = add.lines, 
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = gsub("\\textwidth", ".76\\textwidth",latex.notes, fixed = T),
                     keep = c("epr.polar", "polar","nightlights.pp", "urb.pop.ln"),
                     covariate.labels = c("Ethno-pol. polarization", "Ethnic polarization","Nightlights/capita (log)", "Urban population (log)"), 
                     notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)



# Standard error clustering ###############
#   Produces Table A15

# ... estimate
cluster.ls <- c("district_id", "district_id + lat + long + year", "adm1_code", "cowround")
model.ls <- lapply(cluster.ls, function(c){
  felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov), fe = fe.main, se = c),
       data = ab.fin.df[ab.fin.df$majoritarian==1 ,], keepCX = T, keepX = T)
})
cse.ls <- lapply(model.ls, function(m){
  diag(m$clustervcv)^.5
})

# ... estimate Conley's errors
source("scripts/functions/Conley_HAC.R")
c.se <- ConleySEs(reg = model.ls[[2]],unit = "district_id", 
                  time = "year",
                  lat = "lat", lon = "long",
                  kernel = "bartlett", dist_fn = "Haversine", dist_cutoff = 500, 
                  lag_cutoff = 60,
                  cores = 1, 
                  verbose = TRUE)
cse.ls[[2]] <- diag(as.matrix(c.se$Spatial_HAC))^0.5

# ... prepare table
add.lines <- list(c("Cluster-level",paste0("\\multicolumn{1}{c}{",c("District","Conley","Region", "Country-round"),"}")),
                  c("Sample:",paste0("\\multicolumn{1}{c}{",rep("Maj. \\& Mix.",length(model.ls)),c("","","",""),"}")),
                  latex.ind.cont(length(model.ls)),
                  latex.cow.roundfe(length(model.ls)),latex.mean.dv(model.ls))
if(stars.off){
  these.notes <- "\\parbox[t]{.9\\textwidth}{\\textit{Notes:} OLS linear models. 
Control variables include the district population (logged), and urban and female dummy, age and its square, 
  as well as the respondent's education. }"

} else {
  these.notes <- "\\parbox[t]{.9\\textwidth}{\\textit{Notes:} OLS linear models. 
Control variables include the district population (logged), and urban and female dummy, age and its square, 
as well as the respondent's education.}"
}
# ... save table
fileConn<-file(paste0(tab.path,"tablea15.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& fear of pre-election victimization",
                     dep.var.labels=rep("Fear",4),multicolumn=F, se = cse.ls,
                     notes.align = "l",label="tab_ab_ses",align =T,
                     keep = c("epr.polar"),
                     covariate.labels = c("Ethno-pol. polarization"),
                     add.lines = add.lines,
                     omit.stat = c("adj.rsq","res.dev","ser"), 
                     notes = these.notes,
                     notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)

# Pre-2014 ###############################
#   Produces Table A16

# ... estimate
model.ls <- list(felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov), fe = fe.main, se = se.cluster),
                      data = ab.fin.df[ab.fin.df$majoritarian==1 & ab.fin.df$year <= 2013,]),
                 felm(make_form(dv = "fear_eviol", expl = c(main.expl, main.cov), fe = fe.main, se = se.cluster),
                      data = ab.fin.df[ab.fin.df$majoritarian==0 & ab.fin.df$year <= 2013 ,]),
                 felm(make_form(dv = "fear_eviol", expl = c(main.expl, "epr.polar:pr", paste0(main.cov, "*pr")), 
                                fe = fe.main, se = se.cluster),
                      data = ab.fin.df[ab.fin.df$year <= 2013 ,]))

# ... prepare print
add.lines <- list(c("Sample:",paste0("\\multicolumn{1}{c}{",c("Maj. \\& Mix.","PR","all"),"}")),
                  c("Covariates:",paste0("\\multicolumn{1}{c}{",c("yes","yes","yes"),"}")),
                  latex.cow.roundfe(3),latex.mean.dv(model.ls))
these.notes <- gsub("respondent's education.",
                    "respondent's education. Model 3 also includes interactions of all covariates with the PR dummy.",
                    latex.notes)
these.notes <- gsub("\\textwidth", ".76\\textwidth",these.notes, fixed = T)

# ... save
fileConn<-file(paste0(tab.path,"tablea16.tex"))
writeLines(stargazer(model.ls,title="Local ethnic polarization \\& fear of pre-election victimization: Pre-2014",
                     dep.var.labels=rep("Fear",3),multicolumn=F,# se = se,
                     notes.align = "l",label="tab_ab_pre2014",align =T,#keep=c(0:5),
                     add.lines = add.lines,
                     omit.stat = c("adj.rsq","res.dev","ser"),
                     notes = these.notes,
                     keep = c("epr.polar"),
                     covariate.labels = c("Ethno-pol. polarization", "Ethno-pol. polar. $\\times$ PR"), 
                     notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="7pt"), 
           fileConn)
close(fileConn)


##########################################
# Threats in Nigeria and Uganda ##########
##########################################


# Prepare 

# ... load data
niguga.df <- readRDS(file.path("data", "afrobarometer_niguga.rds"))



# Prepare Analysis #################

# Outcomes
dep.vars <- c("electhreat" ,"electhreat.safe"   , "electhreatcom", "electhreatcom.safe")
dep.vars.labs.wb <- c("\\sc{Personal threat:\\lb frequency}","\\sc{Personal threat:\\lb security}",
                   "\\sc{Community threat:\\lb frequency}","\\sc{Community threat\\lb security}")
dep.vars.labs <- c("Personal threat: frequency","Personal threat: security",
                   "Community threat: frequency","Community threat security")


# Summary table ####################
#   Produces Table A11

# ... variables
sum.vars <- c(dep.vars,"epr.polar", "majoritarian", "pr", "log.pop",
              "urban","sex","age","educ","same_language" , "others_check" , 
              "others_influence" ,"others_present" )

# ... labels
sum.var.labs <- c(dep.vars.labs, "Ethno-pol. polarization",
                  "Majoritarian \\& mixed", "PR (pure)","Population (log)", "Urban",
                  "Female","Age", "Education", "Same language as interviewer", 
                  "Others checked during interview", "Others influenced", "Others present")

# ... save
fileConn<-file(paste0(tab.path,"tablea11.tex"))
writeLines(stargazer(niguga.df[!is.na(niguga.df$epr.polar),sum.vars],
                     title = "Summary statistics: Afrobarometer, Nigeria (3.5) \\& Uganda (4.5)",
                     omit.stat = c("adj.rsq","ser"), covariate.labels = sum.var.labs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)

# Analysis #########################
#   Produces Table A13 and rows 4-7 in Figure 6

# Main

# ... estimate
model.ls <- lapply(dep.vars, function(dv){
  felm(make_form(dv = dv, expl = c(main.expl, main.cov), fe = fe.main, se = se.cluster),
       data = niguga.df)
})

# ... prepare table
add.lines <- list(c("Sample:",paste0("\\multicolumn{1}{c}{",rep("NIG \\& UGA",4),"}")),
                  latex.ind.cont(4),
                  latex.cow.roundfe(4),latex.mean.dv(model.ls))

# ... save table
fileConn<-file(paste0(tab.path,"tablea13.tex"))
writeLines(stargazer(model.ls,title = "Local ethnic polarization \\& pre-election threats: Nigeria 2007 and Uganda 2010/2011",
                     dep.var.labels = dep.vars.labs.wb,multicolumn = F, 
                     notes.align = "l",label="tab_ab_niguga",align =T,
                     keep = c("epr.polar"),
                     covariate.labels = c("Ethno-pol. polarization"),
                     add.lines = add.lines,
                     omit.stat = c("adj.rsq","res.dev","ser"), notes = latex.notes,
                     notes.append = F,notes.label = "",  star.char = star.char, star.cutoffs = star.cutoffs,
                     font.size = "scriptsize", column.sep.width ="0pt"), 
           fileConn)
close(fileConn)


##########################################
# MAIN COMBINED PLOT #####################
##########################################
#   Produces Figure 6 from main results
# Combined plot -- all results 

# ... prepare

# ... Uganda and Nigeria
plot1.df <- as.data.frame(do.call(rbind, lapply(model.ls, function(m){
  this.pos <- which(rownames(m$coefficients) == "epr.polar")
  c(coef = m$coefficients[this.pos, 1] / sd(m$response), 
    se = m$clustervcv[this.pos, this.pos]^.5  / sd(m$response))
})))
plot1.df$N <- c(7, 6,5,4)
plot1.df$Sample <- "Majoritarian"

# ... All Africa
m <- res.main[[3]]
coef.ids <- c("epr.polar", "epr.polar:pr")
plot2.df <- data.frame(coef = c(m$coefficients[coef.ids, 1],
                                m$coefficients[coef.ids[1], 1] + m$coefficients[coef.ids[2], 1])/ sd(m$response),
                       se = c(diag(m$clustervcv[coef.ids, coef.ids])^.5,
                              (m$clustervcv[coef.ids[1], coef.ids[1]] + m$clustervcv[coef.ids[2], coef.ids[2]] + 2*m$clustervcv[coef.ids[1], coef.ids[2]])^.5
                       )/ sd(m$response),
                       stringsAsFactors = F)
plot2.df$N <- c(10.5, 9.5, 10)
plot2.df$coef[2] <- plot2.df$coef[2]  * -1
plot2.df$Sample <- c("Majoritarian","Difference", "Proportional")

plot.df <- rbind(plot1.df, plot2.df)
plot.df$Sample <- factor(plot.df$Sample, levels =  c("Majoritarian", "Proportional","Difference"), ordered = T)

# ... plot
png(file=paste0(fig.path,"figure6.png"), width = 7, height=3.5, units = "in", res = 300)
g <- ggplot(plot.df, aes(x = coef, y = N, pch = Sample)) + 
  geom_segment(aes(x = coef + se * 1.96,
                   xend = coef - se * 1.96,
                   y = N, yend = N)) + 
  theme_minimal() +
  geom_point()  + geom_vline(xintercept = 0, col = "grey", lty = 2) +
  xlab("Standardized effect of ethno-political polarization") +
  scale_y_continuous(breaks = c(11, 10,8,7,6,5,4),
                     labels = c("Full Afrobarometer sample:",
                                "Fear of campaign violence",
                                "Uganda ('10/'11) & Nigeria ('07):",
                                "Threat to respondent: Frequency", "Threat to respondent: Security-related",
                                "Threat to community: Frequency", "Threat to community: Security-related"),
                     limits = c(4, 11))+ 
  theme(axis.ticks.y = element_blank(),
        axis.text.y= element_text(face=ifelse(c(11, 10,8,7,6,5,4) %in% c(11, 8),
                                              "bold","plain"))) +
  labs(pch = "Legend") +
  ylab(NULL)
print(g)
dev.off()
