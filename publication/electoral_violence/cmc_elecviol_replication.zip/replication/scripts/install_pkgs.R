###########################################
# ETHNO-POLITICAL POLARIZATION AND PRE-ELECTION VIOLENCE
#
# PACKAGES
#
# Carl Müller-Crepon, JPR, 2020
###########################################

pkg.ls <- c()

pcks <- c("lfe",    "stargazer",    "ggplot2",  
           "plyr",   "MASS",  "rgeos",   "rgdal",  "countrycode",
          "sp", "spdep", "parallel", "foreach", "splitstackshape", 
          "geosphere", "gtools")
for(p in pcks){
  if(!p %in% installed.packages()[,"Package"]){
    print(p)
    install.packages(p)
  }
}
