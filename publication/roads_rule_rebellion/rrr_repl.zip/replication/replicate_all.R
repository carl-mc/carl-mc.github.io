##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Main Replication File
#
# Journal of Conflict Resolution, 2020
#
# Carl Müller-Crepon, Philipp Hunziker, Lars-Erik Cederman
# 
# Corresponding author: carl.muller-crepon@politics.ox.ac.uk
###########################################


# Clean up
rm(list = ls())

# Set working directory
setwd("replication")

# INIT GLOBALS, FUNCTIONS & LIBRARIES ##
#'   Generates paths, functions and loads libraries need for the analysis.
source("scripts/prepare_functions.R")

# LOAD DATA ###########
#'   Loads the main data needed for the analysis.
source("scripts/prepare_data.R")

# MAIN SPECIFICATION ##
#'   Sets up the main OLS and IV specifications used throughout. 
source("scripts/prepare_specification.R")


# //////////////////////////////////////////////////////////////////////////
############################################################################
# MAIN PAPER ###############################################################
############################################################################
# //////////////////////////////////////////////////////////////////////////

# TABLES
#'   Replicates Tables 1-3 in the main paper.
#'   Note that Table 3 is a composite, made out of two regression tables
#'   produced by the below code (iv.reduced.tex and iv.allhyp.tex)
source("scripts/main_tables.R")


# FIGURES
#'    Replicates Figures 1-3 in the main paper
source("scripts/main_figures.R")



# //////////////////////////////////////////////////////////////////////////
############################################################################
# APPENDIX #################################################################
############################################################################
# //////////////////////////////////////////////////////////////////////////

# DESCRIPTIVE STATISTICS
source("scripts/appendix_descriptives.R")


# ROBUSTNESS CHECKS: OLS
source("scripts/robcheck_ols.R")


# ROBUSTNESS CHECKS: IV ANALYSIS
source("scripts/robcheck_iv.R")


# ROBUSTNESS CHECKS: CROSS-SECTION
# (OLS and IV)
source("scripts/robcheck_crosssection.R")


# ROBUSTNESS CHECKS: COMBINED PLOT
source("scripts/robcheck_plot.R")


# APPENDIX: ADDITIONAL PLOTS AND MAPS
source("scripts/appendix_mapsplots.R")



