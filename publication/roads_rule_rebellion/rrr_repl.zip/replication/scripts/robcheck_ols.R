##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- OLS Robustness Checks ---
#
# Called from ../replicate_all.R
#
###########################################


############################################
# ALTERNATIVE DEPENDENT VARIABLE SPECIFICATION
############################################

##############################
# Disaggregate Buckets 
## -- Appendix A4.1, Figure A8
stub <- "disaggviol"

# Setup
these.dep.vars <- c("rebel.num", "militia.num",
                    "acled.rebel.m.count", "acled.militia.count",
                    "acled.staterebel.count", "acled.statemilitia.count")
these.labels <- c("Rebel groups","Militias","Rebels vs. all challengers", "Militias vs. all challengers",
                  "Rebels vs. State","Militias vs. State")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Disaggregated types of violence, OLS",
            dep.var.caption = "Dependent variable (logged events)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub


###############################
# Linear probability
## -- Appendix A4.1, Figure A9
stub <- "linprob"

# Setup
form.str <- paste0("I(", dv, ">0)"," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Linear probability models, OLS",
            dep.var.caption = "Dependent variable (\\textgreater 0)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub

##################################################
# Fatalities #####################################
## -- Appendix A4.1, Figure A9
stub <- "fatal"

# Setup
these.dep.vars <- gsub("count","fatal",dv[grepl(".count",dv)])
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels)-1)),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels)-1)),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Fatalities, OLS",
            dep.var.caption = "Dependent variable (logged fatalities)",dep.var.labels.include = FALSE,
            column.labels = dv.labels[which(grepl(".count",dv))],
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub


##################################################
# ACLED ############################################
## -- Appendix A4.1, Figure A9
stub <- "acledevents"

# Setup
these.dep.vars <-c("acled.riot.demo.count" ,"acled.viol.civil.count", "acled.battle.count", "acled.remote.viol.count")
these.labels <- c("riot/demo", "OSV", "battles", "remote violence")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",4)),
                  latex.any.row("Controls: ",rep("yes",4)),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="ACLED Events, OLS",
            dep.var.caption = "Dependent variable (logged events)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub

##################################################
# GED ############################################
## -- Appendix A4.1, Figure A9
stub <- "gedevents"

# Setup
these.dep.vars <-c("state.events","onesided.events","nonstate.events")
these.labels <- c("civil war", "OSV", "non-state")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",3)),
                  latex.any.row("Controls: ",rep("yes",3)),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="UCDP GED Events, OLS",
            dep.var.caption = "Dependent variable (logged events)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub

##################################################
# SCAD ############################################
## -- Appendix A4.1, Figure A9
stub <- "scadevents"

# Setup
these.dep.vars <-c("scad.provgov.count" , "scad.anti.gov.count" ,"scad.extra.gov.count")
these.labels <- c("pro-gov. militia", "anti-gov. militia", "extra-gov. militia")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",3)),
                  latex.any.row("Controls: ",rep("yes",3)),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="SCAD Events, OLS",
            dep.var.caption = "Dependent variable (logged events)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)


# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub




###################################################
# FUNCTIONAL FORM #################################
###################################################
## -- Appendix A4.2

#########################
# Logits ################
## -- Appendix A4.2, Figure A10

stub <- "logistic"
# Setup
cluster.logit <- "cowcode"
logit.spec <- c(paste(expl.global, " + ", main.controls),
                paste(expl.global, " + ", main.controls , " + ", add.controls),
                paste("0 +",expl.global, " + ", main.controls , " + factor(cowcode)"),
                paste("0 +",expl.global, " + ", main.controls , " + ", add.controls, " + factor(cowcode) + factor(year)"))
form.str <- paste0("I(",dv,">0) ~ ", logit.spec[4])

# Estimation
this.m <- lapply(form.str, function(form.str){
  data.m <- na.omit(data.main[,unlist(lapply(colnames(data.main), function(v){grepl(v, paste(cluster.global,form.str))}))])
  m <- glm(as.formula(form.str), data = data.m, family = binomial(link = "logit"))
  m$clustervcv <- cl.glm(m, data.m[,cluster.logit], print = F)
  return(m)
})


# Results
add.lines <- list(latex.any.row("Country FE: ",c("yes","yes","yes")),
                  latex.any.row("Year FE: ",c("yes","yes","yes")),
                  latex.any.row("Controls: ",c("yes","yes","yes")))

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,se = lapply(this.m, function(m){ diag(m$clustervcv)^.5 }),
            title="Logistic regression",
            dep.var.caption = "Dependent variable (\\textgreater 0)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep=ols.keep,covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
this.safe <- lapply(1:length(this.m), function(m){
  r <- extract_coef(list(this.m[[m]]))[[1]]
  r$dv <- dv[m]
  r$coef <- as.matrix(r$coef, ncol = 1)
  r
})
all.coef.ls$ols[[stub]] <- NULL
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(this.safe))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub


#########################################
# Negative Binomial Model ###############
## -- Appendix A4.2, Figure A10

stub <- "negbin"
# Setup
cluster.logit <- "cowcode"
negbin.spec <- c(paste(expl.global, " + ", main.controls),
                 paste(expl.global, " + ", main.controls , " + ", add.controls),
                 paste("0 +",expl.global, " + ", main.controls , " + factor(cowcode)"),
                 paste("0 +",expl.global, " + ", main.controls , " + ", add.controls, " + factor(cowcode) + factor(year)"))
form.str <- paste0(dv, " ~ ", negbin.spec[4])

# Estimation
this.m <- lapply(form.str, function(form.str){
  data.m <- na.omit(data.main[,unlist(lapply(colnames(data.main), function(v){grepl(v, paste(cluster.global,form.str))}))])
  m <- glm.nb(as.formula(form.str), data = data.m)
  m$clustervcv <- cl.glm(m, data.m[,cluster.logit], print = F)
  return(m)
})


# Results
add.lines <- list(latex.any.row("Country FE: ",c("yes","yes","yes")),
                  latex.any.row("Year FE: ",c("yes","yes","yes")),
                  latex.any.row("Controls: ",c("yes","yes","yes")))

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,se = lapply(this.m, function(m){ diag(m$clustervcv)^.5 }),
            title="Negative Binomial Models",
            dep.var.caption = "Dependent variable (count)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep=ols.keep,covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
this.safe <- lapply(1:length(this.m), function(m){
  r <- extract_coef(list(this.m[[m]]))[[1]]
  r$dv <- dv[m]
  r$coef <- as.matrix(r$coef, ncol = 1)
  r
})
all.coef.ls$ols[[stub]] <- NULL
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(this.safe))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub



############################################
# 1990 ROAD NETWORK
############################################
## -- Appendix A4.3, Figure A7

stub <- "road1990"

# Setup
form.str <- paste0(dep.global," ~ ", gsub("1966","1990",spec.ols))

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})

# Results short
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)


fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Relational state capacity and violence in Africa 1997--2016: OLS, roads from 1990",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= ols.keep, covariate.labels = gsub("1966","1990",ols.labels),
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub



###################################################
# ADDITIONAL CONTROLS #############################
###################################################
## -- Appendix A4.4, Figure A7

################################
# Vary Covariates
################################
## -- Appendix A4.4, Figure A7

# Landcover vars (>10%)
landcover.vars <- c("Pasturelandusedforgrazing", "Savanna" , "Tropicalwoodland", "Tropicalforest")


# Setup a vector of additional terms
spec.controls <- c(precol =  "v33.num + v28.num + v2.num + v3.num + v4.num + v5.num",
                   landcover = paste(landcover.vars, collapse = "+"),
                   external = paste0("log(pop.ext) + log(pop.urban.ext + 1) +  log(poly.area.km2.ext) +  log(road.totinv.ext.1966 +1) + ",
                                     paste(c("median.altitude.ext","median.slope.ext", "precipitation.ext", "evapotranspiration.ext",  "ppetratio.ext" , "temperaturemean.ext","log(dist.coast.ext)"),
                                           collapse = "+")))
spec.controls <- c(allcontrols = paste(spec.controls, collapse = "+"))
table.names <- c("All controls")

# Estimate
for(ac in c(1:length(spec.controls))){
  stub <- names(spec.controls)[ac]
  print(stub)
  # Setup
  add.spec <- paste(expl.global, " + ", spec.controls[ac], " + ", main.controls , " + ", add.controls, 
                    fe.global, " 0 |", cluster.global)
  form.str <- paste0(dep.global, " ~ ", add.spec)
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Additional controls: ",rep("yes",length(dv.labels))),
                    latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                    mean.dv, f.stat)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title= paste("Additional controls, OLS:",table.names[ac]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = dv.labels,
              keep= ols.keep, covariate.labels = ols.labels,
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.ols(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$ols <- c(all.coef.ls$ols,
                       list(extract_coef(this.m)))
  names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub
  
}


################################
# No controls
################################
## -- Appendix A4.4, Figure A7

stub <- "nocontrols"

# Setup
this.ols <- paste(" rsc.1966  +  I(log(1/(foot.capital.mean.1966 + 1))) +  I(log(1/(foot.internal.mean.1966 + 1)))  ", 
                  fe.global, " 0 |", cluster.global)

form.str <- paste0(dep.global," ~ ", this.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results short
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("no",length(dv.labels))),
                  mean.dv, f.stat)


fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Only road travel, OLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= 1:3, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub



################################
# Matching
################################
## -- Appendix A4.4, Figure A7
stub <- "matching"

# Setup
form.str <- paste0(dep.global," ~ ", gsub("| cow.year |","| cow.year  + match |",spec.ols, fixed = T))

# Estimation
this.m <- lapply(form.str, function(s){
  d <- data.main
  d$match <- NA
  
  for(c in unique(na.omit(d$cowcode))){
    t.o <- d$cowcode == c & !is.na(d$cowcode)
    q = 1/max(1,round((sum(t.o) / length(unique(d$year[t.o]))) / 25))
    d$match[t.o] <- paste0(c, ".",  d$year[t.o], ".",
                           ".", as.numeric(cut(d$foot.capital.mean.1966[t.o], breaks = unique(quantile(d$foot.capital.mean.1966[t.o & !is.na(d[,dv[1]])], 
                                                                                                       probs = unique(c(seq(0, 1, by = q),1)), na.rm = T)),
                                               include.lowest = T, ordered_result =  T)),
                           ".", as.numeric(cut(d$foot.internal.mean.1966[t.o], breaks = unique(quantile(d$foot.internal.mean.1966[t.o & !is.na(d[,dv[1]])], 
                                                                                                        probs = unique(c(seq(0, 1, by = q),1)), na.rm = T)),
                                               include.lowest = T, ordered_result =  T)),
                           ".", as.numeric(cut(d$pop[t.o], breaks = unique(quantile(d$pop[t.o & !is.na(d[,dv[1]])], 
                                                                                    probs = unique(c(seq(0, 1, by = q),1)), na.rm = T)),
                                               include.lowest = T, ordered_result =  T)))
  }
  m <- felm(as.formula(s), data = d)
  m
})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Distance-population-country-year bins: ", unlist(lapply(this.m, function(m) length(unique(m$fe[["match"]]))))),
                  latex.any.row("Country-year FE: ",rep("--",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Distance-population bins: OLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub


# Unique buckets
length(unique(this.m[[1]]$fe$match))


###################################################
# RESTRICTING THE SAMPLE ##########################
###################################################
## -- Appendix A4.5, Figure A7

##########################
# Drop very small units
##########################
## -- Appendix A4.5, Figure A7

stub <- "nosmallunit"


# Setup
form.str <- paste0(dep.global," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), 
                                            data = data.main[data.main$poly.area.km2 > quantile(data.main$poly.area.km2, 0.25, na.rm = T), ])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title= paste0("Units of size \\textgreater 25th quantile (",
                          round(quantile(data.main$poly.area.km2, 0.25, na.rm = T))," km$^2$), OLS"),
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"),multicolumn = F, star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)


# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub


##########################
# Drop Border-Crossing Units
##########################
## -- Appendix A4.5, Figure A7

stub <- "nobordercross"

# Setup
form.str <- paste0(dep.global," ~ ", spec.ols)

# Border-crossing units 
data.bordercross <- aggregate(list(cross = data.main$ethno.id),
                              data.main[,c("NAM_LABEL", "year")], FUN = length)
data.bordercross$cross = data.bordercross$cross > 1
sum(data.bordercross$cross)
data.cross <- join(data.main, data.bordercross, by = c("NAM_LABEL", "year"), type = "left")

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), 
                                            data = data.cross[!data.cross$cross, ])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="No Border-Crossing ethnic groups, OLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub



###################################################
# ALTERNATIVE UNITS OF ANALYSIS ###################
###################################################
## -- Appendix A4.6, Figure A7

table.names <- c("Ethnologue ethnic groups", "GREG ethnic groups", "Murdock ethnic groups")
for(d in  c(2,3)){
  stub <- paste0("unit.",names(data.ls)[d])
  print(stub)
  # Setup
  form.str <- paste0(dep.global, " ~ ", spec.ols)
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.ls[[d]])})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                    mean.dv, f.stat)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title=paste("Alternative units of analysis, OLS:",table.names[[d]]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = dv.labels,
              keep= ols.keep, covariate.labels = ols.labels,
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.ols(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$ols <- c(all.coef.ls$ols,
                       list(extract_coef(this.m)))
  names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub
  
}



#####################################
# COUNTRY-LEVEL JACKKNIFE ###########
#####################################
## -- Appendix A4.7, Table A4
stub <- "cowjackknife"

# Setup
form.str <- paste0(dep.global," ~ ", spec.ols)
countries <- as.character(na.omit(unique(data.main$cntry_name)))
countries <- countries[order(countries)]

# Estimation
this.m <- unlist(lapply(countries, function(c){lapply(form.str, function(s){
  # print(c)
  felm(as.formula(s),  data = data.main[data.main$cntry_name != c,])
})}),
recursive = F)

# Plot

# ... prepare plot data
plot.df <- data.frame(do.call(rbind, 
                              lapply(this.m,function(m){
                                pos <- which(grepl("rsc.1966", rownames(m$coefficients)))[1]
                                c(coef = m$coefficients[pos,1],
                                  se =  m$clustervcv[pos, pos]^0.5)
                              })))
plot.df$label <- rep(c(countries),each = length(dv.labels))
plot.df$pos <- rep(c(length(countries):1), each = length(dv.labels))
plot.df$Specification <- rep(paste0(dv.labels, " (log)"), length(countries))


# ... save data
cow.jack.df <- plot.df
cow.jack.df$Method <- "OLS"




###################################################
# ALTERNATIVE MECHANISMS ##########################
###################################################
## -- Appendix A4.9, Table A4

# ... specifications for alternative mechanisms
alt.mechanisms <- c(am.transethnic = paste(paste0(c("log(1/(1+road.external.mean.","log(1/(1+foot.external.mean."), 1966, "))"), collapse = "+"),
                    am.development = paste0(" log(road.totinv.1966 +1) + log(nightlights+1) + I(nightlights>0)"))
alt.mechanisms <- c(am.all = paste(alt.mechanisms, collapse = "+"),alt.mechanisms)
these.keep <- c(5,2,3,2)
these.labels <- list(c("External connectedness (log)","External connectedness; foot (log)"),
                     c("Roads (km x quality)", "Nightlights (log)", "Nightlights \\textgreater 0"))
these.labels <- c(list(unlist(lapply(c(1:2),function(x) these.labels[x]))),
                  these.labels)
table.names <- c("Alternative mechanisms","Trans-ethnic road connectedness", "Local development")
# ... estimate models
for(ac in c(1:length(alt.mechanisms))){
  stub <- names(alt.mechanisms)[ac]
  print(stub)
  # Setup
  add.spec <- paste(expl.global, " + ", alt.mechanisms[ac], " + ", main.controls , " + ", add.controls, 
                    fe.global, " 0 |", cluster.global)
  form.str <- paste0(dep.global, " ~ ", add.spec)
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                    mean.dv, f.stat)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title=paste("Alternative Mechanisms, OLS:",table.names[ac]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = dv.labels,
              keep= c(1:(length(ols.keep)+these.keep[ac])), covariate.labels = c(ols.labels, these.labels[[ac]]),
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.ols(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$ols <- c(all.coef.ls$ols,
                       list(extract_coef(this.m)))
  names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub
}
