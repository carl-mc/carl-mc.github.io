##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Instrumental Variable Analysis Robustness Checks ---
#
# Called from ../replicate_all.R
#
###########################################


############################################
# ALTERNATIVE DEPENDENT VARIABLE SPECIFICATION
############################################

##############################
# Disaggregate Buckets
## -- Appendix A4.1, Figure A8

stub <- "iv.disaggviol"

# Setup
these.dep.vars <- c("rebel.num", "militia.num",
                    "acled.rebel.m.count", "acled.militia.count",
                    "acled.staterebel.count", "acled.statemilitia.count")
these.labels <- c("Rebel groups","Militias","Rebels vs. all challengers", "Militias vs. all challengers",
                  "Rebels vs. State","Militias vs. State")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",4)),
                  latex.any.row("Controls: ",rep("yes",4)),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Disggregated types of violence, 2SLS",
            dep.var.caption = "Dependent variable (logged event count)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub

###############################
# Linear probability ##########
## -- Appendix A4.1, Figure A9
stub <- "iv.linprob"

# Setup
form.str <- paste0("I(", dv, ">0)"," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Linear probability models, 2SLS",
            dep.var.caption = "Dependent variable (\\textgreater 0)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)


# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


##################################################
# Fatalities #####################################
## -- Appendix A4.1, Figure A9
stub <- "iv.fatal"

# Setup
these.dep.vars <- gsub("count","fatal",dv[grepl(".count",dv)])
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels)-1)),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels)-1)),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Fatalities, 2SLS",
            dep.var.caption = "Dependent variable (logged fatalities)",dep.var.labels.include = FALSE,
            column.labels = dv.labels[which(grepl(".count",dv))],
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)


# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


##################################################
# ACLED ##########################################
## -- Appendix A4.1, Figure A9
stub <- "iv.acledevents"

# Setup
these.dep.vars <-c("acled.riot.demo.count" ,"acled.viol.civil.count", "acled.battle.count", "acled.remote.viol.count")
these.labels <- c("riot/demo", "OSV", "battles", "remote violence")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",4)),
                  latex.any.row("Controls: ",rep("yes",4)),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="ACLED Events, 2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)


# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


##################################################
# GED ############################################
## -- Appendix A4.1, Figure A9
stub <- "iv.gedevents"

# Setup
these.dep.vars <-c("state.events","onesided.events","nonstate.events")
these.labels <- c("civil war", "OSV", "non-state")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",3)),
                  latex.any.row("Controls: ",rep("yes",3)),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="UCDP GED Events, 2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


##################################################
# SCAD ###########################################
## -- Appendix A4.1, Figure A9
stub <- "iv.scadevents"

# Setup
these.dep.vars <-c("scad.provgov.count" , "scad.anti.gov.count" ,"scad.extra.gov.count")
these.labels <- c("pro-gov. militia", "anti-gov. militia", "extra-gov. militia")
form.str <- paste0("log(", these.dep.vars, "+1)"," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",4)),
                  latex.any.row("Controls: ",rep("yes",4)),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="SCAD Events, 2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = these.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub




############################################
# INSTRUMENTED 1990 ROAD NETWORK
############################################
## -- Appendix A4.3, Figure A7
stub <- "iv.road1990"

# Setup
form.str <- paste0(dep.global," ~ ", spec.iv)
form.str <- gsub("1966","1990",form.str)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main[!is.na(data.main[,dv[1]]),])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )

add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat,f.stat.s1)


fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="IV simulated with 1990 road inputs, 2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


###################################################
# ADDITIONAL CONTROLS #############################
###################################################
## -- Appendix A4.4, Figure A7

################################
# Vary Covariates
################################
## -- Appendix A4.4, Figure A7

# Setup a vector of additional terms
# Landcover vars (>10%)
landcover.vars <- c("Pasturelandusedforgrazing", "Savanna" , "Tropicalwoodland", "Tropicalforest")

# Setup a vector of additional terms
spec.controls <- c(precol =  "v33.num + v28.num + v2.num + v3.num + v4.num + v5.num",
                   landcover = paste(landcover.vars, collapse = "+"),
                   external = paste0("log(pop.ext) + log(pop.urban.ext + 1) +  log(poly.area.km2.ext) + ",
                                     paste(c("median.altitude.ext","median.slope.ext", "precipitation.ext", "evapotranspiration.ext",  
                                             "ppetratio.ext" , "temperaturemean.ext","log(dist.coast.ext)"),
                                           collapse = "+")))
spec.controls <- c(allcontrols = paste(spec.controls, collapse = "+"))
table.names <- c("All controls")

# Estimate
for(ac in c(1:length(spec.controls))){
  stub <- paste0("iv.",names(spec.controls)[ac])
  print(stub)
  # Setup
  add.spec <- paste(spec.controls[ac], "+", spec.iv)
  form.str <- paste0(dep.global, " ~ ", add.spec)
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
  # 
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Additional controls: ",rep("yes",length(dv.labels))),
                    latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                    mean.dv, f.stat,f.stat.s1)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title= paste("Additional controls, 2SLS:",table.names[ac]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = dv.labels,
              order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.iv(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$iv <- c(all.coef.ls$iv,
                      list(extract_coef(this.m)))
  names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub
}

################################
# No controls
################################
## -- Appendix A4.4, Figure A7

stub <- "iv.nocontrols"

# Setup
form.str <- paste0(dep.global," ~ ", "I(log(1/(opt.foot.capital.mean.1880.1966 + 1))) + I(log(1/(opt.foot.internal.mean.1880.1966 + 1)))",  
                                           "| 0|", stage1.form, cluster.global)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main[!is.na(data.main[,dv[1]]),])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )

add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("no",length(dv.labels))),
                  mean.dv, f.stat,f.stat.s1)


fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="2SLS, no control variables",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


################################
# Matching
################################
## -- Appendix A4.4, Figure A7
stub <- "iv.matching"

# Setup
form.str <- paste0(dep.global," ~ ", gsub("| cow.year |","| cow.year  + match |",spec.iv, fixed = T))

# Estimation
this.m <- lapply(form.str, function(s){
  d <- data.main
  d$match <- NA
  for(c in unique(na.omit(d$cowcode))){
    t.o <- d$cowcode == c & !is.na(d$cowcode)
    q = 1/((sum(t.o) / length(unique(d$year[t.o]))) / 25)
    d$match[t.o] <- paste0(c, ".",  d$year[t.o], ".",
                           ".", as.numeric(cut(d$opt.foot.capital.mean.1880.1966[t.o], breaks = unique(quantile(d$opt.foot.capital.mean.1880.1966[t.o & !is.na(d[,dv[1]])], 
                                                                                                       probs = unique(c(seq(0, 1, by = q),1)), na.rm = T)),
                                               include.lowest = T, ordered_result =  T)),
                           ".", as.numeric(cut(d$opt.foot.internal.mean.1880.1966[t.o], breaks = unique(quantile(d$opt.foot.internal.mean.1880.1966[t.o & !is.na(d[,dv[1]])], 
                                                                                                        probs = unique(c(seq(0, 1, by = q),1)), na.rm = T)),
                                               include.lowest = T, ordered_result =  T)),
                           ".", as.numeric(cut(d$opt.pop.graph.1880.1966[t.o], breaks = unique(quantile(d$opt.pop.graph.1880.1966[t.o & !is.na(d[,dv[1]])], 
                                                                                    probs = unique(c(seq(0, 1, by = q),1)), na.rm = T)),
                                               include.lowest = T, ordered_result =  T)))
  }
  m <- felm(as.formula(s), data = d)
  m
})

# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )
 
add.lines <- list(latex.any.row("Distance-population-year bins: ", unlist(lapply(this.m, function(m) length(unique(m$fe[["match"]]))))),
                  latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
   stargazer(this.m,
             title="Distance-population bins: 2SLS",
             dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
             column.labels = dv.labels,
             order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
             notes.align = "l",label=paste0("tab.",stub),align =T,
             add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
             omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
             notes = latex.notes.iv(), notes.label = "", notes.append = F,
             type  = stargazer.type[1]), 
   fileConn)
close(fileConn)



# Unique buckets
length(unique(this.m[[1]]$fe$match))

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub



###################################################
# RESTRICTING THE SAMPLE ##########################
###################################################
## -- Appendix A4.5, Figure A7

##########################
# Drop very small units
##########################
## -- Appendix A4.5, Figure A7
stub <- "iv.nosmallunit"

# Setup
form.str <- paste0(dep.global," ~ ", spec.iv)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), 
                                            data = data.main[data.main$poly.area.km2 > quantile(data.main$poly.area.km2, 0.25, na.rm = T), ])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )

mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title=paste0("Units of size \\textgreater 25th quantile (",
                         round(quantile(data.main$poly.area.km2, 0.25, na.rm = T))," km$^2$), 2SLS"),
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub



##########################
# Drop Border-Crossing Units
##########################
## -- Appendix A4.5, Figure A7

stub <- "iv.nobordercross"

# Setup
form.str <- paste0(dep.global," ~ ", spec.iv)

# Border-crossing units 
data.bordercross <- aggregate(list(cross = data.main$ethno.id),
                              data.main[,c("NAM_LABEL", "year")], FUN = length)
data.bordercross$cross = data.bordercross$cross > 1
sum(data.bordercross$cross)
data.cross <- join(data.main, data.bordercross, by = c("NAM_LABEL", "year"), type = "left")

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), 
                                            data = data.cross[!data.cross$cross, ])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", round_any(unlist(lapply(this.m, function(m){m$stage1$iv1fstat$rsc.1990["F"]})), 0.01) )

mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat,f.stat.s1)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="No Border-Crossing ethnic groups, 2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            order = iv.keep, keep= iv.keep , covariate.labels = iv.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)


# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


###################################################
# ALTERNATIVE UNITS OF ANALYSIS ###################
###################################################
## -- Appendix A4.6, Figure A7

table.names <- c("Ethnologue ethnic groups", "GREG ethnic groups", "Murdock ethnic groups")
for(d in c(2,3)){
  stub <- paste0("iv.unit.",names(data.ls)[d])
  print(stub)
  # Setup
  # ... first stage
  form.str <- c(paste(endog.vars, " ~ ",paste(instr.vars, collapse = "+"),"+",iv.controls,
                      fe.global, 
                      "0 |", 
                      cluster.global))
  # ... second stage
  form.str <- c(form.str, paste0(dep.global," ~ ", spec.iv))
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.ls[[d]][!is.na(data.ls[[d]][,dv[1]]),])})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  f.stat.s1 <- latex.any.row("F-Stat Stage 1:", unlist(lapply(this.m, function(m){
    f <- m$stage1$iv1fstat
    if(class(f) == "try-error"| is.null(f)){ "" } else { as.character(round_any(f$rsc.1990["F"], 0.01))}
  })) )
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels)+1)),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels)+1)),
                    mean.dv, f.stat,f.stat.s1)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title=paste("Alternative units of analysis, 2SLS:",table.names[[d]]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = paste0(c(" Stage 1} &  & \\multicolumn{1}{c}{Stage 2} & \\\\ 
                                     \\cmidrule(lr){2-2} \\cmidrule(lr){3-5} & \\multicolumn{1}{c}{",rep("",3)),
                                     gsub(" (log)","",c(iv.labels[1],dv.labels), fixed = T)),
              order = c(stage1.keep,iv.keep), keep= c(stage1.keep,iv.keep) , covariate.labels = c(stage1.labels,iv.labels),
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.iv(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$iv <- c(all.coef.ls$iv,
                      list(extract_coef(this.m)))
  names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub
}



#####################################
# COUNTRY-LEVEL JACKKNIFE ###########
#####################################
## -- Appendix A4.7, Table A4
stub <- "iv.cowjackknife"

# Setup
form.str <- paste0(dep.global," ~ ", spec.iv)
countries <- as.character(na.omit(unique(data.main$cntry_name)))
countries <- countries[order(countries)]

# Estimation
this.m <- unlist(lapply(countries, function(c){lapply(form.str, function(s){
  print(c)
  felm(as.formula(s),  data = data.main[data.main$cntry_name != c,])
})}),
recursive = F)

# Plot

# ... prepare plot data
plot.df <- data.frame(do.call(rbind, 
                              lapply(this.m,function(m){
                                 pos <- which(grepl(paste0("rsc.1990"), rownames(m$coefficients)))
                                 c(coef = m$coefficients[pos,1],
                                   se =  m$clustervcv[pos, pos]^0.5)
                              })))
plot.df$label <- rep(c(countries),each = length(dv.labels))
plot.df$pos <- rep(c(length(countries):1), each = length(dv.labels))
plot.df$Specification <- rep(paste0(dv.labels, " (log)"), length(countries))


# ... save data for combined plot
plot.df$Method <- "2SLS"
cow.jack.df <- rbind(cow.jack.df, plot.df)




#################################################
# FIRST STAGE ROBUSTNESS CHECKS #################
#################################################
## -- Appendix A6.1

# DIFFERENT RESOLUTIONS OF SIMULATED NETWORKS ###
## -- Appendix A6.1, Table A6
stub <- "iv.opt.resolution"

# Set resolution
data.main$nw.resolution <- ifelse(data.main$area > 1e6, 3,
                                  ifelse(data.main$area > 1e5, 2,
                                         ifelse(data.main$area > 1e4, 1,
                                                ifelse(data.main$area > 1e3, 1/2,
                                                       1/3))))

# ... first stage
form.str <- c(paste(endog.vars, " ~ ",paste(instr.vars, collapse = "+"),"+",iv.controls,
                    fe.global, 
                    "0 |", 
                    cluster.global))

# ... estimate across resolutions
this.m <- lapply(c(1:3), function(s){felm(as.formula(form.str), data = data.main[!is.na(data.main[,dv[1]]) & data.main$nw.resolution == s,])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )

mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Resolution (dec. degrees): ",round_any(0.08333 * c(1:3), 0.001)),
                  latex.any.row("Country-year FE: ",rep("yes",length(dv.labels) + 1)),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels) + 1)),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="First stage estimation across resolutions of optimized networks",
            dep.var.caption = paste0("Dependent variable: ",iv.labels[1]),dep.var.labels.include = FALSE,
            column.labels = rep("",3),
            order = c(stage1.keep), keep= c(stage1.keep) , covariate.labels = c(stage1.labels),
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"),  star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,column.sep.width = "7pt",
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


# DIFFERENT SIZES OF ETHNIC GROUPS #######
## -- Appendix A6.1, Table A7

stub <- "iv.opt.groupsize"

# .... size quantiles
data.main$size.quant <- NA
data.main$size.quant[!is.na(data.main[,dv[1]])] <- as.numeric(as.factor(cut(data.main$poly.area.km2[!is.na(data.main[,dv[1]])], 
                                                                            breaks = quantile(data.main$poly.area.km2[!is.na(data.main[,dv[1]])], probs = seq(0, 1, by = 0.25), na.rm = T),
                                                                            include.lowest = T, ordered_result =  T)))

# ... first stage
form.str <- c(paste(endog.vars, " ~ ",paste(instr.vars, collapse = "+"),"+",iv.controls,
                    fe.global, 
                    "0 |", 
                    cluster.global))

# ... estimate across resolutions
this.m <- lapply(c(1:4), function(s){felm(as.formula(form.str), data = data.main[!is.na(data.main[,dv[1]]) & data.main$size.quant == s,])})


# Results
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )

mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Group area quartile: ",c(1:4)),
                  latex.any.row("Country-year FE: ",rep("yes",length(dv.labels) + 1)),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels) + 1)),
                  mean.dv, f.stat)

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="First stage estimation across geographic size of ethnic groups",
            dep.var.caption = paste0("Dependent variable: ",iv.labels[1]),dep.var.labels.include = FALSE,
            column.labels = rep("",4),
            order = c(stage1.keep), keep= c(stage1.keep) , covariate.labels = c(stage1.labels),
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"),column.sep.width = "-5pt", star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub




###########################
# HYDE-RELATED ROBUSTNESS CHECKS 
###########################
## -- Appendix A6.2 and A6.3



##########################
# Early vs. late HYDE ground truth data
## -- Appendix A6.2 , Figure A16

stub <- "iv.hydeyears"

# Load year with earliest subnational data:
hyde.yrs <- read.csv("data/hyde_firstyear.csv",
                     stringsAsFactors = F)
hyde.yrs$cowcode <- countrycode(hyde.yrs$country, origin = "country.name",
                                destination = "cown")

# Join
data.main <- join(data.main, 
                  hyde.yrs[, c("cowcode", "hydeyear")],
                  by = "cowcode", type = "left", match = "first")

# Median year: 1960
median(data.main$hydeyear, na.rm = T)

# Setup
form.str <- paste0(dep.global," ~ ", spec.iv)
# years <- seq(1960, 2000, by = 5)
years <- list(`full sample`= c(T, F),`yes` = T, `no` = F)
# Estimation
this.m <- unlist(lapply(form.str, function(s){
  lapply(years, function(y){
    felm(as.formula(s),  data = data.main[(data.main$hydeyear < 1960) %in% y, ])
    # felm(as.formula(s),  data = data.main[data.main$cowcode %in% c(hyde.yrs$cowcode[hyde.yrs$hydeyear < y]),])
  })
}), recursive = F)

# Plot
# ... prepare plot data
plot.df <- data.frame(do.call(rbind, 
                              lapply(this.m,function(m){
                                pos <- which(grepl(paste0("rsc.1990"), rownames(m$coefficients)))
                                c(coef = m$coefficients[pos,1],
                                  se =  m$clustervcv[pos, pos]^0.5)
                              })))
plot.df$year <- rep(names(years), length(dv.labels))
plot.df$year <- factor(plot.df$year, levels = unique(plot.df$year), ordered = T)
plot.df$Specification <- rep(dv.labels, each = length(years))

# ... plot
png(paste0(fig.path, stub, ".png"), height = 2.5, width = 7, res = 300, unit = "in")
print(ggplot(plot.df, aes(x = year, y = coef)) + geom_point() + 
        geom_errorbar(aes(ymin = coef - 1.96 * se, ymax = coef + 1.96 * se), width=.1) +
        geom_hline(yintercept = 0, color = "darkgrey", lty = 2) + 
        # scale_y_continuous(breaks = c( length(years):1), labels = years)  +
        xlab("Subnational census data in HYDE includes years from before 1960") + ylab(paste("Marginal Effect of\nRelational State Capacity"))  + 
        theme(axis.text.y  = element_text(size = 10, color = "black"),
              legend.position="top") + 
        facet_wrap( ~ Specification, nrow = 1)) 
dev.off()


## Countries by obs:
years <- seq(1960, 2000, by = 5)
cbind(year = years, 
      cownum = sapply(years, function(y){
        length(unique(data.main$cowcode[data.main$cowcode %in% c(hyde.yrs$cowcode[hyde.yrs$hydeyear < y])]))
      }),
      obsnum = sapply(years, function(y){
        sum(data.main$cowcode %in% c(hyde.yrs$cowcode[hyde.yrs$hydeyear < y]))
      }))

##########################
# Resolution of HYDE raster data
## -- Appendix A6.3 , Figure A17
stub <- "iv.nwrescheck"


# Setup
form.str <- paste0(dep.global," ~ ", spec.iv)
res <- c(`full sample`= NA,`30km` = 3,`20km` = 2,`10km` = 1)

# Estimation
this.m <- unlist(lapply(form.str, function(s){
  lapply(res, function(r){
    if(is.na(r)){
      felm(as.formula(s),  data = data.main)
    } else {
      felm(as.formula(s),  data = data.main[data.main$nw.resolution == r, ])
    }
  })
}), recursive = F)



# Plot
# ... prepare plot data
plot.df <- data.frame(do.call(rbind, 
                              lapply(this.m,function(m){
                                pos <- which(grepl(paste0("rsc.1990"), rownames(m$coefficients)))
                                c(coef = m$coefficients[pos,1],
                                  se =  m$clustervcv[pos, pos]^0.5)
                              })))
plot.df$resolution <- rep(names(res), length(dv.labels))
plot.df$resolution <- factor(plot.df$resolution, levels = unique(plot.df$resolution), ordered = T)
plot.df$Specification <- rep(dv.labels, each = length(res))

# ... plot
png(paste0(fig.path, stub, ".png"), height = 2.5, width = 7, res = 300, unit = "in")
print(ggplot(plot.df, aes(x = resolution, y = coef)) + geom_point() + 
        geom_errorbar(aes(ymin = coef - 1.96 * se, ymax = coef + 1.96 * se), width=.1) +
        geom_hline(yintercept = 0, color = "darkgrey", lty = 2) + 
        # scale_y_continuous(breaks = c( length(years):1), labels = years)  +
        xlab("Network resolution used to simulate networks") + ylab(paste("Marginal Effect of\nRelational State Capacity"))  + 
        theme(axis.text.y  = element_text(size = 10, color = "black"),
              legend.position="top") + 
        facet_wrap( ~ Specification, nrow = 1)) 
dev.off()




###################################################
# RSC COMPONENTS ##################################
###################################################
## -- Appendix A6.4, Table A8
stub <- "iv.splitrsc"


# ... first stage
form.str <- c(paste(c("I(log(1/(road.capital.mean.1990 + 1)))","I(log(1/(road.internal.mean.1990 + 1)))"), " ~ ",paste(instr.vars, collapse = "+"),"+",iv.controls,
                    fe.global, 
                    "0 |", 
                    cluster.global))
# ... second stage
form.str <- c(form.str, paste0(dep.global," ~ ", gsub(paste0(endog.vars), 
                                                      "I(log(1/(road.capital.mean.1990 + 1))) +  I(log(1/(road.internal.mean.1990 + 1)))",
                                                      spec.iv)))

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main[!is.na(data.main[,dv[1]]),])})


# Prepare Table

## IV Stats
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1 (state):", unlist(lapply(this.m, function(m){
  f <- try(condfstat(m, type = condfstat.type)[,1])
  if(class(f) == "try-error"){ "" } else { as.character(round_any(f, 0.01))}
})) )
f.stat.s2 <- latex.any.row("F-Stat Stage 1 (internal):", unlist(lapply(this.m, function(m){
  f <- try(condfstat(m, type = condfstat.type)[,2])
  if(class(f) == "try-error"){ "" } else { as.character(round_any(f, 0.01))}
})) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
beta.sum <- unlist(lapply(this.m, function(m){
  pos <- which(grepl("fit", rownames(m$coefficients)))
  if(length(pos) > 0){
    as.character(round_any(sum(m$coefficients[pos,]), 0.01))
  } else {
    ""
  }
}))
beta.sum.se <- unlist(lapply(this.m, function(m){
  pos <- which(grepl("fit", rownames(m$coefficients)))
  if(length(pos) > 0){
    paste0("(",round_any((sum(diag(m$clustervcv[pos,pos])) + 2*m$clustervcv[pos[1], pos[2]])^0.5, 0.01),")")
  } else {
    ""
  }
}))
add.lines <- list(latex.any.row("$\\beta_3 + \\beta_4$ ",beta.sum),
                  latex.any.row("",beta.sum.se),
                  latex.any.row("Country-year FE: ",rep("yes",length(dv.labels)+2)),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels)+2)),
                  mean.dv, f.stat,f.stat.s1, f.stat.s2)

## Covariate labels
these.cov.labs <- c(stage1.labels,
                    paste0(c("$\\beta_3$: ","$\\beta_4$: "),gsub("1880","1990",gsub("foot ","",iv.labels[2:3]))),
                    iv.labels[2:3])
these.cov.labs <- gsub("Internal connectedness", "Int. connect.", these.cov.labs)


# Save Table
fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Effect of the components of RSC,  2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels =  paste0(c(" Stage 1} & \\multicolumn{3}{c}{Stage 2} \\\\ 
                                      \\cmidrule(lr{10pt}){2-3} \\cmidrule(lr{10pt}){4-6} & \\multicolumn{1}{c}{State} & 
                                      \\multicolumn{1}{c}{Internal} & \\multicolumn{1}{c}{Challengers} &
                                      \\multicolumn{1}{c}{Challenger} & \\multicolumn{1}{c}{State} \\\\ 
                                      & \\multicolumn{1}{c}{",rep("",4)),
                                    c("access","connectedness" ,"", "events","events")),
            column.separate = c(2,1,1,1),
            order = c(paste0("opt.",stage1.keep),paste0(stage1.keep,".1990"), iv.keep[2:3]),
            keep= c(paste0("opt.",stage1.keep),paste0(stage1.keep,".1990"), iv.keep[2:3]) ,
            covariate.labels = these.cov.labs,
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"),column.sep.width = "-10pt", star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


