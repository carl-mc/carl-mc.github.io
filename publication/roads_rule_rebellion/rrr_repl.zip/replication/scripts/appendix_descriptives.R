##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Descriptive Statistics ---
#
# Called from ../replicate_all.R
#
###########################################



# Summary Statistics ##########
# Appendix A3, Table A2
stub <- "sumstat"


# ... data.sum
data.sum <- data.main

# ... variables
sum.vars <- c(dv,
              "rsc.1966","road.capital.mean.1966","road.internal.mean.1966","foot.capital.mean.1966","foot.internal.mean.1966",
              "opt.road.capital.mean.1880.1966","opt.road.internal.mean.1880.1966",
              colnames(data.main)[unlist(lapply(colnames(data.main), function(v){grepl(v, paste(main.controls, add.controls))}))])
sum.vars <- sum.vars[!sum.vars %in% c("area","urban")]
data.sum <- data.sum[,sum.vars]

# ... retransform vars according to regression formula
data.sum[,grepl("road.", colnames(data.sum))] <- log(1/(1+data.sum[,grepl("road.", colnames(data.sum))]))
data.sum[,grepl("foot.", colnames(data.sum))] <- log(1/(1+data.sum[,grepl("foot.", colnames(data.sum))]))
data.sum[,c("pop", "pop.urban","poly.area.km2" )] <- data.sum[,c("pop", "pop.urban","poly.area.km2" )] / 1000

# ... variable labels
sum.vars.labels <- c("Challengers", "Challenger Events","State Events","RSC 1966 (log)",
                     "State access 1966; road (log)","Internal connect. 1966; road (log)",
                     "State access 1966; foot (log)","Internal connect. 1966; foot (log)",
                     "State access 1880; road (sim; log)","Internal connect. 1880; road (sim; log)",
                     "Distance to border","Capital dummy","Median altitude","Median slope",
                     "Evapotranspiration","Precipitation","Evapotranspiration / Precipitation",
                     "Temperature", 
                     "Cash crop suitability", "Agricultural suitability", 
                     "Distance to coast",
                     "Distance to nav. river","Mineral deposit",
                     "Area (1000 km$^2$)", "Population (1000s)","Urban population (1000s)" )

# .... Summary stats table
fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(stargazer(data.sum[,sum.vars],align =T, column.sep.width = "-10pt",
                     # omit.summary.stat = c("min","max"), 
                     digits = 2, covariate.labels = sum.vars.labels,
                     title="Summary statistics", label=stub, type  = stargazer.type[1]),
           fileConn)
close(fileConn)

###################################
# Regression: Roads on co-variates
# Appendix A3, Table A3

stub <- "covariates_roads"

# Setup
form.ls <- lapply(c("rsc.1966","log(1/(1 + road.capital.mean.1966))","log(1/(1 + road.internal.mean.1966))"), function(o){
  paste(o, "~", "log(1/(1 + foot.capital.mean.1966))","+", "log(1/(1 + foot.internal.mean.1966))","+",
        main.controls, " + ", add.controls, " | cow.year |  0 | id + cow.year")
})

# Estimate
this.m <- lapply(form.ls, function(f){
  felm(as.formula(f), data = data.main)
})


# To table

dep.vars <- c("RSC",
              "State access",
              "Internal connectedness")

det.vars.labels <- c("State access 1966, foot (log)",
                     "Internal connectedness 1966, foot (log)",
                     "Population (log)","Urban population (log)" , "Area (log)",
                     "Median altitude","Median slope",
                     "Precipitation","Evapotranspiration","Evapotranspiration / Precipitation",
                     "Temperature", 
                     "Cash crop suitability", "Agricultural suitability","Mineral deposit (0/1)",
                     "Distance to coast",
                     "Distance to nav. river",
                     "Capital dummy","Distance to border (log)") 
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  mean.dv)


fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Effect of covariates on RSC and its components",
            dep.var.caption = "Dependent variable (1966; logged)",dep.var.labels.include = FALSE,
            column.labels = dep.vars,
            covariate.labels = det.vars.labels,
            notes.align = "l",label=paste0("tab.",stub, "det"),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = "\\parbox[t]{0.95\\textwidth}{\\textit{Notes:} OLS models. 
            Two-way clustered standard errors in parentheses (ethnic group and country-year clusters). 
            Significance codes: $^{*}$p$<$0.1; $^{**}$p$<$0.05; $^{***}$p$<$0.01.}", 
            notes.label = "", notes.append = F, no.space = T,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)






