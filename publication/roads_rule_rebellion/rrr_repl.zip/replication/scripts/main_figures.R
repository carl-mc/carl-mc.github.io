

##############################################
# Descriptive Maps ###########################


# FIGURE 1: RSC IN THE DR CONGO ##############

# This plot
plot.cowcode = 490
width = 4
height = 3

# Shapes
cow.shp <- cshp(date = as.Date("2000-01-01"))
cow.shp <- cow.shp[cow.shp$COWCODE == plot.cowcode,]

these.groups <- ethno.spdf[ethno.spdf$cowcode == plot.cowcode,]
these.groups@data <- join(these.groups@data, 
                          data.main[data.main$year == 2016, 
                                    c("ethno.id", "road.capital.mean.1966", "road.internal.mean.1966", "rsc.1966")],
                          type = "left", by = "ethno.id")

# 4 Quadrant plot
# Roads, state access, internal connectedness, RSC

# Road Map ##############################

# Load roads
these.roads <- readOGR(dsn = file.path(getwd(), "data/shapefiles"),
                       layer = "drc_roads_1966")

# ... road colors
type.color <- rev(c("#FDE725FF", "#5DC863FF", "#21908CFF", "#3B528BFF", "#440154FF"))

# ... plot
png(paste0(fig.path, "fig1a", ".png"), height = height, width = width, res = 300, unit = "in")

# ... main
layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))
par(mar = c(0,0,0,0))
plot(cow.shp)
plot(these.roads, col = type.color[these.roads$rtype], add =T)

# ... legend
legend_image <- as.raster(matrix(type.color, ncol=1))
plot(c(0,2),c(-0.5,4.5),type = 'n', axes = F,xlab = '', ylab = '', main = '')
legend.labels = c("Other", "Earth\n road", "Partially\n improved","Improved","Hard\n surface")
axis(side = 4, at = c(0:4), labels = legend.labels,
     pos = 0.5, outer = FALSE, font = NA, lty = "solid",  cex.axis = 0.6)
rasterImage(legend_image, 0, -0.5, 0.5,4.5, interpolate = F)
dev.off()


# State Access ###########################
col.breaks = seq(-4.5,.5, l = 256)
# ... colour palette
colpal <- viridis(256, option = "inferno")
these.groups@data$colkey <- colpal[as.numeric(cut(-log(1+these.groups@data$road.capital.mean.1966),
                                                  breaks = col.breaks))]

# ... plot
png(paste0(fig.path, "fig1b", ".png"), height = height, width = width, res = 300, unit = "in")

# ... main
layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))
par(mar = c(0,0,0,0))
plot(these.groups, col = these.groups$colkey, border = "white", lwd = 0.1)
plot(cow.shp, col = "transparent", border = "black", lwd = 1, add = T)

# ... legend
legend_image <- as.raster(matrix(colpal[length(colpal):1], ncol=1))
plot(c(0,2),c(min(col.breaks),max(col.breaks)),type = 'n', axes = F,xlab = '', ylab = '', main = '')
axis(side = 4, 
     pos = 0.5, outer = FALSE, font = NA, lty = "solid", las = 1)
rasterImage(legend_image, 0, min(col.breaks), 0.5,max(col.breaks))
dev.off()



# Internal connectedness ##################

# ... colour palette
colpal <- viridis(256, option = "inferno")
these.groups@data$colkey <- colpal[as.numeric(cut(-log(1+these.groups@data$road.internal.mean.1966),
                                                  breaks = col.breaks))]

# ... plot
png(paste0(fig.path, "fig1c", ".png"), height = height, width = width, res = 300, unit = "in")

# ... main
layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))
par(mar = c(0,0,0,0))
plot(these.groups, col = these.groups$colkey, border = "white", lwd = 0.1)
plot(cow.shp, col = "transparent", border = "black", lwd = 1, add = T)

# ... legend
legend_image <- as.raster(matrix(colpal[length(colpal):1], ncol=1))
plot(c(0,2),c(min(col.breaks),max(col.breaks)),type = 'n', axes = F,xlab = '', ylab = '', main = '')
axis(side = 4, 
     pos = 0.5, outer = FALSE, font = NA, lty = "solid", las = 1)
rasterImage(legend_image, 0, min(col.breaks), 0.5,max(col.breaks))
dev.off()



# Relational State Capacity ##################

# ... colour palette
colpal <- viridis(256, option = "inferno")
these.groups@data$colkey <- colpal[as.numeric(cut(these.groups@data$rsc.1966,breaks = col.breaks))]

# ... plot
png(paste0(fig.path, "fig1d", ".png"), height = height, width = width, res = 300, unit = "in")

# ... main
layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))
par(mar = c(0,0,0,0))
plot(these.groups, col = these.groups$colkey, border = "white", lwd = 0.1)
plot(cow.shp, col = "transparent", border = "black", lwd = 1, add = T)

# ... legend
legend_image <- as.raster(matrix(colpal[length(colpal):1], ncol=1))
plot(c(0,2),c(min(col.breaks),max(col.breaks)),type = 'n', axes = F,xlab = '', ylab = '', main = '')
axis(side = 4, 
     pos = 0.5, outer = FALSE, font = NA, lty = "solid", las = 1)
rasterImage(legend_image, 0, min(col.breaks), 0.5,max(col.breaks))
dev.off()



# FIGURE 2a-c: RSC IN 3 COUNTRIES ##############

# Prepare
cow.years <- list(CAR = c(482,1997), DRCongo = c(490, 1997), Senegal = c(433, 1997))
cow.circles <- list(CAR = c(x = 22.5, y = 9.8, a = 1.5, b = 1.5), 
                    DRCongo = c(x = 28.7, y = -1.8, a = 2, b = 3), 
                    Senegal = c(x = -16.0, y = 12.8, a = 1.3, b = .65))
legend.map = 3

# Plot
for(c in c(1:length(cow.years))){
  
  # Locals
  cy = cow.years[[c]]
  plot.year = cy[2]
  plot.cow = cy[1]
  
  # Join RSC with with polygons
  map.spdf <- ethno.spdf
  map.spdf@data <- join(map.spdf@data,
                        data.main[data.main$year == plot.year & data.main$cowcode == plot.cow,
                                  c("ethno.id","cow.period.id","rsc.1966")], 
                        type = "left", by = c("ethno.id", "cow.period.id") )
  
  cow.shp <- cshp(date = as.Date("2000-01-01"))
  cow.shp <- cow.shp[cow.shp$COWCODE == plot.cow,]
  
  # ... colour palette
  colpal <- viridis(256, option = "inferno") #colorRampPalette(c("blue","green"),space = "Lab")(256)
  map.spdf@data$colkey <- colpal[as.numeric(cut(map.spdf@data$rsc.1966,
                                                breaks = seq(min(data.main$rsc.1966, na.rm = T), 
                                                             max(data.main$rsc.1966, na.rm = T), length.out = 256)))]
  map.spdf <- map.spdf[!is.na(map.spdf$colkey),]
  
  # ... Aspect Ratio
  ext.vec <- as.vector(extent(cow.shp))
  asp.ratio <- (ext.vec[2] - ext.vec[1])/(ext.vec[4] - ext.vec[3])
  
  # ... plot
  png(paste0(fig.path,"rsc.",plot.cow,".png"), height = 4, 
      width = ifelse(c==legend.map, 4*asp.ratio + 1, 4*asp.ratio), res = 300, unit = "in")
  par(mar = c(0,0,0,0))
  if(c == legend.map){layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))}
  
  # ... main
  plot(map.spdf, col = map.spdf$colkey, border = "transparent", lwd = 1)
  plot(cow.shp, col = "transparent", border = "black", lwd = 0.5, add = T)
  points(cow.shp@data[,c("CAPLONG", "CAPLAT")], pch = 15, col = "black", cex = 2)
  points(cow.shp@data[,c("CAPLONG", "CAPLAT")], pch = 18, col = "black", cex = 3)
  plotrix::draw.ellipse(x = cow.circles[[c]]["x"],y = cow.circles[[c]]["y"],a = cow.circles[[c]]["a"],b = cow.circles[[c]]["b"],
                        nv=100,border = "black",col = "transparent",lty=1,
                        angle=0,lwd=4 )
  plotrix::draw.ellipse(x = cow.circles[[c]]["x"],y = cow.circles[[c]]["y"],a = cow.circles[[c]]["a"],b = cow.circles[[c]]["b"],
                        nv=100,border = "white",col = "transparent",lty=3,
                        angle=0,lwd=4.1)
  
  # ... legend
  if(c == legend.map){
    legend_image <- as.raster(matrix(rev(colpal), ncol=1))
    plot(c(0,2),c(min(data.main$rsc.1966, na.rm = T), max(data.main$rsc.1966, na.rm = T)),type = 'n', axes = F,xlab = '', ylab = '', main = '')
    axis(side = 4,pos = 0.5)
    rasterImage(legend_image, 0,min(data.main$rsc.1966, na.rm = T), 0.5, max(data.main$rsc.1966, na.rm = T))
  }
  dev.off()
  
}


# FIGURE 3: SIMULATED ROADS IN UGANDA ###########

# Prepare
plot.cowcode <- 500

# Shapes
cow.shp <- cshp(date = as.Date("2000-01-01"))
cow.shp <- cow.shp[cow.shp$COWCODE == plot.cowcode,]
colnames(cow.shp@data) <- tolower(colnames(cow.shp@data))

# Load optimal network
opt.g <- readRDS(paste0("data/networks/",
                        plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_1880_optnw.rds"))

# Load real network
real.g <- readRDS(paste0("data/networks/",plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_obsnw.rds"))

# Plot

# ...colors
type.color <- rev(c("#FDE725FF", "#5DC863FF", "#21908CFF", "#3B528BFF", "#440154FF", "#440154FF"))

# ... plot final
g.ls <- list(real.g, opt.g)
g.name <- c("obs","opt")

for(i in c(1:2)){
  E(g.ls[[i]])$color <- "lightgrey"
  for(c in c(1:6)){
    E(g.ls[[i]])$color[!is.na(E(g.ls[[i]])$rtype) & E(g.ls[[i]])$rtype == c] <- type.color[c]
  }
  # Aspect Ratio
  ext.vec <- as.vector(extent(cow.shp))
  asp.ratio <- (ext.vec[2] - ext.vec[1])/(ext.vec[4] - ext.vec[3])
  
  # Init file
  png(paste0(fig.path, "network.",g.name[i], ".",plot.cowcode,".png"), height = 4, width = ifelse(i == 1,4 * asp.ratio,4 *asp.ratio + 1), res = 300, unit = "in")
  if(i == 2){layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))}
  par(mar = c(0,0,0,0))
  
  # PLot
  plot(g.ls[[i]], vertex.shape = "none", vertex.size = 0, vertex.color = "transparent", vertex.label = NA, 
       edge.width = ifelse(E(g.ls[[i]])$color == "lightgrey",1,2),
       layout = as.matrix(cbind(vertex_attr(g.ls[[i]], "x"),
                                vertex_attr(g.ls[[i]], "y"))))
  plot(g.ls[[i]], vertex.shape = "none", vertex.size = 0, vertex.color = "transparent", vertex.label = NA, 
       edge.width = ifelse(E(g.ls[[i]])$color == "lightgrey",1,2),
       edge.color = ifelse(E(g.ls[[i]])$color == "lightgrey", NA, E(g.ls[[i]])$color),
       layout = as.matrix(cbind(vertex_attr(g.ls[[i]], "x"),
                                vertex_attr(g.ls[[i]], "y"))), add = T)
  # ... legend
  if(i == 2){
    legend_image <- as.raster(matrix(c(type.color[2:6],"lightgrey"), ncol=1))
    plot(c(0,2),c(-0.5,5.5),type = 'n', axes = F,xlab = '', ylab = '', main = '')
    legend.labels = c("Footpath","Other", "Earth\n road", "Partially\n improved","Improved","Hard\n surface")
    axis(side = 4, at = c(0:5), labels = legend.labels,
         pos = 0.5, outer = FALSE, font = NA, lty = "solid",  cex.axis = 0.6)
    rasterImage(legend_image, 0, -0.5, 0.5,5.5, interpolate = F)
  }
  dev.off()
}