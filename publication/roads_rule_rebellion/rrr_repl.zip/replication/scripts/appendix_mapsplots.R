##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Maps and Plots for the Appendix ---
#
# Called from ../replicate_all.R
#
###########################################




# PLOT FOOTPATH NETWORK ##################
# Appendix A2.2, Figure A5a

## Load Uganda footpath network 
#     (derived from optimized one --that's the same structure)
plot.cowcode <- 500
cow.shp <- cshp(date = as.Date("2000-01-01"))
cow.shp <- cow.shp[cow.shp$COWCODE == plot.cowcode,]
colnames(cow.shp@data) <- tolower(colnames(cow.shp@data))
g <- readRDS(paste0("data/networks/",
                    plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_1880_optnw.rds"))
E(g)$color <- "lightgrey"

png(paste0(fig.path, "network.foot.png"), height = 4, width = 4, res = 300, unit = "in")
par(mar = c(0,0,0,0))
plot(g, vertex.size = 0.01, vertex.color = "black", vertex.label = NA, 
     edge.width = ifelse(E(g)$color == "lightgrey",1,2),
     layout = as.matrix(cbind(vertex_attr(g, "x"),
                              vertex_attr(g, "y"))))
dev.off()



# PLOT OBSERVED NETWORK WITH LEGEND #########
# Appendix A2.2, Figure A5b

## Load Uganda real network
plot.cowcode <- 500
cow.shp <- cshp(date = as.Date("2000-01-01"))
cow.shp <- cow.shp[cow.shp$COWCODE == plot.cowcode,]
colnames(cow.shp@data) <- tolower(colnames(cow.shp@data))
g <- readRDS(paste0("data/networks/",plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_obsnw.rds"))
E(g)$color <- "lightgrey"

## Plot
for(c in c(1:6)){
  E(g)$color[!is.na(E(g)$rtype) & E(g)$rtype == c] <- type.color[c]
}

# Verteces with foot-path connection
foot.vert <- unique(as.vector(ends(g, which(E(g)$color == "lightgrey"))))


# Plot
png(paste0(fig.path, "network.obswl.png"), height = 4, width = 5, res = 300, unit = "in")
layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))
par(mar = c(0,0,0,0))
plot(g, vertex.size = 0.01, vertex.color = "black", vertex.label = NA, 
     vertex.shape = ifelse(names(V(g)) %in% foot.vert, "circle","none"),
     edge.width = ifelse(E(g)$color == "lightgrey",1,2),
     layout = as.matrix(cbind(vertex_attr(g, "x"),
                              vertex_attr(g, "y"))))
plot(g, vertex.size = 0.01, vertex.color = "black", vertex.label = NA, 
     vertex.shape = ifelse(names(V(g)) %in% foot.vert, "circle","none"),
     edge.width = ifelse(E(g)$color == "lightgrey",1,2),
     edge.color = ifelse(E(g)$color == "lightgrey", NA, E(g)$color),
     layout = as.matrix(cbind(vertex_attr(g, "x"),
                              vertex_attr(g, "y"))), add = T)
# ... legend
legend_image <- as.raster(matrix(c(type.color[2:6],"lightgrey"), ncol=1))
plot(c(0,2),c(-0.5,5.5),type = 'n', axes = F,xlab = '', ylab = '', main = '')
legend.labels = c("Footpath","Other", "Earth\n road", "Partially\n improved","Improved","Hard\n surface")
axis(side = 4, at = c(0:5), labels = legend.labels,
     pos = 0.5, outer = FALSE, font = NA, lty = "solid",  cex.axis = 0.6)
rasterImage(legend_image, 0, -0.5, 0.5,5.5, interpolate = F)
dev.off()






# TRVEL SPEED DISTRIBUTIONS ###
# Appendix A2.2, Figure A6a

# Load data
michelin.speed <- read.csv("data/speed_viamichelin.csv", stringsAsFactors = F)

# Estimate
summary(m.speed <- lm(speed ~ 0 + type, data = michelin.speed))


# Prepare plot
types <- c("Highway","Hard\n surface","Improved", "Partially\n improved", "Earth\n road","Other")
est.df <- data.frame(do.call(rbind, lapply(types, function(t){
  pos <- which(grepl(t, names(m.speed$coefficients)))
  c(coef = m.speed$coefficients[pos], se = diag(vcov(m.speed))[pos]^0.5)
})))
colnames(est.df) <- c("coef","se")
est.df$pos <- c(7:2)

# Add foot speed
michelin.speed <- rbind(michelin.speed,
                        data.frame(country = "Google",type = "Foot", 
                                   km = 1, min = 10, km.h = 6, link = "maps.google.com", speed = 6, type.num = 1))

# Plot
png(paste0(fig.path,"travelspeed.png"), height = 3, width = 3, res = 300, unit = "in")
g <- ggplot() + 
  geom_point(data = michelin.speed, aes(x = type.num, y = speed), color = "grey") +
  geom_point(data = michelin.speed[michelin.speed$type == "Foot",], aes(x = type.num, y = speed), color = "black") +
  geom_point(data = est.df, aes(x = pos, y = coef)) + 
  geom_errorbar(data = est.df, aes(x = pos, ymin = coef - 1.96 * se, ymax = coef + 1.96 * se), width=.1) +
  xlab("") + ylab("Speed (km/h)") + scale_x_continuous(breaks = c(1:7), labels = c("Foot",rev(types)))  + 
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5)) + ylim(0,100)
print(g)
dev.off()  



# MICHELIN VS GOOGLE MAPS ###################
# Appendix A2.2, Figure A6b

stub <- "compare_google_michelin"

# ... load data
compare.df <- readRDS("data/mich_google_comp.rds")

# ... plot data
png(paste0(fig.path,stub,".png"), height = 3, width = 3, res = 300, unit = "in")
g <- ggplot(compare.df[compare.df$michelin.dist != 0,], aes(x = log(1+michelin.dist), y = log(1+time_hours))) + 
  geom_point(cex = 0.5) +
  xlim(0,4.5) + ylim(0,4.5) + xlab("log(Michelin travel hours + 1)")+ ylab("log(Google travel hours + 1)")
print(g)
dev.off()


# ... % Missing values in Google Data
print(paste("Missings in Google API (%):", 
            100*nrow(compare.df[compare.df$michelin.dist != 0 & is.na(compare.df$time_hours),]) / 
              nrow(compare.df[compare.df$michelin.dist != 0,])))





# PLOT OPTIMIZATION BY PERIODS ############
# Appendix A5, Figure A13

# ... plot across periods of road building
plot.cowcode = 500
cow.shp <- cshp(date = as.Date("2000-01-01"))
cow.shp <- cow.shp[cow.shp$COWCODE == plot.cowcode,]
colnames(cow.shp@data) <- tolower(colnames(cow.shp@data))


# Load optimal network
g <- readRDS(paste0("data/networks/",
                    plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_1880_optnw.rds"))
E(g)$color <- "lightgrey"
out_ls <- readRDS(paste0("data/networks/",
                         plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_1880_optfull.rds"))

# ...colors
type.color <- rev(c("#FDE725FF", "#5DC863FF", "#21908CFF", "#3B528BFF", "#440154FF", "#440154FF"))

for(p in c(1:5)){
  
  E(g)$color[out_ls[[1]][[p]]] <- type.color[7-p]
  
  png(paste0(fig.path, "network.opt.",p, ".png"), height = 4, width = ifelse(p != 5,4,5), res = 300, unit = "in")
  if(p == 5){layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))}
  par(mar = c(0,0,0,0))
  plot(g, vertex.size = 0.1, vertex.color = "black", vertex.label = NA, 
       edge.width = ifelse(E(g)$color == "lightgrey",1,2),
       layout = as.matrix(cbind(vertex_attr(g, "x"),
                                vertex_attr(g, "y"))))
  plot(g, vertex.shape = "none", vertex.size = 0, vertex.color = "transparent", vertex.label = NA, 
       edge.width = ifelse(E(g)$color == "lightgrey",1,2),
       edge.color = ifelse(E(g)$color == "lightgrey", NA, E(g)$color),
       layout = as.matrix(cbind(vertex_attr(g, "x"),
                                vertex_attr(g, "y"))), add = T)
  # ... legend
  if(p == 5){
    legend_image <- as.raster(matrix(c(type.color[2:6],"lightgrey"), ncol=1))
    plot(c(0,2),c(-0.5,5.5),type = 'n', axes = F,xlab = '', ylab = '', main = '')
    legend.labels = c("Footpath","Other", "Earth\n road", "Partially\n improved","Improved","Hard\n surface")
    axis(side = 4, at = c(0:5), labels = legend.labels,
         pos = 0.5, outer = FALSE, font = NA, lty = "solid",  cex.axis = 0.6)
    rasterImage(legend_image, 0, -0.5, 0.5,5.5, interpolate = F)
  }
  dev.off()
}




# PLOT REAL AND OPTIMIZED NETWORK ###########
# Appendix A5, Figure A14

# Plot for four countries
for(plot.cowcode in c(432, 433, 551)){
  print(plot.cowcode)
  # Shapes
  cow.shp <- cshp(date = as.Date("2000-01-01"))
  cow.shp <- cow.shp[cow.shp$COWCODE == plot.cowcode,]
  colnames(cow.shp@data) <- tolower(colnames(cow.shp@data))
  
  # Load optimal network
  opt.g <- readRDS(paste0("data/networks/",
                          plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_1880_optnw.rds"))
  
  # Load real network
  real.g <- readRDS(paste0("data/networks/",plot.cowcode,"_", cow.shp$cowsyear,"_",cow.shp$coweyear,"_1966_obsnw.rds"))
  

  
  # Plot
  
  # ...colors
  type.color <- rev(c("#FDE725FF", "#5DC863FF", "#21908CFF", "#3B528BFF", "#440154FF", "#440154FF"))

  # ... plot final
  g.ls <- list(real.g, opt.g)
  g.name <- c("obs","opt")
  
  for(i in c(1:2)){
    E(g.ls[[i]])$color <- "lightgrey"
    for(c in c(1:6)){
      E(g.ls[[i]])$color[!is.na(E(g.ls[[i]])$rtype) & E(g.ls[[i]])$rtype == c] <- type.color[c]
    }
    # Aspect Ratio
    ext.vec <- as.vector(extent(cow.shp))
    asp.ratio <- (ext.vec[2] - ext.vec[1])/(ext.vec[4] - ext.vec[3])
    
    png(paste0(fig.path, "network.",g.name[i], ".",plot.cowcode,".png"), height = 4, width = ifelse(i == 1,4 * asp.ratio,4 *asp.ratio + 1), res = 300, unit = "in")
    if(i == 2){layout(matrix(1:2,ncol=2), width = c(4,1),height = c(1,1))}
    par(mar = c(0,0,0,0))
    plot(g.ls[[i]], vertex.shape = "none", vertex.size = 0, vertex.color = "transparent", vertex.label = NA, 
         edge.width = ifelse(E(g.ls[[i]])$color == "lightgrey",1,2),
         layout = as.matrix(cbind(vertex_attr(g.ls[[i]], "x"),
                                  vertex_attr(g.ls[[i]], "y"))))
    plot(g.ls[[i]], vertex.shape = "none", vertex.size = 0, vertex.color = "transparent", vertex.label = NA, 
         edge.width = ifelse(E(g.ls[[i]])$color == "lightgrey",1,2),
         edge.color = ifelse(E(g.ls[[i]])$color == "lightgrey", NA, E(g.ls[[i]])$color),
         layout = as.matrix(cbind(vertex_attr(g.ls[[i]], "x"),
                                  vertex_attr(g.ls[[i]], "y"))), add = T)
    # ... legend
    if(i == 2){
      legend_image <- as.raster(matrix(c(type.color[2:6],"lightgrey"), ncol=1))
      plot(c(0,2),c(-0.5,5.5),type = 'n', axes = F,xlab = '', ylab = '', main = '')
      legend.labels = c("Footpath","Other", "Earth\n road", "Partially\n improved","Improved","Hard\n surface")
      axis(side = 4, at = c(0:5), labels = legend.labels,
           pos = 0.5, outer = FALSE, font = NA, lty = "solid",  cex.axis = 0.6)
      rasterImage(legend_image, 0, -0.5, 0.5,5.5, interpolate = F)
    }
    dev.off()
  }
}



# TABLE INPUT PARAMETERS OF NETWORK SIMULATION ######
# Appendix A5, Table A5

stub <- "input.opt"

# Load input data
input.table <- readRDS("data/opt_inputs.rds")

# LaTeX
col.names <- c("Resolution","Countries", "Example", "Population", "Vertices", paste0("$B_", c(1:5),"$"))
tab <- input.table[2:4,c("nw.resolution", "cow.number", "country", "pop", "n.vertex", paste0("type", c(1:5)))]
sg.tab <- stargazer(tab,
                    title="Mean of input values to road network simulation", summary = F,
                    dep.var.labels  = col.names,
                    rownames = F,
                    notes.align = "l",label=paste0("tab.",stub),align =T, column.sep.width = "-7pt",
                    digits = 1, intercept.top = T,intercept.bottom = F,
                    omit.stat = c("rsq","res.dev","ser"),
                    notes = "Networks' resolution is measured in decimal degrees and road budgets $B_q$ in 1000 kilometers.",
                    type  = stargazer.type[1])
for(v in c(1:ncol(tab))){
  sg.tab <- sub(colnames(tab)[v], col.names[v], sg.tab)
}

fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(sg.tab, fileConn)
close(fileConn)



# PLOT LOSS IMPROVEMENT OVER ALL OPTIMIZED MAPS ######
# Appendix A5, Figure A15a

# Load loss data
loss.df <- readRDS("data/opt_loss.rds")


# Plot
this.colors <- type.color[6:2]
names(this.colors) <- c("Other", "Earth\n road", "Partially\n improved","Improved","Hard\n surface")
png(paste0(fig.path, "network.opt.loss.png"), height = 4, width = 7, res = 300, unit = "in")
g <- ggplot(loss.df, aes(x = pos, y= loss.std, group = map.id, color = type.name)) + geom_line(alpha = 0.75) +
  scale_colour_manual(name = "type.name",values = this.colors) + 
  guides(color=guide_legend(title="Road type added")) + 
  xlab("Step of algorithm (standardized to 0-1)") + ylab("LOSS-value (standardized to 0-1)")
print(g)
dev.off()



# PLOT IMPROVEMENT ACHIEVED BY OPTIMIZED NETWORKS ######
# Appendix A5, Figure A16b

# Load data on improvement
improvement.df <- readRDS("data/opt_improve.rds")

# Plot
png(paste0(fig.path,"comp.opt.real.network.png"), height = 3.3, width = 3.3, res = 300, unit = "in")
g <- ggplot(improvement.df, aes(x = log(opt.road.internal.mean/1000), y = log(road.internal.mean/1000))) + 
  geom_point(cex = 0.5) + geom_abline( slope = 1, intercept = 0, lty = 2)  + 
  xlim(1.5,3.6) + ylim(1.5,3.6) +
  xlab("Mean travel time between inhabitants \non simulated network (hrs; logged)") +
  ylab("Mean travel time between inhabitants \non real network (hrs; logged)") + 
  theme(axis.title=element_text(size=10))
print(g)
dev.off()


