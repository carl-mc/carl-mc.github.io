##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Initialization: Libraries, Globals, Functions ---
#
# Called from ../replicate_all.R
#
###########################################





# LIBRARIES #################

# Install all necessary packages for replication
## Only installs package if not already installed locally
pcks <- c("lfe",    "stargazer",  "clusterSEs",   "survival",  "ggplot2",  
          "raster",   "plyr",   "MASS",   "viridisLite",     "maptools",
          "rgeos",     "igraph",    "rgdal",  "countrycode",
          "cshapes",   ## NOTE: MUST BE cshapes Version 0.6 // Country-period dates are important
          "plotrix",
          "gridExtra")
for(p in pcks){
  if(!p %in% installed.packages()[,"Package"]){
    print(p)
    install.packages(p)
  }
}

# Load packages
library(lfe)
library(clusterSEs)
library(survival)
library(stargazer)
library(ggplot2)
library(raster)
library(plyr)
library(MASS)
library(viridisLite)
library(maptools)
library(rgeos)
library(igraph)
library(rgdal)
library(cshapes)
library(plotrix)
library(gridExtra)
library(countrycode)


# GLOBALS ####################

## Paths
tab.path <- "results/tables/"
dir.create(tab.path)
fig.path <- "results/figures/"
dir.create(fig.path)

## Output tables as LaTeX
as.tex <- T


# FUNCTIONS ##################

## LaTeX Functionalities
latex.any.row <- function(any, entries){c(any,paste0("\\multicolumn{1}{c}{",entries,"}"))}
if(as.tex){
  stargazer.type <- c("latex",".tex")
  
} else {
  stargazer.type <- c("text",".txt")
}

## Function for clustering fitted glm object
cl.glm <- function(glm.fit, cl, print=TRUE) {
  ## Huber-White M-Estimation clustering as implemented in Stata 12
  ## See Rogers (1993): "Regression standard errors in clustered samples", Stata Technical Bulletin 13
  
  require(sandwich)
  require(lmtest)
  
  # Extract info from GLM
  V <- vcov(glm.fit)  # iid VCOV from Fisher Information ("Bread")
  u <- estfun(glm.fit)  # Get gradients at observations ("estimating functions")
  M <- length(unique(cl))  # Nr. of clusters (all asymptotics in M!)
  
  # Finite sample correction
  adj <- (M/(M-1))
  
  # Get correction matrix ("Meat")
  sumU <- NULL
  for (i in 1:M) {
    thiscl <- unique(cl)[i]
    thisu <- u[cl==thiscl,,drop=FALSE]
    thisu <- colSums(thisu)
    thisU <- thisu%*%t(thisu)
    if (is.null(sumU)) {
      sumU <- thisU
    } else {
      sumU <- sumU + thisU
    }
  }
  
  # Cluster
  clV <- adj*V%*%sumU%*%V
  
  if (print) {
    return(coeftest(glm.fit, clV))
  } else {
    return(clV)
  }
}

## Improved stargazer note function
nice_notes <- function(note, width = .95){
  paste("\\begin{minipage}[t]{",width,"\\columnwidth}",
        paste(note, collapse = " "),
        "\\end{minipage}")
}


## Extract coefficients from FELM object function
extract_coef <- function(m.list){
  lapply(m.list, function(m){
    list(dv = colnames(m$coefficients),
         coef = m$coefficients,
         clustervcv = m$clustervcv)
  })
}
