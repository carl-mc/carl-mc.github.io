##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Coefficient Plots of Robustness Checks ---
#
# Called from ../replicate_all.R
#
###########################################



# Needed as input:
#'    all.coef.ls   =   Coefficients from all linear models estimated for the paper
#'    fig.path      =   Path where to store plots
#'    
#'    


# Make one big data frame of RSC coefficients
coef.df <- do.call(rbind, lapply(c(1:length(all.coef.ls)), function(type){
  cbind(type = names(all.coef.ls)[type],
        data.frame(do.call(rbind, 
                           lapply(1:length(all.coef.ls[[type]]), function(stub){
                             cbind(stub = names(all.coef.ls[[type]])[stub],
                                   data.frame(do.call(rbind, 
                                                lapply(all.coef.ls[[type]][[stub]], function(m){
                                                  if(is.vector(m$coef)){
                                                    data.frame(dep.var = ifelse(is.null(m$dv), NA, m$dv),
                                                               var = names(m$coef),
                                                               coef = m$coef,
                                                               se = diag(m$clustervcv)^.5,
                                                               stringsAsFactors = F)
                                                  } else {
                                                    data.frame(dep.var = m$dv,
                                                               var = rownames(m$coef),
                                                               coef = m$coef[,1],
                                                               se = diag(m$clustervcv)^.5,
                                                               stringsAsFactors = F)
                                                  }
                                                })), 
                                        stringsAsFactors = F))
                           })), 
                   stringsAsFactors = F))
}))

# ... delete "iv." from stubs
coef.df$stub <- gsub("iv.", "", coef.df$stub, fixed =  T)

# Color scale
colMethod <- scale_colour_manual(name = "Method",
                                 values = c(OLS = "black",
                                            `2SLS` = "darkgrey"))
pchMethod <- scale_shape_manual(name = "Method", 
                                values = c(OLS = 19,
                                           `2SLS` = 17))


#############################################
# Disaggregate Buckets ######################
#############################################


# ... specify stubs
stub.plot <- c("disaggviol")

# ... titles
title.plot <- c("Rebel groups", "Militias")

# ... specify indpenedent variables to plot
var.plot <- c("rsc.1966","rsc.1990", "`rsc.1990(fit)`")

# ... y-labels 
y.labels <- c("Number of groups", "Battles with\nrebels and militias", "Battles with\nstate forces")

# ... Method
coef.df$Method <- ifelse(coef.df$type == "iv", "2SLS",
                         ifelse(coef.df$type == "ols", "OLS", NA))
coef.df$Method <- factor(coef.df$Method, 
                         levels = unique(coef.df$Method))

# ... subset data
plot.df <- coef.df[coef.df$stub %in% stub.plot & coef.df$var %in% var.plot,]

# ... convert dep.var to factor 
dep.var <- c("Number", "challenger.viol", "state.viol")
plot.df$dep.var <- factor(rep(rep(dep.var, each = 2), 2),
                          levels = dep.var,
                          labels = y.labels)

plot.df$stub.fac <- factor(rep(title.plot, 6),
                           levels = rev(title.plot),
                           labels = rev(title.plot))
plot.df$pos <- as.numeric(plot.df$stub.fac)
plot.df$pos <- ifelse(plot.df$type == "ols", plot.df$pos + .15,
                      plot.df$pos - .15)

# ... plot
p <- ggplot(plot.df, aes(y = pos, x = coef, color = Method, pch = Method)) + 
  geom_point() + 
  geom_errorbarh(aes(xmin = coef - 1.96*se, 
                     xmax = coef + 1.96*se), 
                 height=.1) +
  geom_vline(xintercept = 0, color = "darkgrey", lty = 2) + 
  scale_y_continuous(breaks = unique(as.numeric(plot.df$stub.fac)), 
                     labels = unique(as.character(plot.df$stub.fac)))  +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 3)) +
  xlab("Coefficient of RSC") + ylab(NULL) + 
  facet_wrap(~ dep.var, nrow = 1) + 
  colMethod + pchMethod +
  NULL


# ... save
png(paste0(fig.path, "appx_disaggviol.png"), width = 6, height = 2.5, unit = "in", res = 600)
par(mar = c(0,0,0,0))
print(p)
dev.off()


#############################################
# Alternative Violence Measures #############
#############################################


# ... specify stubs
stub.plot <- c("linprob", "fatal", "acledevents","gedevents","scadevents")

# ... titles
title.plot <- c("Linear probability P(Y > 0)",
                "Fatalities (count; log)",
                "ACLED events (count; log)",
                "UCDP GED events (count; log)",
                "SCAD events (count; log)")

# ... nrow and ncol of combined figure
ncol = 1
nrow = ceiling(length(stub.plot) / ncol)

# ... specify indpenedent variables to plot
var.plot <- c("rsc.1966", "`rsc.1990(fit)`")

# ... y-labels 
y.labels <- list(c("Challenger", "Challenger Events", "State Events"),
                 c( "Challenger Events", "State Events"),
                 c("Riot / Demo", "OSV", "Battles", "Remote Viol."),
                 c("Civil war", "OSV","Non-State"),
                 c("Pro-gov. Militia", "Anti-gov. Militia", "Extra-gov. Militia"))

# ... Method
coef.df$Method <- ifelse(coef.df$type == "iv", "2SLS",
                         ifelse(coef.df$type == "ols", "OLS", NA))
coef.df$Method <- factor(coef.df$Method, 
                         levels = unique(coef.df$Method))

# ... loop over stubs to make plots
plot.ls <- lapply(1:length(stub.plot), function(s){
  # ... subset data
  plot.df <- coef.df[coef.df$stub == stub.plot[s] & coef.df$var %in% var.plot,]
  
  # ... convert dep.var to factor 
  plot.df$dep.var <- factor(plot.df$dep.var,
                            levels = rev(unique(plot.df$dep.var)))
  plot.df$pos <- as.numeric(plot.df$dep.var)
  plot.df$pos <- ifelse(plot.df$type == "ols", plot.df$pos + .15,
                        plot.df$pos - .15)
  
  # ... plot
  p <- ggplot(plot.df, aes(y = pos, x = coef, color = Method, pch = Method)) + 
    geom_point() + 
    geom_errorbarh(aes(xmin = coef - 1.96*se, 
                       xmax = coef + 1.96*se), 
                   height=.1) +
    geom_vline(xintercept = 0, color = "darkgrey", lty = 2) + 
    scale_y_continuous(breaks = unique(as.numeric(plot.df$dep.var)), 
                       labels = y.labels[[s]])  +
    xlab("Coefficient of RSC") + ylab(NULL) + 
    ggtitle(title.plot[s])  + 
    colMethod + pchMethod + 
    NULL
  if(s != length(stub.plot)){
    p <- p + guides(colour=FALSE, lty = FALSE, pch = FALSE)
  }
  
  # return
  p
})

# ... save
png(paste0(fig.path, "appx_altdepvars",".png"), width = 9, height = 4, unit = "in", res = 600)
grid.arrange(grobs = plot.ls, ncol = 3)
dev.off()

for(s in c(1:length(stub.plot))){
  png(paste0(fig.path, "appx_", stub.plot[s] ,".png"), width = 4, height = 3, unit = "in", res = 600)
  par(mar = c(0,0,0,0))
  print(plot.ls[[s]])
  dev.off()
}


####################################
# General Robustness checks ########
####################################


# ... specify stubs
stub.plot <- c("allhyp", "road1990","allcontrols", "matching", 
               "nocontrols", "nosmallunit", "nobordercross",
               "unit.murdock", "unit.greg")

# ... titles
title.plot <- c("Baseline", "Road networks 1990",
                "Additional controls",
                "Distance-population bins",
                "No controls",
                "Drop: small groups",
                "Drop: X-border groups",
                "Unit: Murdock","Unit: GREG")
stopifnot(length(stub.plot) == length(title.plot))


# ... specify indpenedent variables to plot
var.plot <- c("rsc.1966","rsc.1990", "`rsc.1990(fit)`")

# ... y-labels 
y.labels <- c("Challenger", "Challenger Events", "State Events")

# ... Method
coef.df$Method <- ifelse(coef.df$type == "iv", "2SLS",
                         ifelse(coef.df$type == "ols", "OLS", NA))
coef.df$Method <- factor(coef.df$Method, 
                         levels = unique(coef.df$Method))

# ... subset data
plot.df <- coef.df[coef.df$stub %in% stub.plot & coef.df$var %in% var.plot,]

# ... convert dep.var to factor 
plot.df$dep.var <- factor(plot.df$dep.var,
                          levels = unique(plot.df$dep.var),
                          labels = y.labels)

plot.df$stub.fac <- factor(plot.df$stub,
                       levels = rev(unique(stub.plot)),
                       labels = rev(title.plot))
plot.df$pos <- as.numeric(plot.df$stub.fac)
plot.df$pos <- ifelse(plot.df$type == "ols", plot.df$pos + .15,
                      plot.df$pos - .15)

# ... plot
p <- ggplot(plot.df, aes(y = pos, x = coef, color = Method, pch = Method)) + 
  geom_point() + 
  geom_errorbarh(aes(xmin = coef - 1.96*se, 
                     xmax = coef + 1.96*se), 
                 height=.1) +
  geom_vline(xintercept = 0, color = "darkgrey", lty = 2) + 
  scale_y_continuous(breaks = unique(as.numeric(plot.df$stub.fac)), 
                     labels = unique(as.character(plot.df$stub.fac)))  +
  scale_x_continuous(breaks = seq(-1,0,by = .5))  +
  xlab("Coefficient of RSC") + ylab(NULL) + 
  facet_wrap(~ dep.var, nrow = 1) + 
  colMethod + pchMethod +
  NULL


# ... save
png(paste0(fig.path, "appx_robmain.png"), width = 8, height = 4, unit = "in", res = 600)
par(mar = c(0,0,0,0))
print(p)
dev.off()



####################################
# Cross-Sectional Analysis #########
####################################


# ... specify stubs
stub.plot <- c("crossethno1997", "crossethnoindep")

# ... titles
title.plot <- c("Cross-section 1997",
                "Cross-section independence")


# ... specify indpenedent variables to plot
var.plot <- c("rsc.1966", "`rsc.1990(fit)`")

# ... y-labels 
y.labels <- c("Challenger", "Challenger Events", "State Events")


# ... subset data
plot.df <- coef.df[coef.df$stub %in% stub.plot & coef.df$var %in% var.plot,]

# ... Method
plot.df$Method <- ifelse(grepl("1990", plot.df$var), "2SLS", "OLS")
plot.df$Method <- factor(plot.df$Method, 
                         levels = unique(plot.df$Method))

# ... convert dep.var to factor 
plot.df$dep.var <- factor(plot.df$dep.var,
                          levels = unique(plot.df$dep.var),
                          labels = y.labels)

plot.df$stub <- factor(plot.df$stub,
                       levels = rev(unique(plot.df$stub)),
                       labels = rev(title.plot))
plot.df$pos <- as.numeric(plot.df$stub)
plot.df$pos <- ifelse(plot.df$Method == "OLS", plot.df$pos + .15,
                      plot.df$pos - .15)

# ... plot
p <- ggplot(plot.df, aes(y = pos, x = coef, color = Method, pch = Method)) + 
  geom_point() + 
  geom_errorbarh(aes(xmin = coef - 1.96*se, 
                     xmax = coef + 1.96*se), 
                 height=.1) +
  geom_vline(xintercept = 0, color = "darkgrey", lty = 2) + 
  scale_y_continuous(breaks = unique(as.numeric(plot.df$stub)), 
                     labels = unique(as.character(plot.df$stub)))  +
  xlab("Coefficient of RSC") + ylab(NULL) + 
  facet_wrap(~ dep.var, nrow = 1) + 
  colMethod + pchMethod +
  NULL


# ... save
png(paste0(fig.path, "appx_crosssec.png"), width = 8, height = 2, unit = "in", res = 600)
par(mar = c(0,0,0,0))
print(p)
dev.off()


####################################
# Alternative functional forms #####
####################################


# ... specify stubs
stub.plot <- c("logistic",   "negbin")

# ... titles
title.plot <- c("Logit",
                "Negative binomial")


# ... specify indpenedent variables to plot
var.plot <- c("rsc.1966")

# ... y-labels 
y.labels <- c("Challenger", "Challenger Events", "State Events")


# ... subset data
plot.df <- coef.df[coef.df$stub %in% stub.plot & coef.df$var %in% var.plot,]


# ... convert dep.var to factor 
plot.df$dep.var <- factor(plot.df$dep.var,
                          levels = unique(plot.df$dep.var),
                          labels = y.labels)

plot.df$stub <- factor(plot.df$stub,
                       levels = rev(unique(plot.df$stub)),
                       labels = rev(title.plot))
plot.df$pos <- as.numeric(plot.df$stub)


# ... plot
p <- ggplot(plot.df, aes(y = pos, x = coef)) + 
  geom_point() + 
  geom_errorbarh(aes(xmin = coef - 1.96*se, 
                     xmax = coef + 1.96*se), 
                 height=.1) +
  geom_vline(xintercept = 0, color = "darkgrey", lty = 2) + 
  scale_y_continuous(breaks = unique(as.numeric(plot.df$stub)), 
                     labels = unique(as.character(plot.df$stub)))  +
  xlab("Coefficient of RSC") + ylab(NULL) + 
  facet_wrap(~ dep.var, nrow = 1)
  NULL


# ... save
png(paste0(fig.path, "appx_funform.png"), width = 8, height = 2, unit = "in", res = 600)
par(mar = c(0,0,0,0))
print(p)
dev.off()

# Country-Jackknife ####

# ... prepare
plot.df <- cow.jack.df
plot.df$Method <- factor(plot.df$Method, 
                         levels = unique(plot.df$Method))
plot.df$pos <- ifelse(plot.df$Method == "OLS", plot.df$pos + .2, plot.df$pos - .2)

png(paste0(fig.path, "appx_cowjackknife.png"), height = 7, width = 10, res = 300, unit = "in")

print(ggplot(plot.df, aes(x = coef, y = pos, pch = Method, col = Method)) + geom_point() + 
        geom_errorbarh(aes(xmin = coef - 1.96 * se, xmax = coef + 1.96 * se), height=.1) +
        geom_vline(xintercept = 0, color = "darkgrey", lty = 2) + 
        scale_y_continuous(breaks = c( length(countries):1), labels = countries)  +
        ylab("") + xlab(paste("Marginal Effect of Relational State Capacity on main outcomes w/ 95% CI"))  + 
        theme(axis.text.y  = element_text(size = 8, color = "black"),
              legend.position="top") + 
        colMethod + pchMethod +
        facet_wrap( ~ Specification, nrow = 1)) 

dev.off()




