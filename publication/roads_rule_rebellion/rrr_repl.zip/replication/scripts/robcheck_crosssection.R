##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Cross-sectional Analysis ---
#
# Called from ../replicate_all.R
#
###########################################


##########################################
# CROSS-SECTIONAL ANALYSIS
# Appendix A4.8, Figure A12
###########################################



# LOAD DATA #############################

## Load data
cross.ls <- readRDS("data/conflictroads_crosssec.rds")

## loads cross-setion with borders from 1997 and independence
names(cross.ls)

###################################
# Cross-Sectional Analysis


# Names 
table.names <- c("Borders and capitals 1997 (dropping South Sudan)", "Borders and capitals at independence (dropping South Sudan, Eritrea, and Namibia)")

# Estimate
for(d in c(1:length(cross.ls))){
  
  # OLS #######################
  ## Appendix A4.8, Figure A12
  stub <- names(cross.ls)[d]
  
  # Setup
  form.str <- paste0(dep.global," ~ ", spec.ols)
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = cross.ls[[d]])})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                    mean.dv, f.stat)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title=paste("Cross-sectional design, OLS:",table.names[d]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = dv.labels,
              keep= ols.keep, covariate.labels = ols.labels,
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.ols(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$crosssec <- c(all.coef.ls$crosssec,
                      list(extract_coef(this.m)))
  names(all.coef.ls$crosssec)[length(all.coef.ls$crosssec)] <- stub
  
  # IV ########################
  ## Appendix A4.8, Figure A12
  stub <- paste0("iv.", names(cross.ls)[d])
  
  # Setup
  
  # ... first stage
  form.str <- c(paste(endog.vars, " ~ ",paste(instr.vars, collapse = "+"),"+",iv.controls,
                      fe.global, 
                      "0 |", 
                      cluster.global))
  # ... second stage
  form.str <- c(form.str, paste0(dep.global," ~ ", spec.iv))
  
  # Estimation
  this.m <- lapply(form.str, function(s){felm(as.formula(s), data = cross.ls[[d]][!is.na(cross.ls[[d]][,dv[1]]),])})
  
  
  # Results
  f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
  f.stat.s1 <- latex.any.row("F-Stat Stage 1:", unlist(lapply(this.m, function(m){
     f <- m$stage1$iv1fstat
     if(is.null(f)){ "" } else { as.character(round_any(f$rsc.1990["F"], 0.01))}
  })) )
  
  mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )
  add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels)+1)),
                    latex.any.row("Controls: ",rep("yes",length(dv.labels)+1)),
                    mean.dv, f.stat,f.stat.s1)
  
  fileConn<-file(paste0(tab.path, stub, stargazer.type[2]))
  writeLines(
    stargazer(this.m,
              title=paste("Cross-sectional design, 2SLS:",table.names[d]),
              dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
              column.labels = paste0(c(" Stage 1} &  & \\multicolumn{1}{c}{Stage 2} & \\\\ 
                                     \\cmidrule(lr){2-2} \\cmidrule(lr){3-5} & \\multicolumn{1}{c}{",rep("",3)),
                                     gsub(" (log)","",c(iv.labels[1],dv.labels), fixed = T)),
              order = c(stage1.keep,iv.keep), keep= c(stage1.keep,iv.keep) , covariate.labels = c(stage1.labels,iv.labels),
              notes.align = "l",label=paste0("tab.",stub),align =T,
              add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
              omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
              notes = latex.notes.iv(), notes.label = "", notes.append = F,
              type  = stargazer.type[1]), 
    fileConn)
  close(fileConn)
  
  # Save coefficients
  all.coef.ls$crosssec <- c(all.coef.ls$crosssec,
                            list(extract_coef(this.m)))
  names(all.coef.ls$crosssec)[length(all.coef.ls$crosssec)] <- stub
}

