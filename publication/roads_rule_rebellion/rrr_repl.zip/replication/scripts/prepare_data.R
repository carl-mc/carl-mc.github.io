##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Load all Data ---
#
# Called from ../replicate_all.R
#
###########################################




# DATA #########################

# Load Main Data
#   This list contains the datasets for datasets derived from 
#   spatial data from Ethnologue (main), Murdock, and GREG
data.ls <- readRDS("data/conflictroads_data.rds")
names(data.ls)


# Use ethnologue as main data set
data.main <- data.ls[["ethno"]]


# Load WLMS Group Polygons
ethno.spdf <- readOGR(dsn = file.path(getwd(), "data/shapefiles"),
                      "groups_select")
colnames(ethno.spdf@data) <- c("cowcode" , "cow.period.id" ,"cowsyear" , "coweyear" , "ethno.id"    )

## c("cowcode" , "cow.period.id" , "ethno.id") can be used to join ethno.spdf and data.main (for each year).


