##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Main Empirical Specifications (OLS and IV) ---
#
# Called from ../replicate_all.R
#
###########################################

# INITIALIZE LIST TO COLLECT RESULTS #####

# Initialize coefficient list for Appendix plots
all.coef.ls <- list(ols = list(),
                    iv = list(),
                    crosssec = list())


# SPECIFICATION GLOBALS ##################


# Main dependent variables
dv <- c("challenger.num", "acled.nonstateorg.count", "acled.state.count")
dv.labels <- c("Challengers", "Challenger Events", "State Events")

# Main functional form of DV
dep.global <- paste0("log(",dv,"+1)")

# Main fixed effect throughout
#   Country-year (cow.year)
fe.global <- "| cow.year |"

# Cluster for standard errors
#   Ethnic group (id) and country-year (cow.year)
cluster.global <- "id + cow.year"

# Significance stars
notes.p <- " Significance codes: $^{*}$p$<$0.1; $^{**}$p$<$0.05; $^{***}$p$<$0.01."
star.cutoffs <- NULL



# OLS ###################################


# Main explanatory variables
#    RSC and foot travel access to capital and internal connectedness
expl.global <- paste(c("rsc.1966", 
                       paste0(" I(log(1/(",c("foot.capital.mean.", "foot.internal.mean."), #
                              1966," + 1)))")), collapse = " + ")
ols.labels <- c("RSC 1966 (log)","State access 1966; foot (log)",
                "Internal connectedness 1966; foot (log)")
ols.keep <- c(1:3)

# Main controls 
main.controls <- c("log(pop) + log(pop.urban + 1) +  log(poly.area.km2)") 
add.controls <- paste(c("median.altitude","median.slope", "precipitation", "evapotranspiration", "ppetratio" ,
                        "temperaturemean", "max.cash.crop", "suit","mindeposit.any",
                        "log(dist.coast)", "log(dist.river)",
                        "is.capital", "log(border.dist + 1)"),
                      collapse = " + ")

# Main OLS specification
spec.ols <- paste(expl.global, " + ", main.controls , " + ", add.controls, 
                    fe.global, " 0 |", cluster.global)



# INSTRUMENTAL VARIABLE APPROACH ########

# Endogenous variables
endog.vars <- c("rsc.1990")

# Instruments
instr.vars <- c("I(log(1/(opt.road.capital.mean.1880.1966 + 1)))", 
                "I(log(1/(opt.road.internal.mean.1880.1966 + 1)))")

# Controls (population different from OLS due to potential post-treatment bias)
iv.controls <- paste("I(log(1/(opt.foot.capital.mean.1880.1966 + 1))) + I(log(1/(opt.foot.internal.mean.1880.1966 + 1))) + ",
                     "log(opt.pop.graph.1880.1966 + 1) +  log(poly.area.km2)" ,"+", add.controls)

# Variable labels
iv.keep <- c("rsc.1990",
             "foot.capital.mean.1880","foot.internal.mean.1880")
iv.labels = c("RSC 1990 (log)",
              "State access 1880; foot (log)","Internal connectedness 1880; foot (log)")
stage1.keep <- c("road.capital.mean","road.internal.mean")
stage1.labels <- c("State access 1880 (sim; log)","Internal connectedness 1880 (sim; log)")

# 1 stage felm formula
stage1.form <- paste("(",paste(endog.vars, collapse = "+")," ~",paste(instr.vars, collapse = "+") ,") |")

# Type of condtional F-Stat to calculate for First Stages
condfstat.type = "cluster"

# Main IV specification
spec.iv <- paste(iv.controls , 
                   fe.global, stage1.form, cluster.global)



# LATEX NOTES #################
latex.notes.iv <-  function(width = .95){
  paste0("\\parbox[t]{",width,"\\textwidth}{\\textit{Notes:} 2SLS-IV models. ",
         "Control variables consist of the total population in 1880 (log), groups' area (log), ",
         "the mean annual temperature, precipitation, evaporation, ",
         "the ratio of precipitation and evaporation, and the mean altitude and slope of a group's settlement area, 
         its cash crop and agricultural suitability, a mineral deposit dummy, ",
         "as well as groups' logged distance to the closest coast, navigable river, and border. ",
         " Two-way clustered standard errors in parentheses (ethnic group and country-year clusters).",
         notes.p, "}")}

latex.notes.ols <-  function(width = .95){
  paste0("\\parbox[t]{",width,"\\textwidth}{\\textit{Notes:} OLS models. ",
         "Control variables consist of the total and urban population (log), groups' area (log), ",
         "the mean annual temperature, precipitation, evaporation, ",
         "the ratio of precipitation and evaporation, the mean altitude and slope of a group's settlement area, 
         its cash crop and agricultural suitability, a mineral deposit dummy, ",
         "as well as groups' logged distance to the closest coast, navigable river, and border. ",
         " Two-way clustered standard errors in parentheses (ethnic group and country-year clusters).",
         notes.p, "}")}