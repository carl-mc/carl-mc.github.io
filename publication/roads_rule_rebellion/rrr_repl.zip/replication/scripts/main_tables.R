##########################################
# Roads to Rule, Roads to Rebel: Relational State Capacity and Conflict in Africa
#
# Replication Files
#
# --- Tables in Main Paper ---
#
# Called from ../replicate_all.R
#
###########################################

###############################
# Split RSC ###################
# State access and internal connectedness #
###############################
# -- Main Paper, Table 1
stub <- "splitrsc"

# Setup
form.str <- paste0(dep.global," ~ ", gsub(paste0("rsc.1966"), 
                                          "I(log(1/(road.capital.mean.1966 + 1))) +  I(log(1/(road.internal.mean.1966 + 1)))",
                                          spec.ols))
this.keep <- c(1:4)
this.labels <- c("$\\beta_1$: State access '66 (log)" ,"$\\beta_2$: Internal connectedness '66 (log)", 
                 "State access; foot '66 (log)" ,"Internal connectedness '66; foot (log)")
# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Sumstats
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )

# Test of beta1 == beta2
beta.sum <- unlist(lapply(this.m, function(m){as.character(round_any(sum(m$coefficients[c(1,2),]), 0.01))}))
beta.sum.se <- unlist(lapply(this.m, function(m){paste0("(",round_any((sum(diag(m$clustervcv[c(1,2),c(1,2)])) + 2*m$clustervcv[1,2])^0.5, 0.01),")")}))

# Prepare table
add.lines <- list(latex.any.row("$\\beta_1 + \\beta_2$ ",beta.sum),
                  latex.any.row("",beta.sum.se),
                  latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

# Make table
fileConn <- file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Effect of the components of RSC, OLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= this.keep, covariate.labels = this.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T, column.sep.width = "0pt",
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(.9), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub




###############################
# All Hypotheses ##############
###############################
# -- Main Paper, Table 2
stub <- "allhyp"

# Setup
form.str <- paste0(dep.global," ~ ", spec.ols)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main)})


# Sumstats
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )

# Prepare Table
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

# Save Table
fileConn <- file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Relational state capacity and violence in Africa 1997--2016: Main Results, OLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            keep= ols.keep, covariate.labels = ols.labels,
            notes.align = "l",label=paste0("tab.",stub),align =T,column.sep.width = "0pt",
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(.9), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$ols <- c(all.coef.ls$ols,
                     list(extract_coef(this.m)))
names(all.coef.ls$ols)[length(all.coef.ls$ols)] <- stub




# //////////////////////////////////////////////////////////////////////////
############################################################################
# INSTRUMENTAL VARIABLE APPROACH ###########################################
############################################################################
# //////////////////////////////////////////////////////////////////////////
## -- Main Text, Table 3

###################
# Reduced Form
###################
## -- Main Text, Table 3,  upper panel


stub <- "iv.reduced"

# Setup
form.str <-paste(c(endog.vars, dep.global), " ~ ",paste(instr.vars, collapse = "+"), "+", iv.controls,
                 fe.global, 
                 "0 |", 
                 cluster.global)

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main[!is.na(data.main[,dv[1]]),])})


# Sumstats
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )

# Prepare Table
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels))),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels))),
                  mean.dv, f.stat)

# Save Table
fileConn <- file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Instrumental Variable Approach: First stage and reduced form",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = dv.labels,
            order = c(stage1.keep,iv.keep[2:3]), keep= c(stage1.keep,iv.keep) , covariate.labels = c(stage1.labels,iv.labels[2:3]),
            notes.align = "l",label=paste0("tab.",stub),align =T,
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.ols(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


###################
# 2SLS 
###################
## -- Main Text, Table 3, lower panel
stub <- "iv.allhyp"

# Setup
form.str <- c(paste0(dep.global," ~ ", spec.iv))

# Estimation
this.m <- lapply(form.str, function(s){felm(as.formula(s), data = data.main[!is.na(data.main[,dv[1]]),])})


# Sumstats
f.stat <- latex.any.row("F-Stat:", round_any(unlist(lapply(this.m, function(m){summary(m)$F.fstat["F"]})), 0.01) )
f.stat.s1 <- latex.any.row("F-Stat Stage 1:", unlist(lapply(this.m, function(m){
  f <- m$stage1$iv1fstat
  if(is.null(f)){ "" } else { as.character(round_any(f$rsc.1990["F"], 0.01))}
})) )
mean.dv <- latex.any.row("Mean DV", round_any(unlist(lapply(this.m, function(m){mean(m$response)})), 0.01) )

# Prepare Table
add.lines <- list(latex.any.row("Country-year FE: ",rep("yes",length(dv.labels) + 1)),
                  latex.any.row("Controls: ",rep("yes",length(dv.labels) + 1)),
                  mean.dv, f.stat,f.stat.s1)

# Save Table
fileConn <- file(paste0(tab.path, stub, stargazer.type[2]))
writeLines(
  stargazer(this.m,
            title="Relational state capacity and violence in Africa 1997--2016: Main Results, 2SLS",
            dep.var.caption = "Dependent variable (logged)",dep.var.labels.include = FALSE,
            column.labels = paste0(c(" } \\multicolumn{3}{c}{Stage 2} \\\\ 
                                     \\cmidrule(lr{10pt}){2-2} \\cmidrule(lr{10pt}){3-5} & \\multicolumn{1}{c}{RSC 1990} 
                                    & \\multicolumn{1}{c}{Challengers} & \\multicolumn{1}{c}{Challenger} & \\multicolumn{1}{c}{State} \\\\ 
                                     & \\multicolumn{1}{c}{",rep("",3)),
                                   c("","" ,"events","events")),
            order = c(stage1.keep,iv.keep), keep= c(iv.keep) , covariate.labels = c(iv.labels),
            notes.align = "l",label=paste0("tab.",stub),align =T, column.sep.width = "-10pt",
            add.lines = add.lines, digits = 3, intercept.top = T,intercept.bottom = F,
            omit.stat = c("rsq","res.dev","ser"), star.cutoffs = star.cutoffs,
            notes = latex.notes.iv(), notes.label = "", notes.append = F,
            type  = stargazer.type[1]), 
  fileConn)
close(fileConn)

# Save coefficients
all.coef.ls$iv <- c(all.coef.ls$iv,
                    list(extract_coef(this.m)))
names(all.coef.ls$iv)[length(all.coef.ls$iv)] <- stub


