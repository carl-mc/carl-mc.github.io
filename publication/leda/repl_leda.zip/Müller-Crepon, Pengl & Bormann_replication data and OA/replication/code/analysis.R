#### #### #### #### #### #### #### 
## Run Afrobarometer Models on co-ethnic approval of governments


# LOAD DATA ##########################

# Load all data

## Afrobarometer
ab.df <- readRDS(file.path(data.path, "appl_afrobarometer.rds"))

## Links with EPR and FRT
eprfrt2ab.ls <- readRDS(file.path(data.path, "appl_matches.rds"))

# Merge
dat <- join_all(c(list(ab.df), 
                  eprfrt2ab.ls), 
                type="left",
                by = c("cowcode", "round", "language", "year_min"),
                match = "first")



# VARIABLES ##########################

# trust in president (standardize)
dat$trust_president_std <- scale(dat$trust_president)[,1]

# ethnic grievances
dat$ethnic_unfair <- scale(dat$grief_ethfairtreat)[,1]

# code country round  IDs
dat$country_round <- factor(paste(dat$cowcode,dat$round,sep="_"))


# ANALYSIS ############################



# EPR ##########

# Prepare

## prepare tables
latex.country.fe <- function(entries){c("Country-Survey FE",paste0("\\multicolumn{1}{c}{",entries,"}"))}
latex.ethnic.fe <- function(entries){c("Ethnic Group FE",paste0("\\multicolumn{1}{c}{",entries,"}"))}
latex.notes.long <- "\\parbox[t]{\\textwidth}{\\textit{Notes:} Dependent variable standardized to mean $0$ and sd $1$.
Control variables include age, age squared, education level indicators, a female and an urban dummy. 
Standard errors clustered on ethnic group in parentheses.
Significance codes: $^{*}$p$<$0.05; $^{**}$p$<$0.01; $^{***}$p$<$0.001}"


add.lines <- list(latex.country.fe(rep("yes",6)), 
                  latex.ethnic.fe(rep(c("no","yes"),3)))
keep.lines <-  c("status_high","status_high_dist_exp")



# Trust in President

## Estimate
outcomes <- rep(c("I(trust_president_std*-1)"),6)
predictors <- rep(c("status_high","status_high_dist_exp","status_high + status_high_dist_exp"),each=2)
control.str <- "+ sex + urban + age + I(age^2) + factor(educ)"
add.felm <- c("|country_round  | 0 | high_group_id",
              "|country_round + high_group_id | 0 | high_group_id",
              "|country_round | 0 | high_group_id_dist_exp",
              "|country_round + high_group_id_dist_exp | 0 | high_group_id_dist_exp",
              "|country_round | 0 | high_group_id",
              "|country_round + high_group_id  | 0 | high_group_id")

m.list.out <- lapply(c(1:6),function(i){
  felm(formula = as.formula(paste(outcomes[i], "~", predictors[i],control.str,add.felm[i])), 
       data = dat) 
})

## Output
fileConn<-file(file.path(tab.path,"table2.tex"))
writeLines(stargazer(m.list.out,
                     title="Afrobarometer Analysis: Distrust in President",
                     keep=keep.lines,
                     multicolumn=F,# se = se,
                     dep.var.caption = "Mistrust in President",dep.var.labels = rep("",6),
                     column.labels = c("Binary Link","Cont. Link","Both"),
                     column.separate = c(2,2,2),
                     covariate.labels=c("Ethnic Link to Gov.",
                                        "Ling. Dist. to Gov"),
                     font.size = "scriptsize",
                     star.cutoffs = c(0.05,0.01,0.001),
                     notes.align = "c",label="mistrust_high_paper",align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     column.sep.width = "-5pt",
                     notes = latex.notes.long, notes.label = "", notes.append = F), 
           fileConn)
close(fileConn)



# Ethnic grievance models: treated unfairly by government

## Estimate
outcomes <- rep(c("ethnic_unfair"),6)
predictors <- rep(c("status_high","status_high_dist_exp","status_high + status_high_dist_exp"),each=2)
control.str <- "+ sex + urban  + age + I(age^2)+ factor(educ)"
add.felm <- c("|country_round  | 0 | high_group_id",
              "|country_round + high_group_id | 0 | high_group_id",
              "|country_round | 0 | high_group_id_dist_exp",
              "|country_round + high_group_id_dist_exp | 0 | high_group_id_dist_exp",
              "|country_round | 0 | high_group_id",
              "|country_round + high_group_id  | 0 | high_group_id")

m.list.out2 <- lapply(c(1:6),function(i){
  felm(formula = as.formula(paste(outcomes[i], "~", predictors[i],control.str,add.felm[i])), data = dat) 
})

## Output
fileConn<-file(file.path(tab.path,"table3.tex"))
writeLines(stargazer(m.list.out2,
                     title="Ethnic Grievances: Unfairly Treated by Government",
                     keep=keep.lines,
                     multicolumn=F,# se = se,
                     dep.var.caption = "Unfair treatment of own group",dep.var.labels = rep("",6),
                     column.labels = c("Binary Link","Cont. Link","Both"),
                     column.separate = c(2,2,2),
                     covariate.labels=c("Ethnic Link to Gov.",
                                        "Ling. Dist. to Gov"),
                     font.size = "scriptsize",
                     star.cutoffs = c(0.05,0.01,0.001),
                     notes.align = "c",label="grievances_paper",align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     column.sep.width = "-5pt",
                     notes = latex.notes.long, notes.label = "", notes.append = F), 
           fileConn)
close(fileConn)






# FRT comparison ##########

# Prepare

## get subset of countries with FRT data
frt.countries <- unique(dat$cowcode[!is.na(dat$leadergroup)])

## get years covered by FRT (<2005)
frt.years <- unique(dat$year_min[!is.na(dat$leadergroup)])

## subset dataframe to what's covered in FRT
dat2 <- dat[dat$cowcode%in%frt.countries & dat$year_min%in%frt.years,]


# Mistrust on inclusion from EPR and FRT on FRT sample

## Estimate
outcomes <- rep(c("I(trust_president_std*-1)"),6)
predictors <- rep(c("status_high","status_high_dist_exp","status_high + status_high_dist_exp","leadergroup","leadergroup_dist_exp","leadergroup + leadergroup_dist_exp" ))
control.str <- "+ sex + urban + age + I(age^2) + factor(educ)"
add.felm <- c("|country_round  | 0 | high_group_id",
              "|country_round | 0 | high_group_id",
              "|country_round | 0 | high_group_id",
              "|country_round | 0 | leadergroup_id",
              "|country_round | 0 | leadergroup_id",
              "|country_round | 0 | leadergroup_id")

m.list.frt.long <- lapply(c(1:6),function(i){
  felm(formula = as.formula(paste(outcomes[i], "~", predictors[i],control.str,add.felm[i])), data = dat2) 
})


## Prepare regression table & save
add.lines <- list(latex.country.fe(rep("yes",6)), 
                  latex.ethnic.fe(rep(c("no"),6)))
keep.lines <-  c("status_high","status_high_dist_exp","leadergroup","leadergroup_dist_exp")

fileConn<-file(file.path(tab.path,"tablea7.tex"))
writeLines(stargazer(m.list.frt.long,
                     title="Mistrust in President: EPR \\& FRT",
                     keep=keep.lines,
                     multicolumn=F,# se = se,
                     dep.var.caption = "Mistrust in President",dep.var.labels = rep("",6),
                     column.labels = c("EPR","FRT"),
                     column.separate = c(3,3),
                     covariate.labels=c("Ethnic Link to Gov.",
                                        "Ling. Dist. to Gov.",
                                        "Ethnic Link to Leader",
                                        "Ling. Dist. to Leader"),
                     font.size = "scriptsize",
                     star.cutoffs = c(0.05,0.01,0.001),
                     notes.align = "c",label="mistrust_frt",align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     column.sep.width = "-5pt",
                     notes = latex.notes.long, notes.label = "", notes.append = F), 
           fileConn)
close(fileConn)


# Grievance models with inclusion from EPR and FRT on FRT sample

## Estimate
outcomes <- rep(c("ethnic_unfair"),6)
predictors <- rep(c("status_high","status_high_dist_exp","status_high + status_high_dist_exp","leadergroup","leadergroup_dist_exp","leadergroup + leadergroup_dist_exp" ))
control.str <- "+ sex + urban + age + I(age^2) + factor(educ)"
add.felm <- c("|country_round  | 0 | high_group_id",
              "|country_round | 0 | high_group_id",
              "|country_round | 0 | high_group_id",
              "|country_round | 0 | leadergroup_id",
              "|country_round | 0 | leadergroup_id",
              "|country_round | 0 | leadergroup_id")

m.list.frt.long2 <- lapply(c(1:6),function(i){
  felm(formula = as.formula(paste(outcomes[i], "~", predictors[i],control.str,add.felm[i])), data = dat2) 
})



## prepare regression table
add.lines <- list(latex.country.fe(rep("yes",6)), 
                  latex.ethnic.fe(rep(c("no"),6)))
keep.lines <-  c("status_high","status_high_dist_exp","leadergroup","leadergroup_dist_exp")

fileConn<-file(file.path(tab.path,"tablea8.tex"))
writeLines(stargazer(m.list.frt.long2,
                     title="Ethnic Grievances: EPR \\& FRT",
                     keep=keep.lines,
                     multicolumn=F,# se = se,
                     dep.var.caption = "Unfair treatment of own group",dep.var.labels = rep("",6),
                     column.labels = c("EPR","FRT"),
                     column.separate = c(3,3),
                     covariate.labels=c("Ethnic Link to Gov.",
                                        "Ling. Dist. to Gov.",
                                        "Ethnic Link to Leader",
                                        "Ling. Dist. to Leader"),
                     font.size = "scriptsize",
                     star.cutoffs = c(0.05,0.01,0.001),
                     notes.align = "c",label="grievances_frt",align =T,
                     add.lines = add.lines,digits = 3, intercept.top = T,intercept.bottom = F,
                     omit.stat = c("rsq","res.dev","ser"),
                     column.sep.width = "-5pt",
                     notes = latex.notes.long, notes.label = "", notes.append = F), 
           fileConn)
close(fileConn)



