# FIGURE 1 ###########



# LISTS TO ETHNOLOGUE STAR

# ... star setup 
star.ties <- cbind(c( "Murdock" , "PREG","SIDE","Afrobarometer", "AMAR" , "DHS" , "EPR" , "Fearon" , "FRT2015" , "GREG" ,
                      "IPUMS" ),
                   "Ethnologue")
star.graph <- igraph::graph_from_edgelist(star.ties, directed = T)


# ... plot
tiff(file.path(fig.path, "figure1.tiff"), compression = "lzw", 
     width = 4, height = 4, units = "in", res = 600)
par(mar = c(0,0,0,0))
set.seed(250589)
plot.igraph(star.graph, 
            edge.arrow.size = .6, 
            vertex.label.cex = .9, vertex.shape="circle", 
            vertex.size = ifelse(names(V(star.graph)) == "Ethnologue", 60, 40), 
            vertex.color = "white", vertex.frame.color = "white",
            layout = layout_as_star(star.graph, center = "Ethnologue"),
            vertex.size = 5, vertex.label.color = "black")
dev.off()


png(file.path(fig.path, "figure1.png"), 
     width = 4, height = 4, units = "in", res = 600)
par(mar = c(0,0,0,0))
set.seed(250589)
plot.igraph(star.graph, 
            edge.arrow.size = .6, 
            vertex.label.cex = .9, vertex.shape="circle", 
            vertex.size = ifelse(names(V(star.graph)) == "Ethnologue", 60, 40), 
            vertex.color = "white", vertex.frame.color = "white",
            layout = layout_as_star(star.graph, center = "Ethnologue"),
            vertex.size = 5, vertex.label.color = "black")
dev.off()
