# LEDA Replication: Packages


## Liast of packages
pcks <- c("ggplot2", "lfe", "viridisLite",  "plyr",
          "igraph", "gtools", "fields", 
          "snow", "foreach", "parallel","doParallel", "viridis",
          "tidyverse", "Hmisc", "countrycode", "stargazer")

## Install if not there
for(p in pcks){
  if(!p %in% installed.packages()[,"Package"]){
    print(p)
    install.packages(p)
  }
}
rm(pcks)

## Load packages
library(lfe)
library(viridisLite)
library(plyr)
library(igraph)
library(gtools)
library(fields)
library(snow)
library(parallel)
library(doParallel)
library(foreach)
library(tidyverse)
library(ggplot2)
library(Hmisc)
library(countrycode)
library(stargazer)
library(viridis)

