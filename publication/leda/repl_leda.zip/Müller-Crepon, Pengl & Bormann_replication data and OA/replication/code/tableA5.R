# TABLE A5 ################

# Overlap between coded and automatically generated matches
# Table with Stats on use of automatic matches
#'   Format: Type + Total X Matches %

# ... prepare
auto.types <- names(lists.matched.ls)[!names(lists.matched.ls) %in% c("ethnomap", "PREG", "WLMS")]
auto.types <- auto.types[order(auto.types)]
auto.match.vars <- c("auto_match_org", "auto_match_alt","auto_match_dial","auto_match_foreign")
auto.match.use.stats <- do.call(rbind, lapply(auto.types, function(n){
  d <- lists.matched.ls[[n]]
  # ... split matches
  auto.m <- lapply(auto.match.vars, function(v){lapply(strsplit(d[,v], "|", fixed = T), function(x){
    unique(gsub("\\s*\\[[^\\]+\\]","",x))
  })})
  m <- lapply(strsplit(d[,"match"], "|", fixed = T), function(x){
    unique(gsub("\\s*\\[[^\\]+\\]","",x))
  })
  # ... calculate stats
  stat.long <- do.call(cbind, lapply(auto.m, function(a){
    r <- do.call(rbind, lapply(c(1:length(a)),function(i){
      c(length(a[[i]]), sum(a[[i]] %in% m[[i]]))
    }))
  }))
  stat.long <- cbind(stat.long, do.call(rbind, lapply(c(1:length(m)),function(i){
    a <- unique(unlist(lapply(auto.m, function(j){j[[i]]})))
    c(length(a), sum(a %in% m[[i]]))
  })))
  colnames(stat.long) <- paste0(rep(c(auto.match.vars, "auto_match_all"), each = 2), 
                                c("_num", "_matched"))
  stat.long <- cbind(stat.long, 
                     match_num = unlist(lapply(m, length)),
                     prop_num = unlist(lapply(c(1:length(m)),function(i){
                       length(unique(unlist(lapply(auto.m, function(j){j[[i]]}))))
                     })) )
  colSums(stat.long)
}))
auto.match.use.stats <- data.frame(rbind(auto.match.use.stats, 
                                         colSums(auto.match.use.stats)), stringsAsFactors = F)
auto.match.use.stats$type <- c(auto.types, "Total")
auto.match.use.stats$type[auto.match.use.stats$type == "EPR2013"] <- "EPR"
auto.match.use.stats$type[auto.match.use.stats$type == "FRT2015"] <- "FRT"
auto.match.use.stats$type <- c(auto.types, " \\hline \\\\[-1.8ex]  Total")


# ... make Table
tab.vars <- c("auto_match_org", "auto_match_all")
col.heads <- c("", rep(c("", "Language name", "Any name"), 2))
tab.df <- cbind(auto.match.use.stats$type,
                auto.match.use.stats$match_num,
                auto.match.use.stats[,paste0(tab.vars, "_matched")] / auto.match.use.stats$match_num,
                auto.match.use.stats$prop_num,
                auto.match.use.stats[,paste0(tab.vars, "_matched")] / auto.match.use.stats[,paste0(tab.vars, "_num")])
prop.vars <- c(3:(3+length(tab.vars) - 1), (3+length(tab.vars)+1):(3+length(tab.vars)*2))
tab.df[,prop.vars] <- apply(tab.df[,prop.vars]*100, 2, round_any, 1)

tab.string <- paste0("\\begin{table}[!htbp] \\centering ",
                     "\\caption{Overlap between coded and automatically proposed matches} ",
                     "\\label{tab.auto.match.stats} ",
                     "\\begin{tabular}{@{\\extracolsep{3pt}}l",paste(rep("D{.}{.}{-0}", 2 * (1+length(tab.vars))), 
                                                                     collapse = " ")," } ",
                     "\\\\[-1.8ex]\\hline ",
                     "\\hline \\\\[-1.8ex] ",
                     "Type & \\multicolumn{",1+length(tab.vars),"}{c}{Matches coded} &  \\multicolumn{",1+length(tab.vars),"}{c}{Matches proposed} \\\\  \\\\[-1.8ex]",
                     "\\cline{2-4} \\cline{5-7} \\\\[-1.8ex]",
                     "& \\multicolumn{1}{c}{Total} & \\multicolumn{",length(tab.vars),"}{c}{same as proposed match (in \\%)} & ",
                     "\\multicolumn{1}{c}{Total} & \\multicolumn{",length(tab.vars),"}{c}{same as coded match (in \\%)} \\\\  \\\\[-1.8ex] ",
                     "\\cline{3-4} \\cline{6-7} \\\\[-1.8ex]",
                     "\\multicolumn{1}{c}{",paste(col.heads, collapse = "} & \\multicolumn{1}{c}{"), "}\\\\ \\\\[-1.8ex] \\hline \\\\[-1.8ex]",
                     paste(apply(tab.df, 1, paste, collapse = " & "), collapse = " \\\\ \\\\[-1.8ex] \n "),
                     "\\\\  \\\\[-1.8ex] \\hline \\hline \\\\[-1.8ex] ",
                     "\\multicolumn{7}{l}{\\parbox[t]{0.95\\textwidth}{\\textit{Note:} ",
                     "`Org. name' refers to automatically proposed matches on the basis of the names of Ethnologue's languages and the clusters they belong to. ",
                     "`Any' refers to any type of automtically proposed match. Thus, in the case of Afrobarometer, of ",
                     tab.df[1,2], " matches, ", tab.df[1,3], "\\% have been proposed automatically based on the name of an Ethnologue langauge. ", 
                     tab.df[1,4], "\\% have been proposed based on any name, alternative name or subdialect of a language, or langauge from other countries.",
                     " Reversely, of the ",tab.df[1,5], " proposals made for Afrobarometer matches, only  ",tab.df[1,7],
                     "\\% have been coded as actual match.",
                     "}} \\\\ ",
                     "\\end{tabular}  \\end{table} ")

# ... print
fileConn<-file(file.path(tab.path, "tablea5.tex"))
writeLines(tab.string, 
           fileConn)
close(fileConn)

