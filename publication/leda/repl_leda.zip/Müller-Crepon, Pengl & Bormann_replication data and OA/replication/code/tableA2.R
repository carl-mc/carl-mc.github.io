# TABLEE A2 ###################



# DATA: Ethnologue

# ... load
ethnologue.full <- leda.obj$.__enclos_env__$private$ethno.df

# ... ethnologue wide --> long
ethno.long.safe <- leda.obj$.__enclos_env__$private$ethno.long

# DATA: All links
links.comb.df <- do.call(smartbind, 
                         lapply(names(lists.matched.ls)[!names(lists.matched.ls) %in% c("WLMS", "PREG", "SIDE")], function(n){
  lists.matched.ls[[n]]
}))
links.comb.df$group.id <- 1:nrow(links.comb.df)

# links (round 1 and 2) ###

# ... wide to long
link.r1.long <- LEDA:::links_wide2long(data.frame(links.comb.df[,c("iso3c","group.id")], 
                                              link.type = links.comb.df$type,
                                              link = links.comb.df$match.r1, stringsAsFactors = F))
link.r1.long <- link.r1.long[!link.r1.long$link %in% c(NA,""),]
link.r1.long$link.id <- 1:nrow(link.r1.long)
link.r2.long <- LEDA:::links_wide2long(data.frame(links.comb.df[,c("iso3c","group.id")], 
                                              link.type = links.comb.df$type,
                                              link = links.comb.df$match.r2, stringsAsFactors = F))
link.r2.long <- link.r2.long[!link.r2.long$link %in% c(NA,""),]
link.r2.long$link.id <- 1:nrow(link.r2.long)

# Get ethnologue dialect nodes

# ... merge links with ethnologue
ethno.long <- ethno.long.safe
ethno.long$link <- ethno.long$group
link.r1.long <- LEDA:::link_long_4steps(ethno.long = ethno.long, link.long = link.r1.long)
link.r1.long <- link.r1.long[!link.r1.long$ethno.id %in% c(NA),]
link.r2.long <- LEDA:::link_long_4steps(ethno.long = ethno.long, link.long = link.r2.long)
link.r2.long <- link.r2.long[!link.r2.long$ethno.id %in% c(NA),]

# ... order by level for easy processing
link.r1.long <- link.r1.long[order(link.r1.long$level),]
link.r2.long <- link.r2.long[order(link.r2.long$level),]

# ... get all dialect nodes
dial.nodes.r1 <- unique(do.call(rbind, lapply(unique(link.r1.long$level), function(l){
  link.vars <- c(paste0("level", 1:14), "name","iso","dialect")[1:l]
  join(link.r1.long[link.r1.long$level == l, c("group.id",link.vars )],
       ethno.long[ethno.long$level == 17,], by = link.vars)[,c("group.id", "ethno.id")]
})))
stopifnot(length(unique(dial.nodes.r1$group.id)) == length(unique(link.r1.long$group.id)))

dial.nodes.r2 <- unique(do.call(rbind, lapply(unique(link.r2.long$level), function(l){
  link.vars <- c(paste0("level", 1:14), "name","iso","dialect")[1:l]
  join(link.r2.long[link.r2.long$level == l, c("group.id",link.vars )],
       ethno.long[ethno.long$level == 17,], by = link.vars)[,c("group.id", "ethno.id")]
})))
stopifnot(length(unique(dial.nodes.r2$group.id)) == length(unique(link.r2.long$group.id)))


# Direct comparison
links.comb.df$comparison <- unlist(lapply(links.comb.df$group.id, function(g){
  string1 <- links.comb.df$match.r1[links.comb.df$group.id == g]
  string2 <- links.comb.df$match.r2[links.comb.df$group.id == g]
  set1 <- dial.nodes.r1$ethno.id[dial.nodes.r1$group.id == g]
  set2 <- dial.nodes.r2$ethno.id[dial.nodes.r2$group.id == g]
  # Both Missing
  if(length(set1) == 0 & length(set2) == 0 & string1 %in% c("", NA) & string2 %in% c("", NA)){
    "=="
    # Not found
  } else if(length(set1) == 0 & length(set2) == 0 & !string1 %in% c("", NA) & !string2 %in% c("", NA)){
    "ERROR//ERROR"
    # Not found
  } else if(length(set1) == 0 & length(set2) == 0 & !string2 %in% c("", NA)){
    "<//ERROR"
    # Not found
  } else if(length(set1) == 0 & length(set2) == 0 &  !string1 %in% c("", NA)){
    "ERROR//>"
    # Only one missing
  } else if (length(set1) > 0 & length(set2) == 0){
    "<//NA"
  } else if (length(set1) == 0 & length(set2) > 0){
    "NA//>"
    # Same set
  } else if (all(set1 %in% set2) & all(set2 %in% set1)){
    "=="
  } else if (!all(set1 %in% set2) & all(set2 %in% set1)){
    ">>"
  } else if (all(set1 %in% set2) & !all(set2 %in% set1)){
    "<<"
  } else if (!all(set1 %in% set2) & !all(set2 %in% set1) & any(set1 %in% set2)){
    "<>"
  } else if (!all(set1 %in% set2) & !all(set2 %in% set1) & !any(set1 %in% set2)){
    "<//>"
  } else {
    "Unknown condition"
  }
}))

# Add final link column
links.comb.df$link_final <- ""
links.comb.df$comment_final <- ""

# Precode final link for ==
links.comb.df$link_final[links.comb.df$comparison == "=="] <- links.comb.df$match.r2[links.comb.df$comparison == "=="] 

# Sort
links.comb.df <- links.comb.df[order(links.comb.df$iso3c, links.comb.df$group, links.comb.df$type),]
links.comb.df[is.na(links.comb.df)] <- ""



# Make nice Table by type ####

# ... init table object
table.df <- links.comb.df

# ... recode errors into smaller categories
table.df$comp.type <- ifelse(table.df$comparison %in% c("<//>"), "Disjoint",
                             ifelse(table.df$comparison %in% c("<//ERROR", "ERROR//>", "NA//>","<//NA"), "One missing",
                                    ifelse(table.df$comparison %in% c("<<","<>",">>"), "Partial overlap",
                                           ifelse(table.df$comparison %in% c("=="), "Equal", NA))))

# ... Make table
print.df <- data.frame(rbind(All = table(table.df$comp.type)/length(table.df$comp.type),
                             table(table.df$type, table.df$comp.type) / 
                               as.vector(table(table.df$type))))
# ... add total number
print.df$N <- c(length(table.df$comp.type),
                as.vector(table(table.df$type)))

# ... rename types
print.df$Type <- rownames(print.df)
print.df$Type[print.df$Type == "Murdock_Map"] <- "Murdock Map"
print.df$Type[print.df$Type == "EPR2013"] <- "EPR"
print.df$Type[print.df$Type == "FRT2015"] <- "FRT"
print.df$Type[print.df$Type == "DHS"] <- "DHS/SIDE"

# ... sort
print.df <- print.df[,c("Type","N","Equal", "Partial.overlap", "One.missing","Disjoint")]
tab.names <- c("Type","N","Equal", "Partial overlap", "Missing link","Disjoint")

# ... make table string
tab.string <- stargazer(print.df, 
                        title="Intercoder reliability: By list type",
                        dep.var.caption = "",
                        covariate.labels =tab.names,summary = F,
                        rownames = F,
                        digits = 2,label=paste0("intercoder_bytype"),align =T,
                        type  = "latex")
tab.string <- gsub("Afrobarometer",  "\\\\hline \\\\\\\\[-1.8ex] Afrobarometer", tab.string)

# ... print table
fileConn<-file(file.path(tab.path, paste0("tablea2", ".tex")))
writeLines(
  tab.string, 
  fileConn)
close(fileConn)


