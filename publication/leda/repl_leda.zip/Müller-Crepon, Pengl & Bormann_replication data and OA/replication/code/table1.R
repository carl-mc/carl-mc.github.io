######################################
# TABLE 1
######################################

# Matching statistics as Table


# ... prepare
match.stats.df <- data.frame(do.call(rbind, lapply(lists.matched.ls, function(d){
  c(Countries = length(unique(d$iso3c)),
    Groups = nrow(d),
    `Groups / Country` = round_any(nrow(d)/length(unique(d$iso3c)), .1))
})), stringsAsFactors = F)
match.stats.df$type <- names(lists.matched.ls)
match.stats.df$type[match.stats.df$type == "Murdock_Map"] <- "Murdock Map"
match.stats.df$type[match.stats.df$type == "ethnomap"] <- "Ethnologue"
match.stats.df$type[match.stats.df$type == "EPR2013"] <- "Ethnic Power Relations [EPR]"
match.stats.df$type[match.stats.df$type == "FRT2015"] <- "Francois, Trebbi \\& Rainer [FRT]"
match.stats.df <- match.stats.df[order(match.stats.df$type),]

# ... code sources
match.stats.df$source <- c("Survey", "Expert", "Survey","Expert","Expert","Expert","Expert","Expert","Census",
                           "Expert", "Expert", "Survey")

# ... Geocoded?
match.stats.df$geotype <- c("Point", "---", "Point", "Polygon (0/1)", "Polygon (0/1)","---","---","Polygon (0/1)",
                          "Raster (\\%)", "Polygon (0/1)", "---", "Raster (\\%)")
# ... Order table
tab.df <- match.stats.df[,c("type", "Countries", "Groups", "Groups...Country", "geotype", "source"   )]

# ... make printable table
col.heads1 <- c("List", "Countries", "Groups", "Groups", "Geo data", "Source type"   )
col.heads2 <- c("", "", "", "by country", "", ""   )


tab.string <- paste0("\\begin{table}[!htbp] \\centering ",
                     "\\caption{Matched ethnic group lists} ",
                     "\\label{tab.list.sum.tab} ",
                     "\\begin{tabular}{@{\\extracolsep{3pt}}l",paste(rep("D{.}{.}{-0}", 3), 
                                                                     collapse = " "),"ll } ",
                     "\\\\[-1.8ex]\\hline ",
                     "\\hline \\\\[-1.8ex] ",
                     "\\multicolumn{1}{c}{",paste(col.heads1, collapse = "} & \\multicolumn{1}{c}{"), "}\\\\ ",
                     "\\multicolumn{1}{c}{",paste(col.heads2, collapse = "} & \\multicolumn{1}{c}{"), "}\\\\ \\\\[-1.8ex] \\hline \\\\[-1.8ex]",
                     paste(apply(tab.df, 1, paste, collapse = " & "), collapse = " \\\\ \\\\[-1.8ex] \n "),
                     "\\\\  \\\\[-1.8ex] \\hline \\hline \\\\[-1.8ex] ",
                     "\\multicolumn{6}{l}{\\parbox[t]{0.95\\textwidth}{\\textit{Note:} ",
                     "Because of spelling inconsistencies, groups in the Afrobarometer, DHS, IPUMS, and SIDE lists include `duplicate' entries. 
                     Groups that span multiple countries are counted multiple times.",
                     "}} \\\\ ",
                     "\\end{tabular}  \\end{table} ")

# ... print
fileConn<-file(file.path(tab.path, "table1.tex"))
writeLines(tab.string, 
           fileConn)
close(fileConn)


