# FIGURE A1 #############

# Evalution of LEDA against previous links


# Which links?
link.eval.idx <- data.frame(do.call(rbind, lapply(comp.links.ls, function(c){
  c(a.type = unique(c$type),
    b.type = colnames(c)[colnames(c) %in% c("Murdock_Map", names(lists.org.ls))])
})), stringsAsFactors = F)


# Evaluate links

# (function) Calculate overlap by group
grp_overlap <- function(set.ls){
  comp.mat <- matrix(as.numeric(NA), nrow = length(set.ls), ncol = length(set.ls))
  for(i in c(1:length(set.ls))){
    for(j in 1:length(set.ls)){
      if(i == j){next}
      comp.mat[i,j] <- mean(set.ls[[i]] %in% set.ls[[j]])
    }
  }
  return(comp.mat)
}

# (function)
eval_links <- function(link.us, link.they, b.type){
  # Prep data
  link.us$group <- link.us$a.group
  link.us$b.group[is.na( link.us$b.group)] <- ""
  link.they[,b.type][is.na(link.they[,b.type])] <- ""
  
  # Unique obs of them
  id.vars <- c("iso3c", "group")
  if(!"iso3c" %in% colnames(link.us)){
    link.us$list.id <- link.us$a.list.id
    link.us <- join(link.us, lists.org.dict[,c("list.id", "iso3c")], 
                     type = "left", by = "list.id", link = "first")
  }
  
  set.comp <- uni.groups.they <- unique(link.they[,id.vars])
  
  # Set comparison
  
  # ... number of links
  
  # ... -- they
  uni.b.they <- unique(link.they[,c(id.vars, b.type)])
  set.comp <- join(set.comp, 
                   aggregate.data.frame(list(they.num = uni.b.they[,b.type]), 
                                        uni.b.they[,id.vars], FUN = function(x){length(x[!x %in% c("",NA)])}),
                   by = id.vars, type = "left")
  set.comp <- join(set.comp, 
                   aggregate.data.frame(list(they.link = uni.b.they[,b.type]), 
                                        uni.b.they[,id.vars], FUN = function(x){paste(x[!x %in% c(NA,"")], collapse = "|")}),
                   by = id.vars, type = "left")
  
  # ... -- us
  uni.b.us <- unique(link.us[,c(id.vars, "b.group")])
  set.comp <- join(set.comp, 
                   aggregate.data.frame(list(us.num = uni.b.us[,"b.group"]), 
                                        uni.b.us[,id.vars], FUN = function(x){length(x[!x %in% c("",NA)][order(x[!x %in% c(NA,"")])])}),
                   by = id.vars, type = "left")
  set.comp$us.num[is.na(set.comp$us.num)] <- 0
  set.comp <- join(set.comp, 
                   aggregate.data.frame(list(us.link = uni.b.us[,"b.group"]), 
                                        uni.b.us[,id.vars], FUN = function(x){paste(x[!x %in% c(NA,"")][order(x[!x %in% c(NA,"")])], collapse = "|")}),
                   by = id.vars, type = "left")
  
  # ... set overlaps
  set.they <- strsplit(set.comp$they.link, "|", fixed = T)
  set.us <- strsplit(set.comp$us.link, "|", fixed = T)
  set.comp <- cbind(set.comp, do.call(rbind, lapply(1:nrow(set.comp), function(m){
    c(theyinus = mean(set.they[[m]][!set.they[[m]] %in% c("",NA)] %in% set.us[[m]][!set.us[[m]] %in% c("",NA)]),
      usinthey = mean(set.us[[m]][!set.us[[m]] %in% c("",NA)] %in% set.they[[m]][!set.they[[m]] %in% c("",NA)]))
  })))
  
  # Retunr
  return(set.comp)
}


# Compute links across levels

# ... Compute links on all levels
link.ethno.level <- lapply(c(1:nrow(link.eval.idx)), function(c){
  print(link.eval.idx[c,])
  lapply(c(1:16), function(l){
    print(l)
    if("list.id" %in% colnames(comp.links.ls[[c]])){
      a.list.id <- unique(comp.links.ls[[c]]$list.id)
    } else {
      a.list.id <- lists.org.dict$list.id[lists.org.dict$type == link.eval.idx$a.type[c]]
    }
    leda.obj$link_set(lists.a = a.list.id,
                  lists.b = lists.org.dict$list.id[lists.org.dict$type == link.eval.idx$b.type[c]],
                  link.level = l,
                  by.country = ifelse(names(comp.links.ls)[c] == "nunnwant", T, T),
                  drop.a.threshold = 0,
                  drop.b.threshold = 0,
                  drop.ethno.id = F)
    
  })
})

# ... Compute evaluation
level.comp.df <- do.call(rbind, lapply(c(1:nrow(link.eval.idx)), function(c){ # )
  print(c)
  do.call(rbind, lapply(c(1:16), function(l){
    e.m <- eval_links(link.us =  link.ethno.level[[c]][[l]], 
                        link.they = comp.links.ls[[c]], 
                        b.type = link.eval.idx$b.type[c])
    e.m$level = l
    e.m$a.type = link.eval.idx$a.type[c]
    e.m$b.type = link.eval.idx$b.type[c]
    e.m$comp <- names(comp.links.ls)[c]
    e.m$us.link[is.na(e.m$us.link)] <- ""
    e.m$they.link[is.na(e.m$they.link)] <- ""
    e.m
  }))
}))

# ... Aggregate

# ... --- non-weighted
agg.comp.noweight.df <- aggregate.data.frame(level.comp.df[,c("they.num", "us.num" ,   "theyinus",   "usinthey")],
                                             level.comp.df[,c("level","a.type","b.type", "comp" )], FUN = mean, na.rm = T)



# ... --- weighted
weight.df <- do.call(rbind, lapply(unique(level.comp.df$comp), function(c){
  join(level.comp.df[level.comp.df$comp == c,],
       comp.links.ls[[c]][,c("iso3c","group","N")], type = "left", match = "first")
}))
agg.comp.weight.df <- aggregate.data.frame(list(theyinus = weight.df$theyinus * weight.df$N,
                                                usinthey = weight.df$usinthey * weight.df$N,
                                                they.N = ifelse(is.na(weight.df$theyinus), 0, weight.df$N),
                                                us.N = ifelse(is.na(weight.df$usinthey), 0, weight.df$N)),
                                           weight.df[,c("level","a.type","b.type", "comp" )], FUN = sum, na.rm = T)
agg.comp.weight.df$theyinus <- agg.comp.weight.df$theyinus / agg.comp.weight.df$they.N
agg.comp.weight.df$usinthey <- agg.comp.weight.df$usinthey / agg.comp.weight.df$us.N


# ... --- combined
comb.plot.df <- do.call(rbind, list(
  data.frame(weighting = "Population-weighted", type = "Prior link in new links", 
             value = agg.comp.weight.df$theyinus, agg.comp.weight.df[, c("level","comp")]),
  data.frame(weighting = "Population-weighted", type = "New link in prior links", 
             value = agg.comp.weight.df$usinthey, agg.comp.weight.df[, c("level","comp")]),
  data.frame(weighting = "No weighting", type = "Prior link in new links", 
             value = agg.comp.noweight.df$theyinus, agg.comp.noweight.df[, c("level","comp")]),
  data.frame(weighting = "No weighting", type = "New link in prior links", 
             value = agg.comp.noweight.df$usinthey, agg.comp.noweight.df[, c("level","comp")])
))

# Plot

comb.plot.df$group <- paste0(comb.plot.df$type, ".", comb.plot.df$weighting)        

g <- ggplot(comb.plot.df, aes(x = level, y = value, 
                              group = group, 
                              col = type, alpha = weighting, lty = weighting)) + 
  geom_line()+
  facet_wrap( ~ comp, nrow = 1, 
              labeller = labeller(comp = c(borm.afrobarometer.epr = "Afrobarometer - EPR",
                                           borm.dhs.epr = "DHS - EPR I",
                                           borm.epr.fearon = "Fearon - EPR",
                                           mullhunz = "DHS - EPR II",
                                           nunnwant = "Afrobarometer - Murdock"))) + 
  scale_alpha_discrete(range = c(1.,0.3)) +
  labs(color = "Comparison", lty = "Weighting", alpha = "Weighting") +
  ylab("Share of new (prior) links \n among prior (new) links") + 
  xlab("Language level of common parent used for linking") + ylim(0,1)

tiff(file.path(fig.path, "figurea1.tiff"), compression = "lzw", 
     width = 10, height = 3, unit = "in", res = 600)
print(g)
dev.off()

png(file.path(fig.path, "figurea1.png"),
     width = 10, height = 3, unit = "in", res = 600)
print(g)
dev.off()




