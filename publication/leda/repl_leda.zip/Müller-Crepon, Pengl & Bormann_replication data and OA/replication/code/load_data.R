# LOAD ALL DATA ###############




# From directory

## List of original group lists
lists.org.ls <- readRDS(file.path(data.path, "lists_org.rds"))

## List of matched group lists
##   Includes full info on the three codings rounds
lists.matched.ls <- readRDS(file.path(data.path, "lists_match.rds"))

# Clean

## Exclude lists & groups
lists.org.ls <- lapply(lists.org.ls, function(d){
  d[!d$list.id %in% drop.lists &
      !d$group %in% drop.groups, ]
})


## Previous matches from the literature
comp.links.ls <- readRDS("replication/data/lists_compare.rds")

## Group sizes to proportions


### Lists with group sizes types
size.types <- names(lists.org.ls)[unlist(lapply(lists.org.ls, function(d){
  "N" %in% colnames(d) & sum(!is.na(d$N) > 0)
}))]

### N to proportions
list.proportions <- lapply(size.types, function(t){
  d <- lists.org.ls[[t]]
  d$N <- as.numeric(d$N)
  if(mean(d$N, na.rm = T) < 1){
    joined <- lists.org.ls[[t]]
    joined$proportion <- joined$N
  } else {
    list.sum <- aggregate.data.frame(list(sum = d$N),
                                     d[,c("list.id","iso3c", "cowcode")],
                                     FUN = sum, na.rm = T)
    joined <- join(d,list.sum, type = "left", by =  c("list.id","iso3c", "cowcode"))
    joined$proportion <- joined$N / joined$sum
  }
  joined
})
names(list.proportions) <- size.types


# From LEDA Package

## Make ldea object
leda.obj <- LEDA$new()

## Extract dictionary
match.dict <- leda.obj$.__enclos_env__$private$link.dict
lists.org.dict <- leda.obj$.__enclos_env__$private$list.dict



