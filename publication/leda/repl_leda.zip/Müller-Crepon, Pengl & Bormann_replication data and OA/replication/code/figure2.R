
# FIGURE 2 ###############


# DETAILED GRAPH SETUP

# ... Ethnologue nodes
ethn.nodes <- data.frame(name = c("Root", "Niger-Congo", "Kwa", "Akan1", "Abron", "Akan2",
                                  "Ahafo", "Asante","Fante"),
                         label = c("Root", "Niger-Congo", "", "Akan", "Abron", "Akan",
                                  "Ahafo", "Asante","Fante"),
                         level.org = c(0, 1, 4,9, 15, 15, 16, 16, 16 ),
                         x = c(0,0,0,0,-5,5,0,5,10),
                         y = c(4.5,4,4,3,2,2,1,1,1),
                         color = "black",
                         stringsAsFactors = F)
rownames(ethn.nodes) <- ethn.nodes$name

ethn.ties <- do.call(rbind, list(c("Root", "Niger-Congo"),
                                 c("Niger-Congo", "Akan1"),
                                 c("Akan1", "Abron"),
                                 c("Akan1", "Akan2"),
                                 c("Akan2", "Ahafo"),
                                 c("Akan2", "Asante"),
                                 c("Akan2","Fante")))

# ... Matched nodes
match.nodes <- data.frame(name = c("Asante/Akan (DHS)", "Asante (EPR)", "Akan (Afrobarometer)", "Brong (Murdock)"),
                          label = c("Asante/Akan \n (DHS)", "Asante\n(EPR)", "Akan\n(Afrobarometer)", "Brong\n(Murdock)"),
                          level.org = c(9,16,9,15),
                          x = rep(12.5, 4),
                          y = c(3.3, 1.8,2.8,2.3),
                          color = "red",
                          stringsAsFactors = F)
rownames(match.nodes) <- match.nodes$name
match.ethn <- do.call(rbind, list(c("Asante/Akan (DHS)", "Akan1"),
                                  c("Asante (EPR)", "Asante"),
                                  c("Akan (Afrobarometer)", "Akan1"),
                                  c("Brong (Murdock)", "Abron")))


# ... levels
level.df <- data.frame(unique(cbind(level.org =ethn.nodes$level.org, y =  ethn.nodes$y)),
                       stringsAsFactors = F)
level.df$x <- -10
level.df$label <- as.character(ifelse(level.df$level.org < 15, 
                                      paste0("Level: ", level.df$level.org),
                                      ifelse(level.df$level.org == 15, "Language",
                                             "Dialect")))
level.df$name <- paste0("Level: ", level.df$level.org)
rownames(level.df) <- level.df$name
level.df$color <- "black"
level.df <- level.df[!level.df$level.org %in% c(4),]

# PLOTS

# Graph 1: Language tree alone (not in paper)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ethn.ties, color = "grey"),
                                     cbind(match.ethn, color = NA)),
                               vertices = smartbind(smartbind(ethn.nodes, match.nodes), level.df), 
                               directed = F)
V(graph)$color[V(graph)$color == "red"] <- "transparent"

# ... plot
# png(file.path(fig.path, "match_ex_1.png"), width = 4, height = 4, units = "in", res = 300)
# par(mar = c(0,0,0,0))
# plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
#      vertex.label = V(graph)$label, vertex.shape="rectangle", 
#      vertex.size=25, vertex.color = "white", vertex.frame.color = "white",
#      vertex.size = 5, vertex.label.color = V(graph)$color, xlim = c(-1, 1.1))
# text(x = rep(-1, 2), y = c(-.13, .45), label = rep("...", 2))
# dev.off()

# Graph 2: Language tree with matchings

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ethn.ties, color = "grey"),
                                     cbind(match.ethn, color = "red")),
                               vertices = smartbind(smartbind(ethn.nodes, match.nodes), level.df), 
                               directed = F)


# ... plot
tiff(file.path(fig.path, "figure2a.tiff"), compression = "lzw", 
     width = 4, height = 4, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="rectangle", 
     vertex.size=25, vertex.color = "white", vertex.frame.color = "white",
     vertex.size = 5, vertex.label.color = V(graph)$color, xlim = c(-1, 1.1))
text(x = rep(-1, 2), y = c(-.13, .45), label = rep("...", 2))
dev.off()

png(file.path(fig.path, "figure2a.png"), 
     width = 4, height = 4, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="rectangle", 
     vertex.size=25, vertex.color = "white", vertex.frame.color = "white",
     vertex.size = 5, vertex.label.color = V(graph)$color, xlim = c(-1, 1.1))
text(x = rep(-1, 2), y = c(-.13, .45), label = rep("...", 2))
dev.off()


# Graph 3: Matchings at Dialect level 

# ... prepare graph
ties <- do.call(rbind, list(c("Asante (EPR)", "Akan (Afrobarometer)"),
                            c("Asante (EPR)", "Asante/Akan (DHS)"),
                            c("Asante/Akan (DHS)", "Akan (Afrobarometer)"),
                            c("Asante/Akan (DHS)", "Brong (Murdock)"),
                            c("Akan (Afrobarometer)", "Brong (Murdock)")))
ties <- rbind(ties, 
              cbind(ties[,2], ties[,1]))
nodes <- match.nodes
nodes$x <- c(0,1,0, 1)
nodes$y <- c(1,1,0,0)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ties, color = "red")),
                               vertices = nodes, 
                               directed = T)


# ... plot
tiff(file.path(fig.path, "figure2b.tiff"), compression = "lzw", 
     width = 2, height = 2, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="square", 
     vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
     vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
dev.off()

png(file.path(fig.path, "figure2b.png"), 
     width = 2, height = 2, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="square", 
     vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
     vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
dev.off()


# Graph 4: Matchings at Level 9 (not in paper)
# ... prepare graph
ties <- do.call(rbind, list(c("Asante (EPR)", "Akan (Afrobarometer)"),
                            c("Asante (EPR)", "Asante/Akan (DHS)"),
                            c("Asante (EPR)", "Brong (Murdock)"),
                            c("Asante/Akan (DHS)", "Akan (Afrobarometer)"),
                            c("Asante/Akan (DHS)", "Brong (Murdock)"),
                            c("Akan (Afrobarometer)", "Brong (Murdock)")))
ties <- rbind(ties, 
              cbind(ties[,2], ties[,1]))
nodes <- match.nodes
nodes$x <- c(0,1,0, 1)
nodes$y <- c(1,1,0,0)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ties, color = "red")),
                               vertices = nodes, 
                               directed = T)


# ... plot
# png(file.path(fig.path, "match_ex_4.png"), width = 2, height = 2, units = "in", res = 300)
# par(mar = c(0,0,0,0))
# plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
#      vertex.label = V(graph)$label, vertex.shape="square", 
#      vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
#      vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
# dev.off()


# Graph 5: Matchings with min threshold: 100% Nodes of B in A (not in paper)
# ... prepare graph
ties <- do.call(rbind, list(c("Asante (EPR)", "Akan (Afrobarometer)"),
                            c("Asante (EPR)", "Asante/Akan (DHS)"),
                            c("Asante/Akan (DHS)", "Akan (Afrobarometer)"),
                            c("Akan (Afrobarometer)", "Asante/Akan (DHS)"),
                            c("Brong (Murdock)", "Asante/Akan (DHS)"),
                            c("Brong (Murdock)", "Akan (Afrobarometer)")))
ties <- cbind(ties[,2], ties[,1])
nodes <- match.nodes
nodes$x <- c(0,1,0, 1)
nodes$y <- c(1,1,0,0)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ties, color = "red")),
                               vertices = nodes, 
                               directed = T)


# # ... plot
# png(file.path(fig.path, "match_ex_5.png"), width = 2, height = 2, units = "in", res = 300)
# par(mar = c(0,0,0,0))
# plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
#      vertex.label = V(graph)$label, vertex.shape="square", 
#      vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
#      vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
# dev.off()



# Graph 6: Matchings with min threshold: 100% Nodes of B
# ... prepare graph
ties <- do.call(rbind, list(c("Asante (EPR)", "Akan (Afrobarometer)"),
                            c("Asante (EPR)", "Asante/Akan (DHS)"),
                            c("Asante/Akan (DHS)", "Akan (Afrobarometer)"),
                            c("Akan (Afrobarometer)", "Asante/Akan (DHS)"),
                            c("Brong (Murdock)", "Asante/Akan (DHS)"),
                            c("Brong (Murdock)", "Akan (Afrobarometer)")))
nodes <- match.nodes
nodes$x <- c(0,1,0, 1)
nodes$y <- c(1,1,0,0)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ties, color = "red")),
                               vertices = nodes, 
                               directed = T)


# ... plot
tiff(file.path(fig.path, "figure2c.tiff"), compression = "lzw", 
     width = 2, height = 2, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="square",
     vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
     vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
dev.off()

png(file.path(fig.path, "figure2c.png"), 
     width = 2, height = 2, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="square",
     vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
     vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
dev.off()




# Graph 7: Matchings with min threshold: 100% Nodes of A and B (not in paper)
# ... prepare graph
ties <- do.call(rbind, list(c("Asante/Akan (DHS)", "Akan (Afrobarometer)"),
                            c("Akan (Afrobarometer)", "Asante/Akan (DHS)")))
nodes <- match.nodes
nodes$x <- c(0,1,0, 1)
nodes$y <- c(1,1,0,0)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ties, color = "red")),
                               vertices = nodes, 
                               directed = T)


# ... plot
# png(file.path(fig.path, "match_ex_7.png"), width = 2, height = 2, units = "in", res = 300)
# par(mar = c(0,0,0,0))
# plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
#      vertex.label = V(graph)$label, vertex.shape="square", 
#      vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
#      # vertex.label.family=rep('mono',times = length(V(graph))), 
#      # asp = .666 ,
#      vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5)
# dev.off()


# Graph 8: Linguistic distance

## Setup ties
ties <- do.call(rbind, list(c("Asante (EPR)", "Akan (Afrobarometer)"),
                            c("Asante (EPR)", "Asante/Akan (DHS)"),
                            c("Asante (EPR)", "Brong (Murdock)"),
                            c("Asante/Akan (DHS)", "Akan (Afrobarometer)"),
                            c("Asante/Akan (DHS)", "Brong (Murdock)"),
                            c("Akan (Afrobarometer)", "Brong (Murdock)")))
ties <- data.frame(rbind(ties, 
              cbind(ties[,2], ties[,1])),
              stringsAsFactors = F)

ties$weight <- c(0,
                 0,
                 1-(18/31)^.5, 
                 0, 
                 mean(c(0, rep(1-(18/31)^.5,3))),
                 mean(c(0, rep(1-(18/31)^.5,3))),
                 mean(c(1-(18/31)^.5, 1-(30/32)^.5, 0,  1-(30/32)^.5)),
                 mean(c(1-(18/31)^.5, 1-(30/32)^.5, 0,  1-(30/32)^.5)),
                 1-(18/31)^.5, 
                 0,
                 mean(c(0, rep(1-(18/31)^.5, 0))),
                 mean(c(0, rep(1-(18/31)^.5, 0))))

nodes <- match.nodes
nodes$x <- c(0,1,0, 1)
nodes$y <- c(1,1,0,0)

# ... make graph
graph <- graph_from_data_frame(rbind(cbind(ties, 
                                           color = rgb(1, ties$weight * 2,  ties$weight * 2))),
                               vertices = nodes, 
                               directed = T)


# ... plot
tiff(file.path(fig.path, "figure2d.tiff"), compression = "lzw", 
     width = 2, height = 2, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="square", 
     vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
     # vertex.label.family=rep('mono',times = length(V(graph))), 
     # asp = .666 ,
     vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5, edge.curved=.1)

# ... --- color legend
B <- matrix(rgb(1, seq(0, 1, length.out = 100), seq(0, 1, length.out = 100)), nrow = 1, ncol = 100)
B <-  matrix(seq(0,1, length.out = 100), nrow = 100, ncol = 1)

add.image(xpos = 0, ypos = -1.3, B, adj.x = 0.5, adj.y = 0.5, 
          image.width = .01, image.height = .75, col = rgb(1, seq(0, 1, length.out = 100), seq(0, 1, length.out = 100)))

text(x = 0, y = -1.4, label = "linguistic distance", col = "black", cex = .5)
text(x = -1.05, y = -1.4, label = "0", col = "black", cex = .5)
text(x = 1.05, y = -1.4, label = ".4", col = "black", cex = .5)
dev.off()



png(file.path(fig.path, "figure2d.png"), 
     width = 2, height = 2, units = "in", res = 600)
par(mar = c(0,0,0,0))
plot(graph, arrow.size = 0, vertex.label.cex = 0.6,
     vertex.label = V(graph)$label, vertex.shape="square", 
     vertex.size=75, vertex.color = "white", vertex.frame.color = "white",
     # vertex.label.family=rep('mono',times = length(V(graph))), 
     # asp = .666 ,
     vertex.size = 5, vertex.label.color = V(graph)$color, edge.arrow.size = .5, edge.curved=.1)

# ... --- color legend
B <- matrix(rgb(1, seq(0, 1, length.out = 100), seq(0, 1, length.out = 100)), nrow = 1, ncol = 100)
B <-  matrix(seq(0,1, length.out = 100), nrow = 100, ncol = 1)

add.image(xpos = 0, ypos = -1.3, B, adj.x = 0.5, adj.y = 0.5, 
          image.width = .01, image.height = .75, col = rgb(1, seq(0, 1, length.out = 100), seq(0, 1, length.out = 100)))

text(x = 0, y = -1.4, label = "linguistic distance", col = "black", cex = .5)
text(x = -1.05, y = -1.4, label = "0", col = "black", cex = .5)
text(x = 1.05, y = -1.4, label = ".4", col = "black", cex = .5)
dev.off()






