# TABLE A1 ####################

# Illustrative table to be filled in by coder

# ... prepare data
ex.code.table <- lists.matched.ls$DHS[lists.matched.ls$DHS$iso3c == "NGA",]
ex.code.table$pop.share <- paste0("<.01")
ex.code.table <- ex.code.table[1:5,c("group","pop.share", "auto_match_org" , "auto_match_alt" ,
                                     "auto_match_dial" , "auto_match_foreign")]
ex.code.table[,c(6)] <- gsub("Org: ", "", ex.code.table[,c(6)], fixed = T)
ex.code.table[,"match_prev"] <- ""


# ... column headers
col.head.1 <- c("Group", "Share", "Match:", "Match:", "Match:", "Match:", "Match:")
col.head.2 <- c("", "", "direct", "alt. name", "dialect", "foreign",
                "previous")
col.head.1[length(col.head.1)] <- paste(col.head.1[length(col.head.1)], "\\\\ \n",
                                        paste(col.head.2, collapse = "&"))

# ... print
fileConn<-file(file.path(tab.path, "tablea1.tex"))
writeLines(
  gsub("ccccccc", "lllllll",stargazer(ex.code.table,
                                      title="Ethnic groups from DHS in Nigeria: Excerpt",
                                      covariate.labels = col.head.1,
                                      notes.align = "l",label=paste0("ex.code.table"),
                                      digits = 2, summary = F, rownames = F,digit.separate = 0,
                                      type  = "latex", column.sep.width = "0pt",
                                      notes = paste0("\\parbox[t]{", .95,"\\textwidth}{\\textit{Notes:} 
                                                     Column 'Match: previous' is automatically updated as matching proceeds.}"))), 
  fileConn)
close(fileConn)
