# FIGURE 3


# Figure that plots link rates between all data sets
# Extended version also shows rates by country



# Matched to raw ethnologue #####

## Which groups are matched?
groups.df <- do.call(smartbind, lapply(lists.org.ls, function(d){
  if("N" %in% colnames(d) & all(d$type != "AMAR")){
    d$N <- as.numeric(d$N)
  } else {
    d$N <- as.numeric(1)
  }
  d
}))
all.groups.df <- groups.df <- join(groups.df, 
                                   cbind(unique(match.dict[,c("group", "list.id")]), matched = 1),
                                   type = "left", by = c("group","list.id"))
groups.df$matched[is.na(groups.df$matched)] <- 0

## Drop groups which are not ethnic groups
groups.df$drop <- 0
groups.df$drop[groups.df$matched == 0] <- ifelse(rowSums(do.call(cbind,lapply(drop.groups, function(d){
  grepl(d,groups.df$group[groups.df$matched == 0], ignore.case = T)
}))) > 0, 1 , 0)
groups.df <- groups.df[groups.df$drop == 0,]


## Weighted by population
cow.list.prop <- aggregate.data.frame(list(matched = groups.df$matched * groups.df$N,
                                           N = groups.df$N),
                                      groups.df[,c("list.id", "cowcode", "iso3c", "type")],
                                      FUN = sum)
cow.list.prop$matched <- cow.list.prop$matched / cow.list.prop$N



# All matches ############


# Matchings to do
match.types <- names(lists.org.ls)
match.types <- gsub(" ", "_", match.types)
names(match.types) <- match.types

# Compute matchings

## Make Cluster
cl <- makeCluster(getOption("cl.cores", ncore), outfile = "error.txt") 
registerDoParallel(cl)

## Compute
match.all2all.ls <- foreach(a = match.types, .packages = c("LEDA")) %dopar% {
  lapply(match.types,function(b){
    if(a == b){return(NULL)}
    print(paste("Match ",a, " to ", b))
    leda.obj$link_set(lists.a = list(type = a),
                  lists.b = list(type = b),
                  link.level = "dialect",
                  by.country = T,
                  drop.a.threshold = 0,
                  drop.b.threshold = 0,
                  drop.ethno.id = T)
  })
}
names(match.all2all.ls) <- match.types

## Stop cluster
stopCluster(cl)
rm(cl)


# Compute matched population proportions
popprop.match.df <- do.call(rbind, lapply(match.types, function(a){
  # print(a)
  all.a.groups <- unique(match.dict[match.dict$list.id %in% lists.org.dict$list.id[lists.org.dict$type == a],
                                    c("group", "list.id")])
  all.a.groups <- all.a.groups[!all.a.groups$group %in% drop.groups,]
  all.a.groups <- join(all.a.groups, lists.org.dict[, c( "list.id", "iso3c")], 
                       by = "list.id", type = "left", match = "first")
  if(a %in% gsub(" ", "_", names(list.proportions))){
    all.a.groups <- join(all.a.groups, list.proportions[[gsub("_"," ", a)]][, c("list.id","group","proportion")], 
                         by = c("list.id","group"), type = "left", match = "first")
  } else {
    all.a.groups$proportion <- 1
  }
  colnames(all.a.groups) <- paste0("a.",colnames(all.a.groups))
  
  do.call(rbind, lapply(match.types, function(b){
    # print(b)
    if(a == b){return(NULL)}
    # ... group of B
    b.groups <- unique(match.dict[match.dict$list.id %in% lists.org.dict$list.id[lists.org.dict$type == b],
                                  c("group", "list.id")])
    b.groups <- b.groups[!b.groups$group %in% drop.groups,]
    b.groups <- join(b.groups, lists.org.dict[, c( "list.id", "iso3c")], 
                     by = "list.id", type = "left", match = "first")
    # ... add B's population size
    if(b %in% names(list.proportions)){
      b.groups <- join(b.groups, list.proportions[[b]][, c("list.id","group","proportion")], 
                       by = c("list.id","group"), type = "left", match = "first")
    } else {
      b.groups$proportion <- 1
    }
    colnames(b.groups) <- paste0("b.",colnames(b.groups))
    
    
    # ... subset to overlapping set of countries
    b.groups <- b.groups[b.groups$b.iso3c %in% all.a.groups$a.iso3c,]
    a.groups <- all.a.groups[all.a.groups$a.iso3c %in% b.groups$b.iso3c,]
    
    # ... adjust A's proportions to add to 1 by list.id
    a.props <- aggregate.data.frame(list(a.total = a.groups$a.proportion),
                                    a.groups[,c("a.list.id", "a.iso3c")], FUN = sum)
    a.groups <- join(a.groups, a.props, type = "left", by = c("a.list.id", "a.iso3c"))
    a.groups$a.proportion <- a.groups$a.proportion / a.groups$a.total
    
    # ... adjust B's proportions to add to 1 by list.id
    b.props <- aggregate.data.frame(list(b.total = b.groups$b.proportion),
                                    b.groups[,c("b.list.id", "b.iso3c")], FUN = sum)
    b.groups <- join(b.groups, b.props, type = "left", by = c("b.list.id", "b.iso3c"))
    b.groups$b.proportion <- b.groups$b.proportion / b.groups$b.total
    
    # ... match A--B
    this.match <- match.all2all.ls[[a]][[b]]
    this.match$ethno.id <- NULL
    
    # ... delete missing matches B
    this.match <- this.match[!is.na(this.match$b.group),]
    this.match <- unique(this.match)
    
    
    # ... add a and b.proportion
    this.match <- join(this.match, 
                       a.groups[,c("a.list.id","a.group","a.proportion")], 
                       type = "left", by = c("a.group", "a.list.id"))
    this.match <- join(this.match, 
                       b.groups[,c("b.list.id","b.group","b.proportion")], 
                       type = "left", by = c("b.group", "b.list.id"))

    # ... finalize
    data.frame(a.type = gsub("_", " ", a), b.type = gsub("_", " ", b), 
               prop = c(nrow(unique(this.match[, c("a.group", "a.list.id")])) / nrow(a.groups),
                        nrow(unique(this.match[, c("b.group", "b.list.id")])) / nrow(b.groups)),
               prop.pop = c(sum(unique(this.match[, c("a.group", "a.list.id", "a.proportion")])$a.proportion, na.rm = T) / 
                              sum(a.groups$a.proportion, na.rm = T),
                            sum(unique(this.match[, c("b.group", "b.list.id", "b.proportion")])$b.proportion, na.rm = T) / 
                              sum(b.groups$b.proportion, na.rm = T)),
               group = c("A (row)", "B (column)"), stringsAsFactors = F)
  }))
}))
popprop.match.pop <- popprop.match.df


# Plot: As colored raster (pop weighted)


## prepare data
plot.df <- popprop.match.pop[grepl("A", popprop.match.pop$group),]
plot.df <- plot.df[plot.df$a.type != "WLMS" & plot.df$b.type != "WLMS",]
plot.df$x <- as.numeric(factor(plot.df$b.type))
plot.df$y <- as.numeric(factor(plot.df$a.type, 
                               levels = rev(names(table(plot.df$a.type)))))

## compute average per list
avg.df <- aggregate.data.frame(list(prop.pop = plot.df$prop.pop),
                               list(a.type = plot.df$a.type), FUN = mean, na.rm = T)
avg.df$b.type = "List average"
avg.df$x <- -.5
avg.df$y <- as.numeric(factor(avg.df$a.type, 
                              levels = rev(names(table(avg.df$a.type)))))

## extra match to ethnologue
ethno.df <- cow.list.prop
ethno.df <- aggregate.data.frame(list(prop.pop = ethno.df$matched),
                                 list(a.type = ethno.df$type), FUN = mean, na.rm = T)
ethno.df <- ethno.df[!ethno.df$a.type %in% c("WLMS"),]
ethno.df$b.type = "Ethnologue"
ethno.df$x <- -2
ethno.df$y <- as.numeric(factor(ethno.df$a.type, 
                                levels = rev(names(table(plot.df$a.type)))))



## plot with number in plot

g <- ggplot(plot.df, 
            aes(x = x, y = y, z = prop.pop)) + 
  geom_raster(aes(fill = prop.pop, size = 1), hjust = 0, vjust = 0) + 
  geom_raster(data = avg.df, aes(fill = prop.pop, size = 1), hjust = 0, vjust = 0) + 
  geom_raster(data = ethno.df, aes(fill = prop.pop, size = 1), hjust = 0, vjust = 0) + 
  scale_fill_viridis(option = "inferno", direction = -1,
                     guide = guide_colorbar(title = "Population share matched",
                                            direction = "horizontal",
                                            barwidth = 7, barheight = .5),
                     limits = c(.4, 1)) +
  geom_text(aes(x = x-.5, y = y-.5, label = as.character(signif(prop.pop, digits = 2))), color = "white",
            vjust = .5, hjust = .5) +
  geom_text(data = plot.df[plot.df$prop.pop < .5,],
            aes(x = x-.5, y = y-.5, label = as.character(signif(prop.pop, digits = 2))), color = "black",
            vjust = .5, hjust = .5) +
  geom_text(data = avg.df, aes(x = x-.5, y = y-.5, label = as.character(signif(prop.pop, digits = 2))), color = "white",
            vjust = .5, hjust = .5) +
  geom_text(data = ethno.df, aes(x = x-.5, y = y-.5, label = as.character(signif(prop.pop, digits = 2))), color = "white",
            vjust = .5, hjust = .5) +
  theme(axis.text.x = element_text(angle=90, hjust = 1, vjust = .5),
        legend.position="top") +
  scale_y_continuous(breaks = unique(plot.df$y) - .5,
                     labels = unique(plot.df$a.type)) +
  scale_x_continuous(breaks = c(-2, -.5, unique(plot.df$x)) - .5,
                     labels = c("Ethnologue","List average", unique(plot.df$b.type))) +
  ylab(NULL) + xlab(NULL) +
  NULL

tiff(file.path(fig.path, "figure3.tiff"), compression = "lzw", 
     width = 7, height = 5, unit = "in", res = 300)
print(g)
dev.off()

png(file.path(fig.path, "figure3.png"), 
     width = 7, height = 5, unit = "in", res = 300)
print(g)
dev.off()



# Plot: As colored raster (unweighted)


## prepare data
plot.df <- popprop.match.pop[grepl("A", popprop.match.pop$group),]
plot.df <- plot.df[plot.df$a.type != "WLMS" & plot.df$b.type != "WLMS",]
plot.df$x <- as.numeric(factor(plot.df$b.type))
plot.df$y <- as.numeric(factor(plot.df$a.type, 
                               levels = rev(names(table(plot.df$a.type)))))

## compute average per list
avg.df <- aggregate.data.frame(list(prop = plot.df$prop),
                               list(a.type = plot.df$a.type), FUN = mean, na.rm = T)
avg.df$b.type = "List average"
avg.df$x <- -.5
avg.df$y <- as.numeric(factor(avg.df$a.type, 
                              levels = rev(names(table(avg.df$a.type)))))

## extra match to ethnologue
ethno.df <- cow.list.prop
ethno.df <- aggregate.data.frame(list(prop = ethno.df$matched),
                                 list(a.type = ethno.df$type), FUN = mean, na.rm = T)
ethno.df <- ethno.df[!ethno.df$a.type %in% c("WLMS"),]
ethno.df$b.type = "Ethnologue"
ethno.df$x <- -2
ethno.df$y <- as.numeric(factor(ethno.df$a.type, 
                                levels = rev(names(table(plot.df$a.type)))))



## plot with number in plot

g <- ggplot(plot.df, 
            aes(x = x, y = y, z = prop)) + 
  geom_raster(aes(fill = prop, size = 1), hjust = 0, vjust = 0) + 
  geom_raster(data = avg.df, aes(fill = prop, size = 1), hjust = 0, vjust = 0) + 
  geom_raster(data = ethno.df, aes(fill = prop, size = 1), hjust = 0, vjust = 0) + 
  scale_fill_viridis(option = "inferno", direction = -1,
                     guide = guide_colorbar(title = "Share of groups matched (unweighted)",
                                            direction = "horizontal",
                                            barwidth = 7, barheight = .5),
                     limits = c(.25, 1)) +
  geom_text(aes(x = x-.5, y = y-.5, label = as.character(signif(prop, digits = 2))), color = "white",
            vjust = .5, hjust = .5) +
  geom_text(data = plot.df[plot.df$prop < .4,],
            aes(x = x-.5, y = y-.5, label = as.character(signif(prop, digits = 2))), color = "black",
            vjust = .5, hjust = .5) +
  geom_text(data = avg.df, aes(x = x-.5, y = y-.5, label = as.character(signif(prop, digits = 2))), color = "white",
            vjust = .5, hjust = .5) +
  geom_text(data = ethno.df, aes(x = x-.5, y = y-.5, label = as.character(signif(prop, digits = 2))), color = "white",
            vjust = .5, hjust = .5) +
  theme(axis.text.x = element_text(angle=90, hjust = 1, vjust = .5),
        legend.position="top") +
  scale_y_continuous(breaks = unique(plot.df$y) - .5,
                     labels = unique(plot.df$a.type)) +
  scale_x_continuous(breaks = c(-2, -.5, unique(plot.df$x)) - .5,
                     labels = c("Ethnologue","List average", unique(plot.df$b.type))) +
  ylab(NULL) + xlab(NULL) +
  NULL

tiff(file.path(fig.path, "figurea2.tiff"), compression = "lzw", 
     width = 7, height = 5, unit = "in", res = 600)
print(g)
dev.off()

png(file.path(fig.path, "figurea2.png"), 
     width = 7, height = 5, unit = "in", res = 600)
print(g)
dev.off()




# Table by country #########


## Compute matched population proportions by country
cowprop.match.df <- do.call(rbind, lapply(match.types, function(a){
  # print(a)
  all.a.groups <- unique(match.dict[match.dict$list.id %in% lists.org.dict$list.id[lists.org.dict$type == a] &
                                      !match.dict$list.id %in% drop.lists,
                                    c("group", "list.id")])
  all.a.groups <- all.a.groups[!all.a.groups$group %in% drop.groups,]
  all.a.groups <- join(all.a.groups, lists.org.dict[, c( "list.id", "iso3c")], 
                       by = "list.id", type = "left", match = "first")
  if(a %in% gsub(" ", "_", names(list.proportions))){
    all.a.groups <- join(all.a.groups, list.proportions[[gsub("_"," ", a)]][, c("list.id","group","proportion")], 
                         by = c("list.id","group"), type = "left", match = "first")
  } else {
    all.a.groups$proportion <- 1
  }
  colnames(all.a.groups) <- paste0("a.",colnames(all.a.groups))
  
  do.call(rbind, lapply(match.types, function(b){
    # print(b)
    if(a == b){return(NULL)}
    # ... group of B
    b.groups <- unique(match.dict[match.dict$list.id %in% lists.org.dict$list.id[lists.org.dict$type == b] &
                                  !  match.dict$list.id %in% drop.lists,
                                  c("group", "list.id")])
    b.groups <- b.groups[!b.groups$group %in% drop.groups,]
    b.groups <- join(b.groups, lists.org.dict[, c( "list.id", "iso3c")], 
                     by = "list.id", type = "left", match = "first")
    # ... add B's population size
    if(b %in% names(list.proportions)){
      b.groups <- join(b.groups, list.proportions[[b]][, c("list.id","group","proportion")], 
                       by = c("list.id","group"), type = "left", match = "first")
    } else {
      b.groups$proportion <- 1
    }
    colnames(b.groups) <- paste0("b.",colnames(b.groups))
    
    
    # ... subset to overlapping set of countries
    b.groups <- b.groups[b.groups$b.iso3c %in% all.a.groups$a.iso3c,]
    a.groups <- all.a.groups[all.a.groups$a.iso3c %in% b.groups$b.iso3c,]
    
    # ... adjust A's proportions to add to 1 by list.id
    a.props <- aggregate.data.frame(list(a.total = a.groups$a.proportion),
                                    a.groups[,c("a.list.id", "a.iso3c")], FUN = sum)
    a.groups <- join(a.groups, a.props, type = "left", by = c("a.list.id", "a.iso3c"))
    a.groups$a.proportion <- a.groups$a.proportion / a.groups$a.total
    
    # ... adjust B's proportions to add to 1 by list.id
    b.props <- aggregate.data.frame(list(b.total = b.groups$b.proportion),
                                    b.groups[,c("b.list.id", "b.iso3c")], FUN = sum)
    b.groups <- join(b.groups, b.props, type = "left", by = c("b.list.id", "b.iso3c"))
    b.groups$b.proportion <- b.groups$b.proportion / b.groups$b.total
    
    # ... match A--B
    this.match <- match.all2all.ls[[a]][[b]]
    this.match$ethno.id <- NULL
    
    # ... delete missing matches B
    this.match <- this.match[!is.na(this.match$b.group),]
    this.match <- unique(this.match)
    
    
    # ... add a and b.proportion
    this.match <- join(this.match, 
                       a.groups[,c("a.list.id","a.group","a.proportion")], 
                       type = "left", by = c("a.group", "a.list.id"))
    this.match <- join(this.match, 
                       b.groups[,c("b.list.id","b.group","b.proportion")], 
                       type = "left", by = c("b.group", "b.list.id"))
    
    # ... finalize
    do.call(rbind, lapply(unique(this.match$iso3c), function(i){
      sub.a.groups <- a.groups[a.groups$a.iso3c == i,]
      sub.b.groups <- b.groups[b.groups$b.iso3c == i,]
      sub.match <- this.match[this.match$iso3c == i, , drop = F]
      data.frame(iso3c = i,
                 a.type = gsub("_", " ", a), b.type = gsub("_", " ", b), 
                 prop = c(nrow(unique(sub.match[, c("a.group", "a.list.id")])) / nrow(sub.a.groups),
                          nrow(unique(sub.match[, c("b.group", "b.list.id")])) / nrow(sub.b.groups)),
                 prop.pop = c(sum(unique(sub.match[, c("a.group", "a.list.id", "a.proportion")])$a.proportion, na.rm = T) / 
                                sum(sub.a.groups$a.proportion, na.rm = T),
                              sum(unique(sub.match[, c("b.group", "b.list.id", "b.proportion")])$b.proportion, na.rm = T) / 
                                sum(sub.b.groups$b.proportion, na.rm = T)),
                 group = c("A (row)", "B (column)"), stringsAsFactors = F)
    }))
    
  }))
}))


## prepare data

### compute average per list
avg.df <- aggregate.data.frame(list(prop.pop = cowprop.match.df$prop.pop),
                                     cowprop.match.df[, c("iso3c", "a.type")], FUN = mean, na.rm = T)

### Drop WLMS
avg.df <- avg.df[avg.df$a.type != "WLMS",]

### Sort
avg.df <- avg.df[order(avg.df$iso3c, avg.df$a.type),]

### Reshape
table.df <- join_all(lapply(sort(unique(avg.df$a.type)), function(t){
  res <- avg.df[avg.df$a.type == t , c("iso3c", "prop.pop")]
  colnames(res)[2] <- t
  res[, t] <- res[, t] * 100
  res
}), type = "left", by = "iso3c")

### Rename 
colnames(table.df)[1] <- "Country"

### Save
fileConn<-file(file.path(tab.path,"tablea4.tex"))
writeLines(stargazer(table.df,
                     title="Linkage rates by datset and country (in percent, population weighted)",
                     summary=F, digits = 0,align =T, rownames = F,
                     label="matchratebycow",
                     column.sep.width = "-5pt"), 
           fileConn)
close(fileConn)
