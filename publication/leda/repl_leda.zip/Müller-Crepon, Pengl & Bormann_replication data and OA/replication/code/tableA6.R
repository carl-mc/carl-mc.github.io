# TABLE A6 ########################


# List of unmatched groups

# Get all unmatched groups
unmatched.df <- lapply(lists.matched.ls, function(d){
  if("comment_final" %in% colnames(d)){
    d[d$match %in% c("", NA) & !d$group %in% drop.groups,
      c("group","iso3c", "comment")]
  } else {
    d[d$match %in% c("", NA) & !d$group %in% drop.groups,
      c("group","iso3c", "comment")]
  }
})
unmatched.df <- data.frame(do.call(rbind, unmatched.df),
                           type = rep(names(unmatched.df), unlist(lapply(unmatched.df, nrow))),
                           stringsAsFactors = F)
for(d in drop.groups){
  unmatched.df <- unmatched.df[!grepl(d, unmatched.df$group, ignore.case = T),]
}
unmatched.df$cowcode <- countrycode(unmatched.df$group, origin = "country.name", destination = "cown",
                                    warn = F)
unmatched.df <- unmatched.df[is.na(unmatched.df$cowcode),]
unmatched.df$cowcode <- NULL

# ... collapse 
unmatched.col.df <- unmatched.df
unmatched.col.df$type[unmatched.col.df$type == "EPR2013"] <- "EPR"
unmatched.col.df$type[unmatched.col.df$type == "FRT2015"] <- "FRT"
unmatched.col.df$group <- paste0(unmatched.col.df$group, " [", unmatched.col.df$type, "]")
unmatched.col.df <- aggregate.data.frame(list(Missing = unmatched.col.df$group),
                                         list(country = unmatched.col.df$iso3c),
                                         FUN = function(x){paste(x[order(x)], collapse = "; ")})
unmatched.col.df$Missing <- paste("\\parbox{.8\\textwidth}{\\linespread{1}\\selectfont",
                                  unmatched.col.df$Missing, "}")
# ... to one large string
tab.string <- paste("\\begin{longtable}{ll} \\caption{Groups without a match in Ethnologue}  \\label{tab.no.match.list}     \\hline   Country & Groups \\\\   \\hline \\\\[-2.8ex] ",
                    paste(apply(unmatched.col.df, 1, paste, collapse = " & "), collapse = " \\\\ \\\\[-2.8ex] \n "),
                    "  \\\\[-2.8ex] \\\\ \\hline \\\\[-2.8ex]  \\end{longtable}")

# ... print
fileConn<-file(file.path(tab.path, "tablea6.tex"))
writeLines(tab.string, 
           fileConn)
close(fileConn)