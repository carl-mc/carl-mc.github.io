##########################################
# REPLICATION OF: 
#
# Linking Ethnic Data from Africa
#
# Journal of Peace Research
#
# By Carl Müller-Crepon, Yannick Pengl, and Nils-Christian Bormann, 2020
#
##########################################



# INIT ####
rm(list = ls())

# Working dictionary
# setwd()

# Number of CPUs
ncore <- 10

# LEDA package

## Install
# library(devtools)
# install_github(repo = "carl-mc/LEDA@230e1882590b59aaa545fabf3b8d408a1b3de0ad") ## Installs commit version from June 2020
library(LEDA)

# Packages
source("replication/code/packages.R")

# Paths
data.path <- "replication/data"
fig.path <- "replication/figures"
tab.path <- "replication/tables"
for(p in c(fig.path, tab.path)){
  dir.create(p, showWarnings = F)
}



# Exclude lists and group names from analysis

## Lists
##  Specific DHS and SIDE data from DMR, CIV, COD that 
##  list regional nstead of ethnic identities. 
drop.lists <- c(123, 130, 107, 108,
                176, 196, 211, 213)


## Drop groups containing the following:
drop.groups <- c("other", "outra","otro", "autre", "refused", "not asked","missing","mixed","Response suppressed",
                 "unknown","not specified", "not in universe", "illiterate", "non-", "not ", 
                 "foreign", "etrange", "dk", "don't know", "africa", "afrique", "africain", as.character(1:100, 999),
                 "ethnic language","alien")




# DATA #######

source("replication/code/load_data.R")


# TABLES #####
for(i in c("1", "A1", "A2", "A5", "A6")){
  print(paste("Table ", i))
  source(file.path("replication/code", paste0("table",i, ".R")))
}


# FIGURES ####
#  Note: Code for Figure 3 also produces Figure A2 and Table A4
for(i in c("1", "2","3","A1")){
  print(paste("Figure ", i))
  source(file.path("replication/code", paste0("figure",i, ".R")))
}


# ANALYSIS ###
#  Note: Code for Tables 2, 3, A7, A8
source("replication/code/analysis.R")


# Clean up
rm(list = ls())
gc()



